// import me from 'src/mocks/me.json';
// import { http, HttpResponse } from 'msw';

// import { HOST_API } from 'src/config-global';
import { mockJwtToken } from 'src/auth/context/jwt/utils';

// import productDeps from './product-deps.json';
// import orders from './orders.json';
// import order from './order.json';
// import me from './me.json';

mockJwtToken();

// const domain = `${HOST_API}v1`;
const handlers = [
  //   // http.get(`${domain}/orders`, () => HttpResponse.json(orders)),
  //   // http.get(`${domain}/orders/:id`, () => HttpResponse.json(order)),
  //   // http.get(`${domain}/auth/me`, () => HttpResponse.json(me)),
  //   // http.get(`${domain}/products`, () => HttpResponse.json(products)),
  //   // http.get(`${domain}/products/*`, ({ params }) => {
  //   //   console.log('Search for product', params['0']);
  //   //   const currentProduct = products.products.find((product) => product.id === params['0']);
  //   //   console.log({ currentProduct });
  //   //   return HttpResponse.json(currentProduct);
  //   // }),
  //   http.get(`${domain}/product-deps`, () => HttpResponse.json(productDeps))
];

export default handlers;
