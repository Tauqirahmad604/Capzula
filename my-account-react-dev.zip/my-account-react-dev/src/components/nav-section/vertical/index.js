export { default } from './nav-section-vertical';
