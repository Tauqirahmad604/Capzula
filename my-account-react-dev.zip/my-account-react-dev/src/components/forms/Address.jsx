import PropTypes from 'prop-types';
import React, { useState, useEffect } from 'react';

import { Box, Stack, MenuItem } from '@mui/material';

import { useGetWooCountriesAndStatesQuery } from 'src/redux/api/myAccount';

import { RHFSelect, RHFTextField } from '../hook-form';

const AddressFields = ({
  formValues,
  setValue,
  onCountryStateCodesReceived,
  setRequiresState,
  disabled,
}) => {
  // const { register, control } = useFormContext();

  const { data: wooData, isLoading } = useGetWooCountriesAndStatesQuery();
  const [selectedCountry, setSelectedCountry] = useState(null);

  useEffect(() => {
    setSelectedCountry(formValues.country);
  }, [formValues.country]);
  useEffect(() => {
    if (wooData?.data) {
      onCountryStateCodesReceived(wooData.data);
    }
  }, [onCountryStateCodesReceived, wooData]);

  const stateFieldType = () => {
    if (!wooData?.data?.states[selectedCountry]) {
      setRequiresState(true);
      return 'text';
    }

    if (
      wooData?.data?.states[selectedCountry] &&
      wooData?.data?.states[selectedCountry].length === 0
    ) {
      setRequiresState(false);
      return false;
    }

    if (
      wooData?.data?.states[selectedCountry] &&
      wooData?.data?.states[selectedCountry].length > 0
    ) {
      setRequiresState(true);
      return 'select';
    }

    setRequiresState(true);
    return 'text';
  };

  return (
    <Stack spacing={2} sx={{ pt: 1 }}>
      <RHFTextField
        disabled={disabled || isLoading}
        name="address.address_1"
        label="Address Line 1"
      />
      <RHFTextField
        disabled={disabled || isLoading}
        name="address.address_2"
        label="Address Line 2"
      />
      <Box
        rowGap={2}
        columnGap={2}
        display="grid"
        gridTemplateColumns={{
          xs: 'repeat(1, 1fr)',
          sm: 'repeat(2, 1fr)',
        }}
      >
        <RHFTextField disabled={disabled || isLoading} name="address.city" label="Town / City" />
        <RHFTextField
          disabled={disabled || isLoading}
          name="address.postcode"
          label="Zip / Postal Code"
        />
      </Box>

      <Box
        rowGap={2}
        columnGap={2}
        display="grid"
        gridTemplateColumns={{
          xs: 'repeat(1, 1fr)',
          sm: 'repeat(2, 1fr)',
        }}
      >
        <RHFSelect
          disabled={disabled || isLoading}
          name="address.country"
          label="Country"
          InputLabelProps={{ shrink: true }}
          onChange={(e) => {
            setSelectedCountry(e.target.value);
            setValue('address.country', e.target.value);
            setValue('address.state', '');
          }}
        >
          {wooData?.data?.countries?.map((country) => (
            <MenuItem key={country.code} value={country.code}>
              {country.label}
            </MenuItem>
          ))}
        </RHFSelect>

        {stateFieldType() === 'text' && (
          <RHFTextField
            disabled={disabled || isLoading}
            name="address.state"
            label="State / Province"
          />
        )}

        {stateFieldType() === 'select' && (
          <RHFSelect
            disabled={disabled || isLoading}
            name="address.state"
            label="State / Province"
            InputLabelProps={{ shrink: true }}
          >
            {wooData?.data?.states[selectedCountry]?.map((state) => (
              <MenuItem key={state.code} value={state.code}>
                {state.label}
              </MenuItem>
            ))}
          </RHFSelect>
        )}
      </Box>
    </Stack>
  );
};

export default AddressFields;

AddressFields.propTypes = {
  formValues: PropTypes.object.isRequired,
  setValue: PropTypes.func.isRequired,
  onCountryStateCodesReceived: PropTypes.func.isRequired,
  setRequiresState: PropTypes.func,
  disabled: PropTypes.bool,
};
