import PropTypes from 'prop-types';
import { Controller, useFormContext } from 'react-hook-form';

import TextField from '@mui/material/TextField';

// ----------------------------------------------------------------------

export default function RHFTextField({ name, helperText, type, noFormat = true, noDecimal, ...other }) {
  const { control } = useFormContext();
  const formatValue = (value) => {
    if (typeof value === 'number' || /^\d*\.?\d*$/.test(value)) {
      const numberValue = Intl.NumberFormat('en-US', {
        style: 'decimal',
        minimumFractionDigits: noDecimal ? 0 : 0,
        maximumFractionDigits: noDecimal ? 0 : 2,
      }).format(Number(value));
      return numberValue;
    }

    return value;
  };

  return (
    <Controller
      name={name}
      control={control}
      render={({ field, fieldState: { error } }) => (
        <TextField
          {...field}
          fullWidth
          type={type}
          value={noFormat ? field.value : formatValue(field.value)}
          onChange={(event) => {
            const { value } = event.target;
            if (type === 'number') {
              field.onChange(Number(value));
            } else {
              field.onChange(value);
            }
          }}
          error={!!error}
          helperText={error ? error?.message : helperText}
          {...other}
        />
      )}
    />
  );
}

RHFTextField.propTypes = {
  helperText: PropTypes.object,
  name: PropTypes.string,
  type: PropTypes.string,
  noFormat: PropTypes.bool,
  noDecimal: PropTypes.bool,
};
