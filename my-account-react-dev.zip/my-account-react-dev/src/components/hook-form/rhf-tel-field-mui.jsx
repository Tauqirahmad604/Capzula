import { forwardRef } from 'react';

// import { makeStyles } from '@mui/styles';
import { TextField } from '@mui/material';

// const UseStyles = makeStyles((theme) => ({
//   input: {
//     backgroundColor: '#fff',
//   },
// }));
const phoneInput = (props, ref) => (
  // const classes = UseStyles();

  <TextField
    {...props}
    // InputProps={{
    //   className: classes.input,
    // }}
    inputRef={ref}
    fullWidth
    label="Phone Number"
    variant="outlined"
    name="phone"
  />
);
export default forwardRef(phoneInput);
