import PropTypes from 'prop-types';
import { MuiTelInput } from 'mui-tel-input';
import { Controller, useFormContext } from 'react-hook-form';

// ----------------------------------------------------------------------

export default function RHFTelField({ name, helperText, defaultCountry, ...other }) {
  const { control } = useFormContext();

  return (
    <Controller
      name={name}
      control={control}
      render={({ field, fieldState: { error } }) => (
        <MuiTelInput
          {...field}
          fullWidth
          value={field.value}
          onChange={(value) => {
            field.onChange(value);
          }}
          error={!!error}
          helperText={error ? error?.message : helperText}
          {...other}
        />
      )}
    />
  );
}

RHFTelField.propTypes = {
  helperText: PropTypes.object,
  name: PropTypes.string,
  defaultCountry: PropTypes.string,
};
