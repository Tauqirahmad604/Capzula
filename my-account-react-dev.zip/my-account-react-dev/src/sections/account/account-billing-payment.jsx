import PropTypes from 'prop-types';
import { useSnackbar } from 'notistack';
import { useState, useEffect } from 'react';

import Box from '@mui/material/Box';
import Card from '@mui/material/Card';
import Button from '@mui/material/Button';
import CardHeader from '@mui/material/CardHeader';

import { useParams } from 'src/routes/hooks';

import { useBoolean } from 'src/hooks/use-boolean';

import {
  useCreateStripeIntentMutation,
  useDeletePaymentMethodMutation,
  useEnablePaymentMethodMutation,
  useSetDefaultPaymentMethodMutation,
} from 'src/redux/api/myAccount';

import Iconify from 'src/components/iconify';
import { LoadingScreen } from 'src/components/loading-screen';
import EmptyContent from 'src/components/empty-content/empty-content';

import PaymentCardItem from '../payment/payment-card-item';
import PaymentNewCardDialog from '../payment/payment-new-card-dialog';
import PaymentEditCardDialog from '../payment/payment-edit-card-dialog';
import PaymentDeleteCardDialog from '../payment/payment-delete-card-dialog';

// ----------------------------------------------------------------------

export default function AccountBillingPayment({ cards, loading }) {
  const newCard = useBoolean();
  const editCard = useBoolean();
  const deleteCard = useBoolean();

  const [createStripeIntent, createStripeIntentResult] = useCreateStripeIntentMutation();
  const [deletePaymentMethod, deletePaymentMethodResult] = useDeletePaymentMethodMutation();
  const [enablePaymentMethod, enablePaymentMethodResult] = useEnablePaymentMethodMutation();
  const [setDefaultPaymentMethod, setDefaultPaymentMethodResult] =
    useSetDefaultPaymentMethodMutation();

  const [isLoading, setIsLoading] = useState(false);
  const [cardEditing, setCardEditing] = useState(null);
  const { enqueueSnackbar } = useSnackbar();
  const { action } = useParams();

  const handleAddNewCard = () => {
    createStripeIntent();
    setIsLoading(true);
    newCard.onTrue();
  };

  useEffect(() => {
    if (action === 'new') {
      handleAddNewCard();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [action]);

  useEffect(() => {
    if (createStripeIntentResult.isSuccess) {
      setIsLoading(false);
    }
    if (createStripeIntentResult.isError) {
      enqueueSnackbar(createStripeIntentResult.error.data.data.message, { variant: 'error' });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [createStripeIntentResult]);

  const handleEditCard = (card) => {
    setCardEditing(card);
    editCard.onTrue();
  };

  const handleConfirmDeleteCard = (card) => {
    setCardEditing(card);
    deleteCard.onTrue();
    // deletePaymentMethod(card);
  };

  const handleDeleteCard = (card) => {
    deletePaymentMethod(card.payment_id);
  };

  useEffect(() => {
    if (deletePaymentMethodResult.isSuccess) {
      // refresh();
      enqueueSnackbar(deletePaymentMethodResult.data.data, { variant: 'success' });
    }
    if (deletePaymentMethodResult.isError) {
      enqueueSnackbar(deletePaymentMethodResult.error.data.data, { variant: 'error' });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [deletePaymentMethodResult]);

  const handleEnableCard = (id) => {
    enablePaymentMethod(id);
  };

  useEffect(() => {
    if (enablePaymentMethodResult.isSuccess) {
      enqueueSnackbar(enablePaymentMethodResult.data.data, { variant: 'success' });
    }
    if (enablePaymentMethodResult.isError) {
      enqueueSnackbar(enablePaymentMethodResult.error.data.data, { variant: 'error' });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [enablePaymentMethodResult]);

  const handleSetDefaultPaymentMethod = (id) => {
    setDefaultPaymentMethod(id);
  };

  useEffect(() => {
    if (setDefaultPaymentMethodResult.isSuccess) {
      enqueueSnackbar(setDefaultPaymentMethodResult.data.data, { variant: 'success' });
    }
    if (setDefaultPaymentMethodResult.isError) {
      enqueueSnackbar(setDefaultPaymentMethodResult.error.data.data, { variant: 'error' });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [setDefaultPaymentMethodResult]);

  return (
    <>
      <Card sx={{ my: 3 }}>
        <CardHeader
          title="Payment Methods"
          action={
            !loading && (
              <Button
                size="small"
                color="primary"
                startIcon={<Iconify icon="mingcute:add-line" />}
                onClick={() => handleAddNewCard()}
              >
                New Card
              </Button>
            )
          }
        />

        {loading ||
        setDefaultPaymentMethodResult.isLoading ||
        enablePaymentMethodResult.isLoading ||
        deletePaymentMethodResult.isLoading ? (
          <LoadingScreen />
        ) : (
          <>
            {!cards && (
              <EmptyContent
                title="No payment methods have been added yet"
                action={
                  <Button
                    sx={{ mt: 2 }}
                    color="success"
                    onClick={() => handleAddNewCard()}
                    variant="contained"
                  >
                    Add New Card
                  </Button>
                }
                sx={{ p: 2 }}
              />
            )}

            <Box
              rowGap={2.5}
              columnGap={2}
              display="grid"
              gridTemplateColumns={{
                xs: 'repeat(1, 1fr)',
                md: 'repeat(2, 1fr)',
              }}
              sx={{ p: 3 }}
            >
              {/* PaymentCardItemCompact */}
              {cards?.map((card) => (
                <PaymentCardItem
                  key={card.payment_id}
                  card={card}
                  editCard={handleEditCard}
                  deleteCard={handleConfirmDeleteCard}
                  enableCard={handleEnableCard}
                  setDefault={handleSetDefaultPaymentMethod}
                />
              ))}
            </Box>
          </>
        )}
      </Card>

      <PaymentNewCardDialog
        open={newCard.value}
        onClose={newCard.onFalse}
        secret={createStripeIntentResult?.data?.data?.client_secret}
        loading={isLoading}
      />
      {editCard.value && (
        <PaymentEditCardDialog
          open={editCard.value}
          onClose={editCard.onFalse}
          card={cardEditing}
        />
      )}
      {deleteCard.value && (
        <PaymentDeleteCardDialog
          open={deleteCard.value}
          onClose={deleteCard.onFalse}
          card={cardEditing}
          deleteCard={handleDeleteCard}
        />
      )}
    </>
  );
}

AccountBillingPayment.propTypes = {
  cards: PropTypes.array,
  loading: PropTypes.bool,
};
