import { useSnackbar } from 'notistack';
import { useState, useEffect } from 'react';

import { LoadingButton } from '@mui/lab';
import { Stack, Container } from '@mui/system';
import {
  Card,
  Table,
  TableRow,
  TableHead,
  TableCell,
  TableBody,
  TextField,
  CardHeader,
  Typography,
  CardContent,
  CircularProgress,
} from '@mui/material';

import { useAuthContext } from 'src/auth/hooks';
import {
  useSetPlatformFeeMutation,
  useDisconnectStripeMutation,
  useGenerateStripeAccountLinkQuery,
} from 'src/redux/api/myAccount';

import Iconify from 'src/components/iconify';
import { StyledIcon } from 'src/components/snackbar/styles';
import { useSettingsContext } from 'src/components/settings';

export default function AccountStripeConnect() {
  const settings = useSettingsContext();
  const { enqueueSnackbar } = useSnackbar();
  const { user, loading, refresh } = useAuthContext()

  const [platFee, setPlatFee] = useState(user.platform_fee);

  const [platformFeeLoading, setPlatformFeeLoading] = useState(false);

  const {
    data: stripeAccountLink,
    isLoading,
    isFetching,
    isError,
    error,
  } = useGenerateStripeAccountLinkQuery();
  const handleConnectStripe = () => {
    if (stripeAccountLink) {
      window.location.href = stripeAccountLink.data.url;
    }
  };

  const [disconnectStripe, disconnectStripeResult] = useDisconnectStripeMutation();
  const [setPlatformFee, setPlatformFeeResult] = useSetPlatformFeeMutation();

  const handleDisconnectStripe = () => {
    disconnectStripe();
  };
  useEffect(() => {
    if (disconnectStripeResult.isSuccess) {
      enqueueSnackbar(disconnectStripeResult?.data?.data, { variant: 'success' });
    }
    if (disconnectStripeResult.isError) {
      enqueueSnackbar(disconnectStripeResult?.error?.data.data, { variant: 'error' });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [disconnectStripeResult]);

  const handleUpdatePlatformFee = () => {
    if (!user?.is_emulating) {
      enqueueSnackbar('Unauthorized Action', { variant: 'error' });
      return;
    }

    if (platFee < 0 || platFee > 100) {
      enqueueSnackbar('Platform fee must be between 0 and 100', { variant: 'error' });
      return;
    }

    setPlatformFeeLoading(true);
    setPlatformFee({
      platformFee: platFee,
    });

  }

  useEffect(() => {
    if (setPlatformFeeResult.isSuccess) {
      enqueueSnackbar(setPlatformFeeResult?.data?.data, { variant: 'success' });
      setPlatformFeeLoading(false);
      refresh();
    }
    if (setPlatformFeeResult.isError) {
      enqueueSnackbar(setPlatformFeeResult?.error?.data.data, { variant: 'error' });
      setPlatformFeeLoading(false);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [setPlatformFeeResult]);

  return (
    <Container maxWidth={settings.themeStretch ? false : 'lg'}>
      <Card sx={{ mb: 3 }}>
        <CardHeader
          title="Platform Fees"
          subheader="Below you can find the fees that are charged by the platform for using our services."
        />
        <CardContent>
          {loading ? (
            <CircularProgress />
          ) : (
            <>
              <Stack sx={{ pb: 2 }}>
                <TextField
                  fullWidth
                  type="number"
                  label="Platform Fee"
                  value={platFee}
                  InputProps={{ endAdornment: '%' }}
                  onChange={(e) => setPlatFee(e.target.value)}
                  disabled={!user?.is_emulating}
                />
              </Stack>
              {user?.is_emulating && (
                <Stack alignItems="flex-end">
                  <LoadingButton
                    variant="contained"
                    color="primary"
                    onClick={() => handleUpdatePlatformFee(platFee)}
                    loading={platformFeeLoading}
                    sx={{ width: 100 }}
                  >
                    Update
                  </LoadingButton>
                </Stack>
              )}
            </>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader
          title="Automatic Stripe Payments"
          subheader="Stripe Connect allows you to automatically receive payments from buyers (minus our marketplace comission). This is only avaiable for customers with a United States Stripe account. You can connect your existing Stripe account or create one using the button below."
        />
        <CardContent>
          {isError ? (
            `Error : ${error?.data}`
          ) : (
            <>
              <LoadingButton
                variant={stripeAccountLink?.data.connected ? 'outlined' : 'contained'}
                color={stripeAccountLink?.data.connected ? 'secondary' : 'primary'}
                onClick={
                  stripeAccountLink?.data.connected ? handleDisconnectStripe : handleConnectStripe
                }
                loading={isLoading || isFetching || disconnectStripeResult.isLoading}
              >
                <Stack flexDirection="row" spacing={2} alignItems="center">
                  <Iconify icon="cib:stripe" />
                  {stripeAccountLink?.data.connected
                    ? 'Disconnect from Stripe'
                    : 'Connect to Stripe'}
                </Stack>
              </LoadingButton>
              {stripeAccountLink?.data.connected && (
                <Stack spacing={2} mt={6}>
                  <Typography variant="subtitle1" color="text.secondary">
                    {' '}
                    Stripe Status{' '}
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    {' '}
                    Please make sure all 3 parameters are green if any of them are red then you are
                    most likely missing information on stripe and will be required to login to your
                    stripe account and resolve issues.{' '}
                  </Typography>

                  <Table>
                    <TableHead>
                      <TableCell>Name</TableCell>
                      <TableCell>Status</TableCell>
                    </TableHead>
                    <TableBody>
                      {Object.entries(stripeAccountLink?.data.status).map(([key, status]) => (
                        <TableRow>
                          <TableCell sx={{ textTransform: 'capitalize' }}>
                            {key.replace('_', ' ')}
                          </TableCell>
                          <TableCell>
                            {status ? (
                              <StyledIcon sx={{ backgroundColor: 'transparent' }} color="success">
                                <Iconify icon="ic:baseline-check-box" width={30} />
                              </StyledIcon>
                            ) : (
                              <StyledIcon sx={{ backgroundColor: 'transparent' }} color="error">
                                <Iconify icon="entypo:squared-cross" width={30} />
                              </StyledIcon>
                            )}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </Stack>
              )}
            </>
          )}
        </CardContent>
      </Card>
    </Container>
  );
}
