import PropTypes from 'prop-types';
import { useSnackbar } from 'notistack';
import { useState, useEffect, useCallback } from 'react';

import Card from '@mui/material/Card';
import { Container } from '@mui/system';
import Stack from '@mui/material/Stack';
import { LoadingButton } from '@mui/lab';
import Button from '@mui/material/Button';
import MenuItem from '@mui/material/MenuItem';
import IconButton from '@mui/material/IconButton';
import CardHeader from '@mui/material/CardHeader';
import {
  Dialog,
  DialogTitle,
  DialogActions,
  DialogContent,
  DialogContentText,
} from '@mui/material';

import { useBoolean } from 'src/hooks/use-boolean';

import { useAuthContext } from 'src/auth/hooks';
import { useDeleteDeliveryAddressMutation } from 'src/redux/api/myAccount';

import Iconify from 'src/components/iconify';
import CustomPopover, { usePopover } from 'src/components/custom-popover';

import { AddressItem, AddressNewForm } from '../address';

// ----------------------------------------------------------------------

export function AccountDeliveryAddressContent({ addressForm }) {
  const [address, setAddress] = useState('');
  const [deleteDeliveryAddress, deleteDeliveryAddressResult] = useDeleteDeliveryAddressMutation();
  const { user, refresh } = useAuthContext();
  const { enqueueSnackbar } = useSnackbar();
  const popover = usePopover();

  const addressUpdateForm = useBoolean();
  const confirmDeletionDialog = useBoolean();

  const handlePopoverOpen = useCallback(
    (event, value) => {
      popover.onOpen(event);
      setAddress(value);
    },
    [popover]
  );

  const handleClose = useCallback(() => {
    popover.onClose();
    // setAddress('');
  }, [popover]);

  const handleDeleteAddress = () => {
    deleteDeliveryAddress({
      body: {
        id: address.id,
      },
    });
  };

  useEffect(() => {
    if (deleteDeliveryAddressResult.isSuccess) {
      refresh();
      enqueueSnackbar(deleteDeliveryAddressResult.data.data, { variant: 'success' });
      confirmDeletionDialog.onFalse();
    }
    if (deleteDeliveryAddressResult.isError) {
      enqueueSnackbar(deleteDeliveryAddressResult.error.data.data, { variant: 'error' });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [deleteDeliveryAddressResult]);

  return (
    <>
      <Stack spacing={2.5} sx={{ p: 3 }}>
        {Object.entries(user.delivery_addresses).map(([key, value]) => (
          <AddressItem
            variant="outlined"
            key={key}
            address={value}
            action={
              <IconButton
                onClick={(event) => {
                  handlePopoverOpen(event, value);
                }}
                sx={{ position: 'absolute', top: 8, right: 8 }}
              >
                <Iconify icon="eva:more-vertical-fill" />
              </IconButton>
            }
            sx={{
              p: 2.5,
              borderRadius: 1,
            }}
          />
        ))}
      </Stack>

      <CustomPopover open={popover.open} onClose={handleClose}>
        <MenuItem
          onClick={() => {
            handleClose();
            console.info('SET AS PRIMARY', address);
          }}
        >
          <Iconify icon="eva:star-fill" />
          Set as primary
        </MenuItem>

        <MenuItem
          onClick={() => {
            handleClose();
            addressUpdateForm.onTrue();
          }}
        >
          <Iconify icon="solar:pen-bold" />
          Edit
        </MenuItem>

        <MenuItem
          onClick={() => {
            handleClose();
            confirmDeletionDialog.onTrue();
          }}
          sx={{ color: 'error.main' }}
        >
          <Iconify icon="solar:trash-bin-trash-bold" />
          Delete
        </MenuItem>
      </CustomPopover>

      {addressForm.value && (
        <AddressNewForm open={addressForm.value} onClose={addressForm.onFalse} />
      )}

      {addressUpdateForm.value && (
        <AddressNewForm
          open={addressUpdateForm.value}
          onClose={addressUpdateForm.onFalse}
          isEditing={addressUpdateForm.value}
          addressData={address}
        />
      )}

      {confirmDeletionDialog.value && (
        <Dialog open={confirmDeletionDialog.value} onClose={confirmDeletionDialog.onFalse}>
          <DialogTitle>This action is irreversible</DialogTitle>
          <DialogContent>
            <DialogContentText>
              Please bear in mind that this action will not remove the delivery address from your
              existing orders. Are you sure you want to delete this address?
            </DialogContentText>
          </DialogContent>
          <DialogActions>
            <Button onClick={confirmDeletionDialog.onFalse} variant="outlined">
              Cancel
            </Button>
            <LoadingButton
              onClick={() => handleDeleteAddress()}
              variant="contained"
              loading={deleteDeliveryAddressResult.isLoading}
            >
              {' '}
              Delete{' '}
            </LoadingButton>
          </DialogActions>
        </Dialog>
      )}
    </>
  );
}
AccountDeliveryAddressContent.propTypes = {
  addressForm: PropTypes.object,
};

export default function AccountDeliveryAddress({ embeded }) {
  const addressForm = useBoolean();

  if (embeded) {
    return (
      <>
        <CardHeader
          title="Delivery Addresses"
          action={
            <Button
              size="small"
              color="primary"
              startIcon={<Iconify icon="mingcute:add-line" />}
              onClick={addressForm.onTrue}
            >
              Address
            </Button>
          }
        />
        <AccountDeliveryAddressContent addressForm={addressForm} />
      </>
    );
  }
  return (
    <Container>
      <Card>
        <CardHeader
          title="Delivery Addresses"
          action={
            <Button
              size="small"
              color="primary"
              startIcon={<Iconify icon="mingcute:add-line" />}
              onClick={addressForm.onTrue}
            >
              Address
            </Button>
          }
        />
        <AccountDeliveryAddressContent addressForm={addressForm} />
      </Card>
    </Container>
  );
}

AccountDeliveryAddress.propTypes = {
  embeded: PropTypes.bool,
};
