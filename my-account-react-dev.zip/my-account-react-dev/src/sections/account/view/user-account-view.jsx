import { useSnackbar } from 'notistack';
import { useState, useEffect } from 'react';
import { useStripe } from '@stripe/react-stripe-js';

import Container from '@mui/material/Container';

import { useAuthContext } from 'src/auth/hooks';
import { PARENT_HOST_URL } from 'src/config-global';
import { useGetPaymentMethodsQuery, useAddPaymentMethodMutation } from 'src/redux/api/myAccount';

import { useSettingsContext } from 'src/components/settings';

import AccountBillingPayment from '../account-billing-payment';

// ----------------------------------------------------------------------

// ----------------------------------------------------------------------

export default function AccountView() {
  const settings = useSettingsContext();
  const { refresh } = useAuthContext();
  const stripe = useStripe();
  const [loading, setLoading] = useState(false);
  const [addPaymentMethod, addPaymentMethodResult] = useAddPaymentMethodMutation();
  const { enqueueSnackbar } = useSnackbar();
  const clientSecret = new URLSearchParams(window.location.search).get(
    'setup_intent_client_secret'
  );
  const { data: cards, isLoading, isFetching } = useGetPaymentMethodsQuery();

  useEffect(() => {
    if (!stripe) {
      return;
    }
    if (clientSecret === null) {
      return;
    }
    setLoading(true);
    stripe.retrieveSetupIntent(clientSecret).then(({ setupIntent }) => {
      switch (setupIntent.status) {
        case 'succeeded':
          handleAddPaymentMethod(setupIntent.payment_method);
          break;

        case 'processing':
          setLoading(false);
          enqueueSnackbar(
            "Processing payment details. We'll update you when processing is complete.",
            { variant: 'info' }
          );
          break;

        case 'requires_payment_method':
          setLoading(false);
          enqueueSnackbar('Failed to process payment details. Please try another payment method.', {
            variant: 'error',
          });
          break;

        default:
          setLoading(false);
          enqueueSnackbar('Failed to process payment details. Please try another payment method.', {
            variant: 'error',
          });
          break;
      }
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [stripe]);
  const handleAddPaymentMethod = (paymentMethodID) => {
    addPaymentMethod({
      body: {
        paymentMethodID,
      },
    });
  };
  useEffect(() => {
    if (addPaymentMethodResult.isSuccess) {
      refresh();
      setLoading(false);
      enqueueSnackbar(addPaymentMethodResult.data.data, { variant: 'success' });
      window.parent.postMessage('cpz-refresh-payment-methods', PARENT_HOST_URL);
    }
    if (addPaymentMethodResult.isError) {
      setLoading(false);
      enqueueSnackbar(addPaymentMethodResult.error.data.data, { variant: 'error' });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [addPaymentMethodResult]);

  useEffect(() => {
    setLoading(isFetching);
  }, [isFetching]);

  return (
    <Container maxWidth={settings.themeStretch ? false : 'lg'}>
      <AccountBillingPayment cards={cards?.data} loading={loading || isLoading || isFetching} />
    </Container>
  );
}
