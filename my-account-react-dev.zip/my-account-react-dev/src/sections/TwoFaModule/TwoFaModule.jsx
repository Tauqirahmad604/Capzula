import * as Yup from 'yup';
import Cookies from 'js-cookie';
import PropTypes from 'prop-types';
import { combineLatest } from 'rxjs';
import { enqueueSnackbar } from 'notistack';
import ReactCodeInput from 'react-code-input';
import { useLocation } from 'react-router-dom';
import { useState, useEffect, useCallback } from 'react';

import { Box, Stack } from '@mui/system';
import { LoadingButton } from '@mui/lab';
import {
  Link,
  Alert,
  Button,
  Dialog,
  TextField,
  Typography,
  DialogTitle,
  DialogActions,
  DialogContent,
  CircularProgress,
} from '@mui/material';

import { paths } from 'src/routes/paths';
import { useRouter } from 'src/routes/hooks';

import { useAuthContext } from 'src/auth/hooks';
import { PARENT_HOST_URL } from 'src/config-global';
import {
  usePost2FaCodeMutation,
  useRenew2faCodeMutation,
  useGet2FaSummaryMutation,
  usePutChangeEmailMutation,
} from 'src/redux/api/myAccount';
import {
  twoFactor$,
  reRequestLast,
  enableTwoFactor,
  sendTwoFactorSuccess,
  twoFactorOnLoadSubject,
  resetTwoFactorAuthentication,
  cancelTwoFactorAuthentication,
} from 'src/lib/observables';

import Logo from 'src/components/logo';

const Countdown = ({ seconds, onComplete }) => {
  const [countdown, setCountdown] = useState(seconds);

  useEffect(() => {
    const interval = setInterval(() => {
      setCountdown((prev) => prev - 1);
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    if (countdown === 0) {
      onComplete(true);
    }
  }, [countdown, onComplete]);

  return (
    <>{countdown > 60 ? `${Math.floor(countdown / 60) + 1} minutes` : `${countdown} seconds`}</>
  );
};

Countdown.propTypes = {
  seconds: PropTypes.number,
  onComplete: PropTypes.func,
};
export default function TwoFaModule({ open, fullScreen, defaultTwoFaType }) {
  const { logout } = useAuthContext();
  const [dialogIsOpen, setDialogIsOpen] = useState(open);
  const [post2FaCode, post2FaCodeResults] = usePost2FaCodeMutation();
  const [renew2FaCode, renew2FaCodeResults] = useRenew2faCodeMutation();
  const [get2FaSummary, get2FaSummaryResult] = useGet2FaSummaryMutation();
  const [putChangeEmail, putChangeEmailResults] = usePutChangeEmailMutation();
  const [code, setCode] = useState('');
  const router = useRouter();
  const { pathname, search } = useLocation();
  const params = new URLSearchParams(search);

  const [twoFaBlocked, setTwoFaBlocked] = useState(false);
  const [twoFaAvailableIn, setTwoFaAvailableIn] = useState(false);
  const [twoFaExpired, setTwoFaExpired] = useState(false);
  const [twoFaType, setTwoFaType] = useState(defaultTwoFaType);
  const [changeEmail, setChangeEmail] = useState(false);
  const [newEmailAddress, setNewEmailAddress] = useState('');
  const [isEmailValid, setIsEmailValid] = useState(false);
  const { user, refresh: refreshUser } = useAuthContext();

  const setTwoFaValidCookie = (dateString) => {
    const dateParts = dateString.split(' ');
    const date = new Date(`${dateParts[0]}T${dateParts[1]}Z`);
    Cookies.set('2fa_session_authorized_until', date, { expires: date });
  };

  const removeTwoFaValidCookie = (dateString) => {
    Cookies.remove('2fa_session_authorized_until');
  };

  const handle2faResponse = (data) => {
    enableTwoFactor();

    if (!data.valid) {
      removeTwoFaValidCookie();
    }
    if (data.tfa_type) {
      setTwoFaType(data.tfa_type);
    }

    if (data.blocked_for_secs) {
      setTwoFaBlocked(true);
      setTwoFaAvailableIn(data.blocked_for_secs);
    }
  };

  useEffect(() => {
    if (dialogIsOpen && twoFaType) {
      get2FaSummary({
        type: twoFaType,
      });
    }
  }, [dialogIsOpen, get2FaSummary, twoFaType]);

  useEffect(() => {
    if (get2FaSummaryResult.isSuccess) {
      if (
        get2FaSummaryResult.data?.data?.active ||
        (get2FaSummaryResult.data?.data?.verified && twoFaType === 'verify_email')
      ) {
        router.replace(paths.dashboard.root);
      } else {
        if (get2FaSummaryResult.data?.data.requires_renewal) {
          renew2FaCode({
            type: get2FaSummaryResult.data?.data.tfa_type,
          });
        }
        handle2faResponse(get2FaSummaryResult.data?.data);
      }
    }
    if (get2FaSummaryResult.isError) {
      enqueueSnackbar("There's been a problem", { variant: 'error' });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [get2FaSummaryResult.isSuccess, get2FaSummaryResult.isError]);

  useEffect(() => {
    const subscription = combineLatest([twoFactor$, twoFactorOnLoadSubject]).subscribe(
      ([{ action, isActive }, request]) => {
        if (fullScreen) return;

        if (action === 'SHOW_2FA') {
          if (isActive) {
            setDialogIsOpen(true);
          } else {
            setDialogIsOpen(false);
          }
        }

        if (action === 'CANCEL_2FA') {
          setDialogIsOpen(false);
          // enqueueSnackbar('You do not have access to perform this action', { variant: 'error' });
          if (request.request_method === 'get') {
            router.push(paths.error['401']);
          }
        }
      }
    );

    return () => {
      resetTwoFactorAuthentication();
      subscription.unsubscribe();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [router, pathname, twoFaType]);

  useEffect(() => {
    if (!fullScreen) {
      twoFactorOnLoadSubject.subscribe((data) => {
        handle2faResponse(data);
      });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [fullScreen]);

  useEffect(() => {
    if (post2FaCodeResults.isSuccess) {
      enqueueSnackbar('Code verified successfully', { variant: 'success' });
      const authorizedUntil = post2FaCodeResults?.data?.data?.authorized_until;
      if (authorizedUntil) {
        setTwoFaValidCookie(authorizedUntil);
        sendTwoFactorSuccess();
        setDialogIsOpen(false);
      }

      if (!fullScreen) {
        resetTwoFactorAuthentication();
        reRequestLast();
      } else {
        const redirectTo = params.get('redirect_to');
        if (!redirectTo) {
          window.location.replace(paths.dashboard.root);
        } else {
          window.location.replace(`${PARENT_HOST_URL}/${redirectTo || ''}`);
        }
      }
    }
    if (post2FaCodeResults.isError) {
      const resp = post2FaCodeResults?.error?.data?.data;
      handle2faResponse(resp);
      enqueueSnackbar('Unable to verify code', { variant: 'error' });
      setCode('');
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [post2FaCodeResults.isSuccess, post2FaCodeResults.isError, post2FaCodeResults]);

  useEffect(() => {
    if (renew2FaCodeResults.isSuccess) {
      enqueueSnackbar('A new code has been sent to your email', { variant: 'success' });
      setTwoFaBlocked(false);
      setTwoFaAvailableIn(false);
      setCode('');
    }

    if (renew2FaCodeResults.isError) {
      enqueueSnackbar('Unable to renew code, please try again later', { variant: 'error' });
    }
  }, [renew2FaCodeResults.isError, renew2FaCodeResults.isSuccess]);

  useEffect(() => {
    // check if length of pin is 6
    console.log(code, code.length, twoFaType, '<< 649789');
    if (code.length === 6 && twoFaType) {
      console.log('in here');
      post2FaCode({
        code,
        type: twoFaType,
      });
    }
  }, [code, post2FaCode, twoFaType]);

  useEffect(() => {
    if (!dialogIsOpen) {
      setTwoFaBlocked(false);
      setTwoFaAvailableIn(false);
      setTwoFaExpired(false);
      setTwoFaType(null);
      setCode('');
    }
  }, [dialogIsOpen]);

  const isLoading = () =>
    get2FaSummaryResult.isLoading ||
    get2FaSummaryResult.isFetching ||
    post2FaCodeResults.isLoading ||
    post2FaCodeResults.isFetching ||
    renew2FaCodeResults.isLoading ||
    putChangeEmailResults.isLoading ||
    putChangeEmailResults.isFetching ||
    renew2FaCodeResults.isFetching;

  const generateContent = useCallback(() => {
    if (changeEmail) {
      return {
        title: 'Change Email Address',
        content: 'Please enter the new email address you would like to use.',
      };
    }
    if (twoFaType === 'verify_email') {
      return {
        title: 'Verify Your Email Address',
        content: `Please enter the 6 digit code sent to ${user?.email}`,
      };
    }

    if (twoFaBlocked) {
      return {
        title: 'Two-Factor Authentication Restriction',
        content: `You have entered an invalid code too many times. Please try again in ${twoFaAvailableIn} minutes.`,
      };
    }

    return {
      title: `Two-Factor Authentication ${twoFaType === 'session' ? 'Login' : ''}`,
      content: 'Please enter the 6 digit code sent to your email to access your account.',
    };
  }, [changeEmail, twoFaType, twoFaBlocked, user?.email, twoFaAvailableIn]);

  const emailSchema = Yup.string().matches(
    /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/,
    'Please enter a valid email address'
  );

  const emailAddressIsValid = async (email) => {
    try {
      await emailSchema.validate(email);
      return true;
    } catch (error) {
      return false;
    }
  };

  const handleEmailInputChange = async (value) => {
    setNewEmailAddress(value);
    if (!value) {
      return setIsEmailValid(false);
    }
    const valid = await emailAddressIsValid(value);
    return setIsEmailValid(valid);
  };

  const submitEmailChange = () => {
    putChangeEmail({
      email: newEmailAddress,
    });
  };

  useEffect(() => {
    if (putChangeEmailResults.isSuccess) {
      refreshUser();
      enqueueSnackbar('Email address changed successfully', { variant: 'success' });
      setChangeEmail(false);
      setNewEmailAddress('');
      renew2FaCode({ type: twoFaType, force: true });
    }

    if (putChangeEmailResults.isError) {
      console.log(putChangeEmailResults, '<< putChangeEmailResults');
      if (putChangeEmailResults?.error?.data?.data?.email_exists) {
        enqueueSnackbar('Email address already exists', { variant: 'error' });
      } else if (putChangeEmailResults?.error?.data?.data?.email_already_verified) {
        enqueueSnackbar('Your email is already verified', { variant: 'error' });
        router.replace(paths.dashboard.root);
      } else {
        enqueueSnackbar('Unable to change email address', { variant: 'error' });
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [putChangeEmailResults.isSuccess, putChangeEmailResults.isError, putChangeEmailResults]);

  return (
    <Dialog
      fullWidth
      maxWidth="xs"
      open={fullScreen || dialogIsOpen}
      sx={
        fullScreen
          ? {
              backgroundImage: `url("/assets/background/2fa-bg-1.jpg")`,
              backgroundSize: 'cover',
              backgroundPosition: 'center',
            }
          : {}
      }
      // onClose={onClose}
    >
      {fullScreen && (
        <DialogContent>
          <Stack alignContent="center" alignItems="center" sx={{ mt: 4 }}>
            <Logo maxHeight={45} />
          </Stack>
        </DialogContent>
      )}

      <>
        <DialogTitle textAlign="center" sx={{ pb: 2 }}>
          {generateContent().title}
        </DialogTitle>

        {twoFaBlocked ? (
          <DialogContent>
            <Alert severity="warning" sx={{ px: 3 }}>
              You have entered an invalid code too many times. Please try again in{' '}
              <Countdown
                seconds={twoFaAvailableIn}
                onComplete={() => {
                  setTwoFaBlocked(false);
                  renew2FaCode({
                    type: twoFaType,
                  });
                }}
              />
              .
            </Alert>
          </DialogContent>
        ) : (
          <DialogContent>
            <Typography textAlign="center" sx={{ px: 3, pb: 3 }}>
              {generateContent().content}
            </Typography>

            <Box sx={{ textAlign: 'center' }}>
              {isLoading() ? (
                <CircularProgress />
              ) : (
                <>
                  {changeEmail ? (
                    <Stack>
                      <TextField
                        value={newEmailAddress}
                        onChange={(e) => handleEmailInputChange(e.target.value)}
                        fullWidth
                        autoFocus
                        type="email"
                        placeholder="Email Address"
                      />
                      <LoadingButton
                        onClick={submitEmailChange}
                        loading={putChangeEmailResults.isLoading}
                        variant="contained"
                        disabled={!isEmailValid}
                        // size="small"
                        sx={{ mt: 1 }}
                      >
                        Change Email
                      </LoadingButton>
                      <Typography textAlign="center" sx={{ px: 2, pt: 1, fontSize: 12 }}>
                        <Link
                          sx={{ color: '#333', cursor: 'pointer', textDecoration: 'underline' }}
                          variant="outlined"
                          onClick={(e) => {
                            setChangeEmail(false);
                            e.preventDefault();
                          }}
                        >
                          Go back
                        </Link>
                      </Typography>
                    </Stack>
                  ) : (
                    <>
                      <ReactCodeInput
                        autoFocus
                        onChange={(codeInput) => setCode(codeInput)}
                        type="number"
                        fields={6}
                      />

                      <Stack flexWrap="wrap">
                        <Typography textAlign="center" sx={{ px: 3, pt: 2, fontSize: 12 }}>
                          {twoFaType !== 'verify_email' && 'Code not arrived?'}{' '}
                          {twoFaType === 'verify_email' && (
                            <>
                              <Link
                                sx={{
                                  color: '#333',
                                  cursor: 'pointer',
                                  textDecoration: 'underline',
                                }}
                                variant="outlined"
                                onClick={(e) => {
                                  setChangeEmail(true);
                                  e.preventDefault();
                                }}
                              >
                                Change email address
                              </Link>
                              &nbsp;&nbsp; | &nbsp;&nbsp;
                            </>
                          )}
                          <Link
                            sx={{ color: '#333', cursor: 'pointer', textDecoration: 'underline' }}
                            variant="outlined"
                            onClick={(e) => {
                              renew2FaCode({ type: twoFaType, force: true });
                              e.preventDefault();
                            }}
                          >
                            Resend email
                          </Link>
                        </Typography>
                      </Stack>
                    </>
                  )}
                </>
              )}
            </Box>

            {twoFaExpired && (
              <Alert severity="warning" sx={{ px: 3, mt: 3 }}>
                The code has expired. A new code has been sent your email.
              </Alert>
            )}
          </DialogContent>
        )}
        <DialogActions>
          <Button
            variant="outlined"
            color="inherit"
            size="small"
            disabled={isLoading()}
            onClick={() => {
              if (twoFaType === 'session' || twoFaType === 'verify_email') {
                return logout();
              }
              cancelTwoFactorAuthentication();
              return setDialogIsOpen(false);
            }}
          >
            Cancel {twoFaType === 'session' || twoFaType === 'verify_email' ? '& Logout' : ''}
          </Button>
        </DialogActions>
      </>
    </Dialog>
  );
}

TwoFaModule.propTypes = {
  open: PropTypes.bool,
  fullScreen: PropTypes.bool,
  defaultTwoFaType: PropTypes.string,
};

TwoFaModule.defaultProps = {
  open: false,
  fullScreen: false,
  defaultTwoFaType: 'temporary',
};
