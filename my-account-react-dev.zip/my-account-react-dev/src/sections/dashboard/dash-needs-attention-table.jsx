import PropTypes from 'prop-types';
import { Link } from 'react-router-dom';

import { Stack } from '@mui/system';
import {
  Card,
  Table,
  Button,
  TableRow,
  TableBody,
  TableCell,
  TableHead,
  CardHeader,
  CardContent,
  TableContainer,
  CircularProgress,
} from '@mui/material';

import Label from 'src/components/label';
import { TableNoData } from 'src/components/table';

export default function DashboardNotificationsTable({notifications, isLoading, title}) {

  const getPriority = (priority) => {
    switch (priority) {
      case 'low':
        return <Label>Low</Label>;
      case 'medium':
        return <Label color="warning">Medium</Label>;
      case 'high':
        return <Label color="error">High</Label>;
      default:
        return <Label>{priority}</Label>;
    }
  };

  return (
    <Card>
      <CardHeader title={title} />
      <CardContent>
        <TableContainer>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell width="5%">#</TableCell>
                <TableCell width="75%">Message</TableCell>
                <TableCell width="10%">Priority</TableCell>
                <TableCell width="10%">Actions</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {isLoading}
              {isLoading ? (
                <TableRow>
                  <TableCell colSpan={12}>
                    <Stack style={{ minHeight: 300 }} alignItems="center" justifyContent="center">
                      <CircularProgress />
                    </Stack>
                  </TableCell>
                </TableRow>
              ) : (
                <>
                  {notifications?.data?.map((item, index) => (
                    <TableRow key={index}>
                      <TableCell>{index + 1}</TableCell>
                      <TableCell>{item.message}</TableCell>
                      <TableCell>{getPriority(item.priority)}</TableCell>
                      <TableCell>
                        <Button variant="contained" color="primary" size="small">
                          {item.link && <Link to={item.link} style={{color:'#fff'}}>View</Link>}
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                  <TableNoData
                    notFound={notifications?.data?.length === 0}
                    title="You are all set for now! Let's keep it that way.😉"
                  />
                </>
              )}
            </TableBody>
          </Table>
        </TableContainer>
      </CardContent>
    </Card>
  );
}

DashboardNotificationsTable.propTypes = {
  notifications: PropTypes.array,
  isLoading: PropTypes.bool,
  title: PropTypes.string,
};