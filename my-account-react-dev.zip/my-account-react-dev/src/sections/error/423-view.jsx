import { m } from 'framer-motion';
import { useEffect } from 'react';

import { Link, Button } from '@mui/material';
import Typography from '@mui/material/Typography';

import { paths } from 'src/routes/paths';
import { useRouter } from 'src/routes/hooks';

import CompactLayout from 'src/layouts/compact';
import { useAuthContext } from 'src/auth/hooks';

import { varBounce, MotionContainer } from 'src/components/animate';

// ----------------------------------------------------------------------

export default function View423() {
  const { logout, user } = useAuthContext();
  const router = useRouter();

  useEffect(() => {
    if (!user?.account_locked) {
      console.log(user);
      router.push(paths.dashboard.root);
    }
  }, [router, user]);

  return (
    <CompactLayout>
      <MotionContainer>
        <m.div variants={varBounce().in}>
          <Typography variant="h3" sx={{ mb: 2 }}>
            Your account is locked
          </Typography>
        </m.div>

        <m.div variants={varBounce().in}>
          <Typography sx={{ color: 'text.secondary' }}>
            You are unable to access this page, if you believe this is a mistake, please{' '}
            <Link
              sx={{ color: '#333', cursor: 'pointer', textDecoration: 'underline' }}
              href="mailto:support@capzula.com"
              target="_blank"
              rel="noreferrer"
            >
              contact us
            </Link>
            .
          </Typography>

          <Button onClick={logout} size="large" sx={{ mt: 2 }} color="error" variant="outlined">
            {' '}
            Logout
          </Button>
        </m.div>
      </MotionContainer>
    </CompactLayout>
  );
}
