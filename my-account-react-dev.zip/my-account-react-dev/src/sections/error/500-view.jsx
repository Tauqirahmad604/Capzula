import PropTypes from 'prop-types';
import { useEffect, useCallback } from 'react';
import { useErrorBoundary } from 'react-error-boundary';

import Box from '@mui/material/Box';
import Stack from '@mui/material/Stack';
import Button from '@mui/material/Button';
import Typography from '@mui/material/Typography';

import { RouterLink } from 'src/routes/components';

import { SeverErrorIllustration } from 'src/assets/illustrations';

import Logo from 'src/components/logo';

// ----------------------------------------------------------------------

function Page500({ error }) {
  const { resetBoundary } = useErrorBoundary();

  const resetBoundaryOnNavigateBack = useCallback(() => {
    resetBoundary();
  }, [resetBoundary]);

  useEffect(() => {
    // on navigate back reset the error boundary
    window.addEventListener('popstate', resetBoundaryOnNavigateBack);

    return () => {
      window.removeEventListener('popstate', resetBoundaryOnNavigateBack);
    };
  }, [error, resetBoundaryOnNavigateBack]);

  return (
    <Box
      sx={{
        display: 'flex',
        minHeight: '100vh',
        maxWidth: '450px',
        alignItems: 'center',
        flexDirection: 'column',
        alignContent: 'center',
        justifyContent: 'center',
        margin: 'auto',
      }}
    >
      <Stack spacing={2} alignItems="center">
        <Box pb={4}>
          <Logo />
        </Box>
        <Box mt={3}>
          <Typography variant="h4" sx={{ mb: 2 }}>
            Something went wrong!
          </Typography>
        </Box>

        <Box>
          <Typography sx={{ color: 'text.secondary' }}>
            There was an error, please try again later.
          </Typography>
        </Box>

        <Box>
          <SeverErrorIllustration sx={{ height: 260, my: { xs: 5, sm: 10 } }} />
        </Box>

        {import.meta.env.MODE === 'development' && (
          <Button color="inherit" variant="outlined" onClick={resetBoundary} size="large">
            Try again
          </Button>
        )}

        <Button
          color="inherit"
          variant="outlined"
          onClick={resetBoundary}
          component={RouterLink}
          href="/"
          size="large"
        >
          Go to Home
        </Button>
      </Stack>
    </Box>
  );
}

Page500.propTypes = {
  error: PropTypes.object,
};

export default Page500;
