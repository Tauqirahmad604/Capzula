import keyBy from 'lodash/keyBy';
import PropTypes from 'prop-types';
import { sortBy, orderBy, groupBy } from 'lodash';
import { useSelector, useDispatch } from 'react-redux';
import { useRef, useMemo, useState, useEffect, useCallback } from 'react';

import { useSearchParams } from 'src/routes/hooks';

import { HOST_API } from 'src/config-global';
import { useAuthContext } from 'src/auth/hooks';
import { useSupabaseContext } from 'src/supabase/hooks';
import { axiosBaseQuery } from 'src/redux/api/baseQuery';
import {
  setParticipants,
  resetUnreadCount,
  selectParticipants,
  selectConversations,
  incrementUnreadCount,
  addHistoricalMessages,
  addNewMessage as addNewMessageRedux,
  setConversations as setConversationsRedux,
} from 'src/redux/chats';

import { ChatContext } from './chat-context';
import { contentTypes, fetchActions } from '../constants';

function formatUserDetails(userDetails) {
  if (!userDetails) {
    return {
      name: 'Unavailable',
      avatarUrl: null,
    };
  }

  const cleanedName =
    userDetails.name?.trim() || userDetails.display_name?.trim() || 'Name Unavailable';

  return {
    name: cleanedName,
    avatarUrl: userDetails.profile_photo,
  };
}

function createNewMessage(message) {
  return {
    id: message.id,
    receiverId: message.receiver_id,
    senderId: message.sender_id,
    body: message.body,
    contentType: message.content_type,
    createdAt: message.created_at,
    chatId: message.chat_id,
  };
}

async function getUserDetails(userIds) {
  try {
    const axios = axiosBaseQuery({
      baseUrl: `${HOST_API}v1/`,
    });

    const { data: response } = await axios({
      url: 'chats/users',
      params: {
        ids: userIds,
      },
    });

    const userDetails = response;

    const formattedUserDetails = Object.entries(userDetails.data).reduce((acc, [key, value]) => {
      acc[key] = formatUserDetails(value);

      return acc;
    }, {});

    return {
      data: formattedUserDetails,
    };
  } catch (error) {
    return {
      error: {
        message: error.message,
      },
    };
  }
}

export function ChatProvider({ children }) {
  const { makeAPICall, dbClient, accessToken } = useSupabaseContext();
  const searchParams = useSearchParams();
  const { user } = useAuthContext();
  const [userStatus] = useState('offline');
  const [conversationLoading, setConversationsLoading] = useState(true);
  const [conversationError, setConversationError] = useState('');
  const chatChannel = useRef(null);
  const scrollRef = useRef(null);
  const activeConversationId = searchParams.get('id') || '';
  const receiverId = searchParams.get('to') || '';
  const [lastMessageFetchAction, setLastMessageFetchAction] = useState(null);
  const dispatch = useDispatch();
  const conversations = useSelector(selectConversations);
  const participants = useSelector(selectParticipants);

  const representativeUserId = useMemo(() => {
    if (!user) {
      return '';
    }
    if (user.parent_id) {
      return user.parent_id;
    }

    if (user.emulated_user_id) {
      return user.emulated_user_id;
    }

    return user.id;
  }, [user]);

  const getUserDetailsFor = useCallback(
    async (user_id) =>
      getUserDetails([user_id])
        .then(({ data }) => {
          dispatch(setParticipants({ participants: data }));
        })
        .catch((err) => {
          console.error(err);
          setConversationError(err.message);
        }),
    [dispatch]
  );

  const scrollToBottom = useCallback(() => {
    if (!scrollRef.current) return;
    scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, [scrollRef]);

  const getInitialConversations = useCallback(async () => {
    try {
      setConversationsLoading(true);
      const { data: messages } = await makeAPICall((apiClient) =>
        apiClient.rpc('get_recent_user_chat_messages', {
          user_id: representativeUserId,
          row_limit: 10,
        })
      );
      const participantsIds = messages.reduce((acc, curr) => {
        acc.add(curr.sender_id);
        acc.add(curr.receiver_id);
        return acc;
      }, new Set());

      const [unreadMessages, usersDetails] = await Promise.all([
        makeAPICall((apiClient) =>
          apiClient.rpc('unread_chat_messages', { user_id: representativeUserId })
        ),
        getUserDetails(Array.from(participantsIds)),
      ]);

      const unreadMessagesById = unreadMessages.data.reduce((acc, curr) => {
        acc[curr.chat_id] = curr.count;
        return acc;
      }, {});

      const conversationsById = groupBy(messages, 'chat_id');
      const userChats = Object.values(conversationsById).map((chat) => {
        const [firstMessage] = chat;
        return {
          id: firstMessage.chat_id,
          totalMessages: firstMessage.total_messages,
          unreadCount: unreadMessagesById[firstMessage.chat_id] || 0,
          messages: chat
            .map((message) => ({ ...message, id: message.message_id }))
            .map(createNewMessage),
          participants: [firstMessage.sender_id, firstMessage.receiver_id],
          type: 'ONE_TO_ONE',
        };
      });

      dispatch(setConversationsRedux({ conversations: userChats }));
      dispatch(setParticipants({ participants: usersDetails.data }));

      setConversationsLoading(false);
      setLastMessageFetchAction(fetchActions.INITIAL);
    } catch (error) {
      console.error(error);
      setConversationError(error.message);
      setConversationsLoading(false);
    }
  }, [dispatch, makeAPICall, representativeUserId]);

  const createConversation = useCallback(
    async (conversationData) => {
      const { messages, participants: newParticipants, type } = conversationData;

      const { data: newChat, error: chatError } = await makeAPICall((apiClient) =>
        apiClient
          .from('chats')
          .insert({
            type,
          })
          .select()
          .single()
      );

      if (chatError) {
        console.error(chatError);
        setConversationError(chatError.message);
      } else {
        const chatParticipants = newParticipants.map((participantId) => ({
          user_id: participantId,
          chat_id: newChat.id,
        }));
        const { error: userConversationError } = await makeAPICall((apiClient) =>
          apiClient.from('user_chats').insert(chatParticipants).select()
        );

        if (userConversationError) {
          console.error(userConversationError);
          setConversationError(userConversationError.message);
        } else {
          const message = messages[0];
          const { error: chatMessagesError } = await makeAPICall((apiClient) =>
            apiClient
              .from('chat_messages')
              .insert({
                sender_id: message.senderId,
                receiver_id: message.receiverId,
                chat_id: newChat.id,
                sent_by_id: user.id,
                body: message.body,
                content_type: message.contentType,
              })
              .select()
          );

          if (chatMessagesError) {
            console.error(chatMessagesError);
            setConversationError(chatMessagesError.message);
          }
        }
      }

      return {
        conversation: {
          id: newChat.id,
        },
      };
    },
    [makeAPICall, user]
  );

  const markMessagesAsRead = useCallback(
    async (chatId) => {
      makeAPICall((apiClient) =>
        apiClient
          .from('chat_messages')
          .update({
            read: true,
          })
          .eq('chat_id', chatId)
          .eq('receiver_id', representativeUserId)
          .eq('read', false)
      );
    },
    [makeAPICall, representativeUserId]
  );

  const markChatAsRead = useCallback(
    async (chatId) => {
      const activeConversation = conversations.find((chat) => chat.id === chatId);

      if (!activeConversation) {
        return;
      }

      if (activeConversation.unreadCount > 0) {
        await markMessagesAsRead(chatId);
        dispatch(resetUnreadCount({ conversationId: chatId }));
      }
    },
    [conversations, markMessagesAsRead, dispatch]
  );

  const markMessageAsUnRead = useCallback(
    async (chatId) => {
      dispatch(incrementUnreadCount({ conversationId: chatId }));
    },
    [dispatch]
  );

  const handleNewMessage = useCallback(
    async (message) => {
      const isOwnMessage = message.sender_id === representativeUserId;

      if (!participants[message.sender_id]) {
        getUserDetailsFor(message.sender_id);
      }

      dispatch(
        addNewMessageRedux({
          conversationId: message.chat_id,
          message: createNewMessage(message),
          isOwnMessage,
        })
      );

      setLastMessageFetchAction(fetchActions.ADD_NEW);
    },
    [representativeUserId, participants, dispatch, getUserDetailsFor]
  );

  const subscribeToChatChanges = useCallback(async () => {
    if (!chatChannel.current && representativeUserId) {
      console.info('Subscribe to chat changes');
      chatChannel.current = dbClient.channel('postgres:public:chat_messages', {
        config: {
          presence: {
            key: representativeUserId,
          },
        },
      });

      chatChannel.current
        // .on('presence', { event: 'sync' }, () => {
        //   const newState = chatChannel.current.presenceState()
        //   console.log('sync', newState)
        // })
        // .on('presence', { event: 'join' }, ({ key, newPresences }) => {
        //   console.log('join', key, newPresences)
        // })
        // .on('presence', { event: 'leave' }, ({ key, leftPresences }) => {
        //   console.log('leave', key, leftPresences)
        // })
        .on(
          'postgres_changes',
          {
            event: 'INSERT',
            schema: 'public',
            table: 'chat_messages',
            // filter: `sender_id=${representativeUserId} OR receiver_id=${representativeUserId}`,
          },
          (payload) => {
            console.info('Change received!', payload);
            handleNewMessage(payload.new);
          },
          { debug: true }
        )
        // .on('presence', { event: 'sync' }, () => {
        //   console.log('Synced presence state: ', chatChannel.current.presenceState())
        // })
        .subscribe(async (status) => {
          // console.log('status', status)
          if (status !== 'SUBSCRIBED') {
            // try reconnecting
            // console.log('reconnecting realtime');
            // reconnect();
          }

          // const currentStatus = {
          //   user_id: representativeUserId,
          //   state: 'online',
          //   metadata: {
          //     last_seen_at: new Date().toISOString(),
          //   }
          // }

          // if(!chatChannel.current?.presenceState()?.[representativeUserId]) {
          //   const presenceTrackStatus = await chatChannel.current?.track(currentStatus)
          //   // setUserStatus('online');
          //   console.log({presenceTrackStatus})
          // }
        });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [handleNewMessage, representativeUserId]);

  const fetchMoreChatMessagesFor = useCallback(
    async (chatId) => {
      const currentChat = conversations.find((chat) => chat.id === chatId);

      if (!currentChat) {
        return;
      }

      const messagesSize = currentChat.messages.length;
      const hasMoreMessages = currentChat.totalMessages > messagesSize;

      if (!hasMoreMessages) {
        return;
      }

      const remainingMessages = currentChat.totalMessages - messagesSize;
      const nextMessagesSize = remainingMessages > 10 ? 10 : remainingMessages;

      const { data, error } = await makeAPICall((apiClient) =>
        apiClient
          .from('chat_messages')
          .select('*')
          .eq('chat_id', chatId)
          .order('created_at', { ascending: false })
          .range(messagesSize, messagesSize + nextMessagesSize)
      );

      if (error) {
        console.error(error);
        return;
      }

      const newMessages = data.map(createNewMessage);

      dispatch(
        addHistoricalMessages({
          conversationId: chatId,
          messages: newMessages,
        })
      );

      setLastMessageFetchAction(fetchActions.FETCH_MORE);
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [conversations]
  );

  const addNewMessage = useCallback(
    async (chatId, messageData) => {
      try {
        let insertMessagePromises = [];
        if (messageData.contentType === contentTypes.MEDIA) {
          insertMessagePromises = messageData.attachments.map(async (file) => {
            const contentType = file.type.includes('image')
              ? contentTypes.IMAGE
              : contentTypes.FILE;
            const fileExtension = file.name.split('.').pop();
            const fileName = `${messageData.id}.${fileExtension}`;

            await makeAPICall((apiClient) =>
              apiClient.storage.from('chats').upload(`${chatId}/${fileName}`, file.file, {
                cacheControl: '3600',
                upsert: false,
              })
            );

            await makeAPICall((apiClient) =>
              apiClient.from('chat_messages').insert({
                body: fileName,
                sender_id: representativeUserId,
                receiver_id: messageData.receiverId,
                chat_id: chatId,
                content_type: contentType,
                sent_by_id: user.id,
              })
            );
          });
        }

        if (messageData.body) {
          insertMessagePromises.push(
            await makeAPICall((apiClient) =>
              apiClient.from('chat_messages').insert({
                body: messageData.body,
                sender_id: representativeUserId,
                receiver_id: messageData.receiverId,
                chat_id: chatId,
                content_type: contentTypes.TEXT,
                sent_by_id: user.id,
              })
            )
          );
        }

        return Promise.all(insertMessagePromises);
      } catch (error) {
        console.error(error);
        return null;
      }
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [representativeUserId]
  );

  const getSignedUrlForMedia = useCallback(async (chatId, filename) => {
    const { data, error: urlError } = await makeAPICall((apiClient) =>
      apiClient.storage.from('chats').createSignedUrl(`${chatId}/${filename}`, 60 * 60)
    );

    if (urlError) {
      return '';
    }

    return data.signedUrl;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const downloadMedia = useCallback(async (chatId, filename) => {
    const { data, error: urlError } = await makeAPICall((apiClient) =>
      apiClient.storage.from('chats').download(`${chatId}/${filename}`)
    );

    if (urlError) {
      console.error({ urlError });
      return '';
    }

    return data;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const memoizedValue = useMemo(() => {
    const chatsWithParticipants = conversations
      .filter((chat) => chat.totalMessages > 0)
      .map((chat) => ({
        ...chat,
        messages: sortBy(chat.messages, 'createdAt', 'desc'),
      }))
      .map((chat) => ({
        ...chat,
        participants: chat.participants.map((participantId) => ({
          id: participantId,
          ...participants[participantId],
        })),
      }));

    const chatsWithSortedMessages = orderBy(chatsWithParticipants, 'messages[0].createdAt', 'desc');
    const byId = keyBy(chatsWithSortedMessages, 'id');
    const currentActiveConversation = byId?.[activeConversationId];
    const activeConversation = currentActiveConversation
      ? {
          ...currentActiveConversation,
          participants: currentActiveConversation?.participants?.filter(
            (participant) => participant.id !== representativeUserId
          ),
        }
      : null;

    return {
      representativeUserId,
      conversations: {
        byId,
        data: chatsWithSortedMessages,
        isLoading: conversationLoading,
        error: conversationError,
      },
      participants,
      activeConversation,
      fetchMoreChatMessagesFor,
      createConversation,
      getSignedUrlForMedia,
      addNewMessage,
      scrollToBottom,
      downloadMedia,
      scrollRef,
      lastMessageFetchAction,
      getInitialConversations,
      markChatAsRead,
      markMessageAsUnRead,
    };
  }, [
    conversations,
    activeConversationId,
    conversationLoading,
    conversationError,
    participants,
    representativeUserId,
    lastMessageFetchAction,
    fetchMoreChatMessagesFor,
    getInitialConversations,
    createConversation,
    getSignedUrlForMedia,
    addNewMessage,
    scrollToBottom,
    downloadMedia,
    markChatAsRead,
    markMessageAsUnRead,
  ]);

  // Get user details for receiver
  useEffect(() => {
    if (!receiverId) {
      return;
    }

    if (participants[receiverId]) {
      return;
    }

    getUserDetailsFor(receiverId);
  }, [getUserDetailsFor, participants, receiverId]);

  // Subscribe to chat changes
  useEffect(() => {
    if (representativeUserId && !chatChannel.current) {
      subscribeToChatChanges();
    }

    return () => {
      if (chatChannel?.current) {
        console.log('unsubscribe chatChannel');
        console.log(chatChannel.current.presenceState());
        chatChannel.current.untrack();
        chatChannel.current.unsubscribe();
        dbClient.removeChannel(chatChannel.current);
        chatChannel.current = null;
      }
      console.warn('Remove apiClient subscription by useEffect unmount');
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [userStatus, subscribeToChatChanges, representativeUserId, accessToken]);

  // Scroll to bottom when conversation changes
  useEffect(() => {
    if (!activeConversationId) {
      return;
    }

    markChatAsRead(activeConversationId);
    scrollToBottom();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [activeConversationId]);

  return <ChatContext.Provider value={memoizedValue}>{children}</ChatContext.Provider>;
}

ChatProvider.propTypes = {
  children: PropTypes.node,
};
