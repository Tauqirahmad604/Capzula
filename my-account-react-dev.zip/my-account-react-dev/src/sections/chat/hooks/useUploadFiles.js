import { useState } from 'react';

import { useChatContext } from './use-chat-context';

const permittedMimeTypes = [
  'image/jpeg',
  'image/gif',
  'image/png',
  'application/pdf',
  'image/x-eps',
];

function useUploadFile(chatId) {
  const { errors, setErrors } = useState();
  const { dbClient } = useChatContext();

  async function uploadFile(file) {
    if (!permittedMimeTypes.includes(file.type)) {
      setErrors(['File type not permitted']);
      return null;
    }

    const fileNames = file.name;

    const { data, error } = await dbClient.storage
      .from('chats')
      .upload(`${chatId}/${fileNames}`, file, {
        cacheControl: '3600',
        upsert: false,
      });

    if (error) {
      setErrors([error.message]);
    }

    return data;
  }

  async function uploadFiles(files) {
    const uploadPromises = Array.from(files).map((file) => uploadFile(file));

    const results = await Promise.all(uploadPromises);

    const uploadErrors = results.filter((result) => result.error);

    if (uploadErrors.length > 0) {
      setErrors(uploadErrors.map((error) => error.message));
    }

    return results;
  }

  return {
    uploadFile,
    uploadFiles,
    errors,
  };
}

export default useUploadFile;
