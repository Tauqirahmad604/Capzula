// ----------------------------------------------------------------------

const messageExcerpt = (message) => {
  switch (message.contentType) {
    case 'image':
      return 'Sent a photo';
    case 'file':
      return 'Sent a file';
    default:
      return message.body;
  }
};

export default function useGetNavItem({ currentUserId, conversation }) {
  const { messages, participants } = conversation;

  const participantsInConversation = participants.filter(
    (participant) => participant.id !== currentUserId
  );

  const lastMessage = messages[messages.length - 1];

  const group = participantsInConversation.length > 1;

  const displayName = participantsInConversation.map((participant) => participant.name).join(', ');
  const avatarUrl = participantsInConversation.map((participant) => participant.avatarUrl).join(', ');

  // const hasOnlineInGroup = group
  //   ? participantsInConversation.map((item) => item.status).includes('online')
  //   : false;

  let displayText = '';

  if (lastMessage) {
    const sender = lastMessage.senderId === currentUserId ? 'You: ' : '';

    const message = messageExcerpt(lastMessage);

    displayText = `${sender}${message}`;
  }

  return {
    group,
    displayName,
    avatarUrl,
    displayText,
    participants: participantsInConversation,
    lastActivity: lastMessage.createdAt,
    hasOnlineInGroup: false,
  };
}
