import { useEffect } from 'react';

import { paths } from 'src/routes/paths';
import { useRouter, useSearchParams } from 'src/routes/hooks';

import { useChatContext } from './use-chat-context';

export default function useCheckConversationExist() {
  const { conversations } = useChatContext();
  const router = useRouter();
  const searchParams = useSearchParams();
  const sendToId = searchParams.get('to') || '';

  // If conversation exists with user, redirect to that conversation
  useEffect(() => {
    if (!sendToId) {
      return;
    }

    if (!conversations) {
      return;
    }

    const conversationExists = Object.values(conversations.byId).find((conversation) => {
      if (conversation.type === 'ONE_TO_ONE') {
        const participant = conversation.participants.find((p) => p.id === sendToId);

        return !!participant;
      }

      return false;
    });

    if (conversationExists) {
      router.push(`${paths.chats.root}?id=${conversationExists.id}`);
    }
  }, [conversations, conversations.byId, router, sendToId]);
}
