import { useEffect, useCallback } from 'react';

import { fetchActions } from '../constants';
import { useChatContext } from './use-chat-context';

export default function useMessagesScroll(messages, chatId) {
  const {
    fetchMoreChatMessagesFor,
    scrollToBottom,
    scrollRef,
    lastMessageFetchAction,
    markChatAsRead,
    markMessageAsUnRead,
    representativeUserId,
  } = useChatContext();

  const handleScroll = useCallback(
    async ({ target }) => {
      if (target.scrollHeight - target.scrollTop <= target.clientHeight + 1) {
        markChatAsRead(chatId);
      } else {
        // setIsOnBottom(false);
      }

      //* Load more messages when reaching top
      if (target.scrollTop === 0) {
        await fetchMoreChatMessagesFor(chatId);
      }
    },
    [chatId, fetchMoreChatMessagesFor, markChatAsRead]
  );

  useEffect(() => {
    const scrollElement = scrollRef.current;

    if (scrollElement) {
      scrollElement.addEventListener('scroll', handleScroll);
    }

    return () => {
      scrollElement.removeEventListener('scroll', handleScroll);
    };
  }, [handleScroll, scrollRef]);

  useEffect(() => {
    if (!messages?.length) return;

    const latestMessage = messages[messages.length - 1];

    if (lastMessageFetchAction === fetchActions.FETCH_MORE) {
      scrollRef.current.scrollTop = 100;
      return;
    }

    if (lastMessageFetchAction === fetchActions.ADD_NEW) {
      if (latestMessage?.senderId === representativeUserId) {
        console.log('scrolling to bottom');
        scrollToBottom();
      } else {
        markMessageAsUnRead(chatId);
      }
    }

    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [lastMessageFetchAction, messages?.length, representativeUserId]);

  useEffect(() => {
    if (!messages?.length) return;
    // scroll to the bottom when messages are loaded for the first time
    if (lastMessageFetchAction === fetchActions.INITIAL) {
      scrollToBottom();
    }
  }, [messages?.length, lastMessageFetchAction, scrollToBottom]);

  return {
    scrollRef,
  };
}
