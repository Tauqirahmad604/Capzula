import PropTypes from 'prop-types';
import { useState, useEffect, useCallback } from 'react';

import Box from '@mui/material/Box';
import Chip from '@mui/material/Chip';
import { Skeleton } from '@mui/material';

import Iconify from 'src/components/iconify';

import { contentTypes } from './constants';
import { useChatContext } from './hooks/use-chat-context';

export default function ChatFile({
  conversationId,
  fileName,
  contentType,
  onClick,
  onLoad: addToSlides,
}) {
  const { getSignedUrlForMedia, downloadMedia } = useChatContext();
  const [isLoading, setIsLoading] = useState(true);
  const [signedUrl, setSignedUrl] = useState(null);
  const [downloadUrl, setDownloadUrl] = useState(null);
  const [error, setError] = useState(null);

  const handleError = useCallback((err) => {
    console.error(err);
    setError(err);
    setIsLoading(false);
  }, []);

  const handleClick = useCallback(async () => {
    if (contentType === contentTypes.IMAGE) {
      onClick(signedUrl);
    } else {
      onClick(downloadUrl);
    }
  }, [contentType, downloadUrl, onClick, signedUrl]);

  useEffect(() => {
    if (contentType === contentTypes.IMAGE) {
      getSignedUrlForMedia(conversationId, fileName)
        .then((res) => {
          setSignedUrl(res);
          setIsLoading(false);
        })
        .catch(handleError);
    } else {
      downloadMedia(conversationId, fileName)
        .then((blob) => {
          const urlFromBlob = URL.createObjectURL(blob);
          setDownloadUrl(urlFromBlob);
          setIsLoading(false);
        })
        .catch(handleError);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  if (isLoading) {
    return (
      <Skeleton
        variant="rectangular"
        width={220}
        height={220}
        sx={{
          borderRadius: 1.5,
        }}
      />
    );
  }

  if (error) {
    return (
      <Box
        sx={{
          width: 220,
          minHeight: 220,
          borderRadius: 1.5,
          bgcolor: 'background.neutral',
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          justifyContent: 'center',
        }}
      >
        <Iconify icon="ic:outline-broken-image" width={80} />
        <Chip variant="outlined" label="File not found" size="small" />
      </Box>
    );
  }

  if (contentType === contentTypes.IMAGE) {
    return (
      <Box
        component="img"
        alt="attachment"
        src={signedUrl}
        loading="lazy"
        onClick={handleClick}
        onError={handleError}
        onLoad={() => {
          addToSlides(signedUrl);
        }}
        sx={{
          objectFit: 'cover',
          minHeight: 220,
          borderRadius: 1.5,
          cursor: 'pointer',
          '&:hover': {
            opacity: 0.9,
          },
        }}
      />
    );
  }

  return (
    <Box
      title={fileName}
      onClick={handleClick}
      sx={{
        width: 220,
        minHeight: 220,
        borderRadius: 1.5,
        cursor: 'pointer',
        bgcolor: 'background.neutral',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
      }}
    >
      <Iconify icon="iwwa:file-pdf" width={80} />
      <Chip variant="outlined" label={fileName} size="small" />
    </Box>
  );
}

ChatFile.propTypes = {
  conversationId: PropTypes.string,
  fileName: PropTypes.string,
  onClick: PropTypes.func,
  onLoad: PropTypes.func,
  contentType: PropTypes.string,
};
