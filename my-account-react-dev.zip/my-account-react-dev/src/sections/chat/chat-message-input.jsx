import PropTypes from 'prop-types';
import { useRef, useMemo, useState, useCallback } from 'react';

import Box from '@mui/material/Box';
import Stack from '@mui/material/Stack';
import InputBase from '@mui/material/InputBase';
import IconButton from '@mui/material/IconButton';

import { paths } from 'src/routes/paths';
import { useRouter } from 'src/routes/hooks';

import uuidv4 from 'src/utils/uuidv4';

import { trl } from 'src/locales/i18n';

import Iconify from 'src/components/iconify';
import MultiFilePreview from 'src/components/upload/preview-multi-file';

import { fileToBase64 } from './utils';
import { contentTypes } from './constants';
import { useChatContext } from './hooks/use-chat-context';

// ----------------------------------------------------------------------

const permittedMimeTypes = [
  'image/jpeg',
  'image/gif',
  'image/png',
  'application/pdf',
  'image/x-eps',
];

export default function ChatMessageInput({
  recipients,
  presetMessage,
  // onAddRecipients,
  disabled,
  conversationId,
}) {
  // const { user } = useAuthContext();
  const { addNewMessage, createConversation, representativeUserId, markChatAsRead } =
    useChatContext();
  const router = useRouter();

  const fileRef = useRef(null);

  const [message, setMessage] = useState(presetMessage);
  const [files, setFiles] = useState({});
  const [submitting, setSubmitting] = useState(false);

  const messageData = useMemo(() => {
    const attachments = Object.values(files);

    return {
      id: uuidv4(),
      attachments,
      body: message?.trim(),
      contentType: attachments.length > 0 ? contentTypes.MEDIA : contentTypes.TEXT,
      senderId: representativeUserId,
      receiverId: recipients?.filter((recipient) => recipient.id !== representativeUserId)?.[0]?.id,
    };
  }, [files, message, recipients, representativeUserId]);

  const conversationData = useMemo(() => {
    const participants = recipients.map((recipient) => recipient.id);

    return {
      id: uuidv4(),
      messages: [messageData],
      participants: [...participants, representativeUserId],
      type: recipients.length > 1 ? 'GROUP' : 'ONE_TO_ONE',
      unreadCount: 0,
    };
  }, [messageData, recipients, representativeUserId]);

  const handleAttach = useCallback(() => {
    if (fileRef.current) {
      fileRef.current.click();
    }
  }, []);

  const handleFileChange = useCallback((event) => {
    const filesPreviews = Array.from(event.target.files).map(async (file) => {
      const preview = await fileToBase64(file);

      return { preview, file };
    });

    Promise.all(filesPreviews).then((previews) => {
      setFiles((prevFiles) => ({
        ...prevFiles,
        ...previews.reduce((acc, { preview, file }) => {
          acc[preview] = {
            name: file.name,
            type: file.type,
            preview,
            size: file.size,
            path: file.path,
            lastModified: file.lastModified,
            lastModifiedDate: file.lastModifiedDate,
            file,
          };
          return acc;
        }, {}),
      }));
    });
  }, []);

  const handleRemoveFile = useCallback((file) => {
    setFiles((prevFiles) => {
      const newFiles = { ...prevFiles };
      delete newFiles[file.preview];
      return newFiles;
    });
  }, []);

  const handleChangeMessage = useCallback((event) => {
    setMessage(event.target.value);
  }, []);

  const submitMessage = useCallback(async () => {
    if (submitting) {
      return;
    }
    setSubmitting(true);
    try {
      if (conversationId) {
        await addNewMessage(conversationId, messageData);
      } else {
        const res = await createConversation(conversationData);
        router.push(`${paths.chats.root}?id=${res.conversation.id}`);
      }
    } catch (error) {
      console.error(error);
    } finally {
      setMessage('');
      setFiles({});
      fileRef.current.value = null;
      setSubmitting(false);
    }
  }, [
    submitting,
    conversationId,
    addNewMessage,
    messageData,
    createConversation,
    conversationData,
    router,
  ]);

  const handleNewLine = useCallback((event) => {
    if (!event.shiftKey && event.key === 'Enter') {
      event.preventDefault();
      event.stopPropagation();
    }
  }, []);

  const handleSendMessage = useCallback(
    (event) => {
      if ((!event.shiftKey && event.key === 'Enter') || event.type === 'click') {
        submitMessage();
      }
    },
    [submitMessage]
  );

  return (
    <>
      <Box
        sx={{
          pl: 2.5,
        }}
      >
        <MultiFilePreview files={Object.values(files)} onRemove={handleRemoveFile} thumbnail />
      </Box>
      <InputBase
        value={message}
        multiline
        onKeyDown={handleNewLine}
        onKeyUp={handleSendMessage}
        onChange={handleChangeMessage}
        placeholder={trl('Chat.type_a_message')}
        disabled={disabled}
        onFocus={() => {
          markChatAsRead(conversationId);
        }}
        startAdornment={
          <Stack direction="row" sx={{ flexShrink: 0, mr: 1.5 }}>
            <IconButton onClick={handleAttach} disabled={submitting}>
              <Iconify icon="solar:gallery-add-bold" />
            </IconButton>
            <IconButton onClick={handleAttach} disabled={submitting}>
              <Iconify icon="eva:attach-2-fill" />
            </IconButton>
          </Stack>
        }
        endAdornment={
          <Stack direction="row" sx={{ flexShrink: 0 }}>
            <IconButton type="submit" onClick={handleSendMessage} disabled={submitting}>
              {submitting ? (
                <Iconify icon="line-md:loading-loop" />
              ) : (
                <Iconify icon="ic:outline-send" />
              )}
            </IconButton>
          </Stack>
        }
        sx={{
          px: 1,
          height: 56,
          flexShrink: 0,
          borderTop: (theme) => `solid 1px ${theme.palette.divider}`,
        }}
      />

      <input
        type="file"
        ref={fileRef}
        style={{ display: 'none' }}
        multiple
        disabled={submitting}
        onChange={handleFileChange}
        accept={permittedMimeTypes.join(',')}
      />
    </>
  );
}

ChatMessageInput.propTypes = {
  disabled: PropTypes.bool,
  // onAddRecipients: PropTypes.func,
  recipients: PropTypes.array,
  presetMessage: PropTypes.string,
  conversationId: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
};
