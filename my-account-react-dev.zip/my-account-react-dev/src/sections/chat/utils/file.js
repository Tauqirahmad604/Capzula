/**
 * @param {File} file
 * @returns {Promise<string>}
 */
export function fileToBase64(file) {
  return new Promise((resolve) => {
    const reader = new FileReader();
    // Read file content on file loaded event
    reader.onloadend = (event) => {
      resolve(event.target.result);
    };

    // Convert data to base64
    reader.readAsDataURL(file);
  });
}

/**
 * @param {string} url
 * @param {string} fileName
 */
export const handleFileDownload = (url, fileName) => {
  if (!document) return;
  // window.open(url, '_blank')
  const link = document.createElement('a');
  link.download = fileName;

  link.href = url;
  link.target = '_blank';

  link.click();
};
