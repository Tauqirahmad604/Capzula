export const contentTypes = {
  TEXT: 'text',
  MEDIA: 'media',
  IMAGE: 'image',
  FILE: 'file',
};

export const fetchActions = {
  INITIAL: 'INITIAL',
  ADD_NEW: 'ADD_NEW',
  FETCH_MORE: 'FETCH_MORE',
};
