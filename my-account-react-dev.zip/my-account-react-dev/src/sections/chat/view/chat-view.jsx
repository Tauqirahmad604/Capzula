import { useNavigate } from 'react-router';
import { useEffect, useCallback } from 'react';

import Card from '@mui/material/Card';
import { Alert } from '@mui/material';
import Stack from '@mui/material/Stack';
import Container from '@mui/material/Container';
import Typography from '@mui/material/Typography';
import IconButton from '@mui/material/IconButton';

import { paths } from 'src/routes/paths';
import { RouterLink } from 'src/routes/components';
import { useRouter, useSearchParams } from 'src/routes/hooks';

import Iconify from 'src/components/iconify/iconify';
import { useSettingsContext } from 'src/components/settings';

import ChatNav from '../chat-nav';
import ChatMessageList from '../chat-message-list';
import ChatMessageInput from '../chat-message-input';
import ChatHeaderDetail from '../chat-header-detail';
import { useCheckConversationExist } from '../hooks';
import { useChatContext } from '../hooks/use-chat-context';

// ----------------------------------------------------------------------

export default function ChatView() {
  const router = useRouter();
  const { conversations, activeConversation, participants, getInitialConversations } =
    useChatContext();
  const settings = useSettingsContext();
  const searchParams = useSearchParams();
  const sendToId = searchParams.get('to') || '';
  const presetMessage = searchParams.get('message') || '';
  const navigate = useNavigate();
  // const selectedConversationId = searchParams.get('id') || '';
  // const [recipients, setRecipients] = useState([]);
  // const { contacts } = useGetContacts();
  // console.log('activeConversation', activeConversation);

  // Get initial chats and scroll to bottom
  useEffect(() => {
    getInitialConversations();
  }, [getInitialConversations]);

  // If no conversation exists, redirect to chat
  useEffect(() => {
    if (conversations.error) {
      router.push(paths.chats.root);
    }
  }, [conversations.error, router]);

  // If conversation exists with user, redirect to that conversation
  useCheckConversationExist();

  // const handleAddRecipients = useCallback((selected) => {
  //   setRecipients(selected);
  // }, []);

  const activeConversationParticipants = useCallback(() => {
    if (activeConversation) {
      return activeConversation.participants;
    }

    if (participants[sendToId]) {
      return [{ ...participants[sendToId], id: sendToId }];
    }

    return [];
  }, [activeConversation, participants, sendToId]);

  const renderHead = () => (
    <Stack
      direction="row"
      alignItems="center"
      flexShrink={0}
      sx={{ pr: 1, pl: 2.5, py: 1, minHeight: 72 }}
    >
      <ChatHeaderDetail participants={activeConversationParticipants()} />
      {/* <ChatHeaderCompose contacts={[]} onAddRecipients={handleAddRecipients} /> */}
    </Stack>
  );
  // conversations

  const renderNav = (
    <ChatNav
      contacts={[]}
      conversations={conversations.data}
      loading={conversations.isLoading}
      selectedConversationId={activeConversation?.id}
    />
  );
  const isFrameless = window.self !== window.top;

  const renderMessages = () => {
    let isDisabled = true;

    if (activeConversation) {
      isDisabled = false;
    } else if (sendToId) {
      isDisabled = false;
    }

    return (
      <Stack
        sx={{
          width: 1,
          height: 1,
          overflow: 'hidden',
        }}
      >
        {conversations.error && <Alert severity="error">{conversations.error}</Alert>}
        <ChatMessageList
          conversationId={activeConversation?.id}
          messages={activeConversation?.messages}
          participants={activeConversation?.participants}
        />

        <ChatMessageInput
          presetMessage={presetMessage}
          // recipients={recipients}
          // onAddRecipients={handleAddRecipients}
          conversationId={activeConversation?.id}
          recipients={activeConversationParticipants()}
          disabled={isDisabled}
        />
      </Stack>
    );
  };

  return (
    <Container maxWidth={settings.themeStretch ? false : 'xl'}>
      {!isFrameless && (
        <Stack direction="row" alignItems="center" spacing={1} sx={{ mb: { xs: 3, md: 5 } }}>
          <IconButton component={RouterLink} onClick={() => navigate(-1)}>
            <Iconify icon="eva:arrow-ios-back-fill" />
          </IconButton>
          <Typography variant="h4">Chats</Typography>
        </Stack>
      )}

      <Stack component={Card} direction="row" sx={{ height: 'calc(100vh - 150px)', mt: 3 }}>
        {renderNav}

        <Stack
          key={activeConversation?.id}
          sx={{
            width: 1,
            height: 1,
            overflow: 'hidden',
          }}
        >
          {renderHead()}

          <Stack
            direction="row"
            sx={{
              width: 1,
              height: 1,
              overflow: 'hidden',
              borderTop: (theme) => `solid 1px ${theme.palette.divider}`,
            }}
          >
            {renderMessages()}

            {/* {activeConversation && <ChatRoom conversation={activeConversation} participants={activeConversation.par} />} */}
          </Stack>
        </Stack>
      </Stack>
    </Container>
  );
}
