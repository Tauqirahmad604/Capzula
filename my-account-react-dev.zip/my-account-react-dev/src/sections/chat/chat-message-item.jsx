import i18n from 'i18next';
import PropTypes from 'prop-types';
import { useDispatch } from 'react-redux';
import { useState, useCallback } from 'react';
import { differenceInSeconds, formatDistanceToNowStrict } from 'date-fns';

import Stack from '@mui/material/Stack';
import Avatar from '@mui/material/Avatar';
import Button from '@mui/material/Button';
import Typography from '@mui/material/Typography';

import { trl } from 'src/locales/i18n';
import { translate } from 'src/google-translate';
import { setMessageTranslation } from 'src/redux/chats';

import Iconify from 'src/components/iconify';

import ChatFile from './chat-file';
import { useGetMessage } from './hooks';
import { contentTypes } from './constants';
import { handleFileDownload } from './utils';
import { useChatContext } from './hooks/use-chat-context';

// ----------------------------------------------------------------------

export default function ChatMessageItem({
  conversationId,
  message,
  participants,
  onOpenLightbox,
  onLoad,
}) {
  const currentLanguage = i18n.language || window.localStorage.i18nextLng;
  const dispatch = useDispatch();
  const [showTranslation, setShowTranslation] = useState(false);
  const { representativeUserId } = useChatContext();
  const { me, senderDetails, hasMedia } = useGetMessage({
    conversationId,
    message,
    participants,
    currentUserId: `${representativeUserId}`,
  });
  const { firstName, avatarUrl } = senderDetails;
  const { id, body, translatedBody, createdAt, contentType } = message;
  const sentDate = new Date(createdAt);
  const messageBody = showTranslation ? translatedBody : body;

  const handleMediaClick = useCallback(
    (url) => {
      if (contentType === contentTypes.IMAGE) {
        onOpenLightbox(url);
      } else {
        handleFileDownload(url, body);
      }
    },
    [body, contentType, onOpenLightbox]
  );

  const translateMessage = useCallback(async () => {
    try {
      if (showTranslation) {
        setShowTranslation(false);
        return;
      }

      if (translatedBody) {
        setShowTranslation(true);
        return;
      }

      // Todo: get the language from the user's profile
      const translation = await translate(body, { to: currentLanguage });
      dispatch(
        setMessageTranslation({
          conversationId,
          messageId: id,
          translation,
        })
      );
      setShowTranslation(true);
    } catch (error) {
      setShowTranslation(false);
    }
  }, [body, conversationId, currentLanguage, dispatch, id, showTranslation, translatedBody]);

  const renderInfo = (
    <Typography
      noWrap
      variant="caption"
      sx={{
        mb: 1,
        color: 'text.disabled',
        ...(!me && {
          mr: 'auto',
        }),
      }}
    >
      {!me && `${firstName},`} &nbsp;
      {differenceInSeconds(new Date(), sentDate) < 10
        ? 'now'
        : formatDistanceToNowStrict(sentDate, {
            addSuffix: true,
          })}
    </Typography>
  );

  const renderBody = (
    <Stack
      sx={{
        p: 1.5,
        minWidth: 48,
        maxWidth: 320,
        borderRadius: 1,
        typography: 'body2',
        bgcolor: 'background.neutral',
        ...(me && {
          color: 'grey.800',
          bgcolor: 'primary.lighter',
        }),
        ...(hasMedia && {
          p: 0,
          bgcolor: 'transparent',
        }),
      }}
    >
      {hasMedia ? (
        <ChatFile
          onClick={handleMediaClick}
          onLoad={onLoad}
          conversationId={conversationId}
          fileName={body}
          contentType={contentType}
        />
      ) : (
        messageBody
      )}
    </Stack>
  );

  const renderActions = (
    <Stack
      direction="row"
      className="message-actions"
      sx={{
        pt: 0.5,
        // bottom: '100%',
        left: 0,
        // position: 'absolute',
        transition: (theme) =>
          theme.transitions.create(['opacity'], {
            duration: theme.transitions.duration.shorter,
          }),
        ...(me && {
          left: 'unset',
          right: 0,
        }),
      }}
    >
      {/* <IconButton size="small">
        <Iconify icon="solar:reply-bold" width={16} />
      </IconButton> */}
      {!me && (
        <Button
          sx={{
            border: 'none',
            p: 0,
            fontWeight: '500',
            '&:hover': {
              border: 'none',
              backgroundColor: 'transparent',
              boxShadow: 'none',
            },
          }}
          variant="outlined"
          startIcon={<Iconify icon="mdi:translate-variant" width={20} />}
          size="small"
          onClick={translateMessage}
        >
          {trl('Global.translate')}
        </Button>
      )}
      {/* <IconButton size="small">
        <Iconify icon="solar:trash-bin-trash-bold" width={16} />
      </IconButton> */}
    </Stack>
  );

  return (
    <Stack direction="row" justifyContent={me ? 'flex-end' : 'unset'} sx={{ mb: 5 }}>
      {!me && <Avatar alt={firstName} src={avatarUrl} sx={{ width: 32, height: 32, mr: 2 }} />}

      <Stack alignItems={me ? 'flex-end' : 'unset'}>
        <Stack
          // direction="row"
          sx={{
            position: 'relative',
            '&:hover': {
              '& .message-actions': {
                opacity: 1,
              },
            },
          }}
        >
          {renderBody}
          {renderActions}
        </Stack>
        {renderInfo}
      </Stack>
    </Stack>
  );
}

ChatMessageItem.propTypes = {
  conversationId: PropTypes.string,
  message: PropTypes.object,
  onOpenLightbox: PropTypes.func,
  onLoad: PropTypes.func,
  participants: PropTypes.array,
};
