import PropTypes from 'prop-types';
import 'yet-another-react-lightbox/styles.css';
import 'yet-another-react-lightbox/plugins/thumbnails.css';

import Box from '@mui/material/Box';

import Scrollbar from 'src/components/scrollbar';
import Lightbox, { useLightBox } from 'src/components/lightbox';

import { useMessagesScroll } from './hooks';
import ChatMessageItem from './chat-message-item';

// ----------------------------------------------------------------------

export default function ChatMessageList({ messages = [], participants, conversationId }) {
  const { scrollRef } = useMessagesScroll(messages, conversationId);
  const lightbox = useLightBox();

  return (
    <>
      <Scrollbar ref={scrollRef} sx={{ px: 3, py: 5, height: 1 }}>
        <Box>
          {messages.map((message) => (
            <ChatMessageItem
              key={message.id}
              message={message}
              conversationId={conversationId}
              participants={participants}
              onLoad={(url) => {
                lightbox.addToSlides({ src: url });
              }}
              onOpenLightbox={(url) => {
                lightbox.onOpen(url);
              }}
            />
          ))}
        </Box>
      </Scrollbar>

      <Lightbox
        index={lightbox.selected}
        slides={lightbox.slides}
        open={lightbox.open}
        close={lightbox.onClose}
        disabledZoom
        disabledVideo
        disabledTotal
        disabledCaptions
        disabledSlideshow
        disabledThumbnails
        // disabledFullscreen,
      />
    </>
  );
}

ChatMessageList.propTypes = {
  messages: PropTypes.array,
  participants: PropTypes.array,
  conversationId: PropTypes.string,
};
