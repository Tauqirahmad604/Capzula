import Grid from '@mui/material/Unstable_Grid2';
import Container from '@mui/material/Container';

import { trl } from 'src/locales/i18n';
import { useGetNotificationsQuery, useGetImportantNotificationsQuery } from 'src/redux/api/myAccount';

import { useSettingsContext } from 'src/components/settings';

import DashboardNotificationsTable from 'src/sections/dashboard/dash-needs-attention-table';

import AnalyticsWebsiteVisits from '../analytics-website-visits';
import AnalyticsWidgetSummary from '../analytics-widget-summary';

// ----------------------------------------------------------------------

export default function OverviewAnalyticsView() {
  const settings = useSettingsContext();
  const {
    data: urgentNotifications,
    isLoading: urgentNotificationsLoading,
    isFetching: urgentNotificationsFetching,
    // isError,
  } = useGetImportantNotificationsQuery();

  const {
    data: notifications,
    isLoading: notificationsLoading,
    isFetching: notificationsFetching,
  } = useGetNotificationsQuery();

  return (
    <Container maxWidth={settings.themeStretch ? false : 'xl'}>
      <Grid container spacing={4}>
        <Grid xs={12} sm={6} md={4}>
          {/* <EcommerceWidgetSummary
            title="New Orders"
            percent={2.6}
            total={24}
            chart={{
              series: [22, 8, 35, 50, 82, 84, 77, 12, 87, 43],
            }}
          />

          <EcommerceWidgetSummary
            title="New Orders"
            percent={2.6}
            total={24}
            chart={{
              series: [22, 8, 35, 50, 82, 84, 77, 12, 87, 43],
            }}
          /> */}

          <AnalyticsWidgetSummary
            title="Home.new_orders"
            total={4}
            color="info"
            buttonCta="Home.view_orders"
          // icon={<img alt="icon" src="/assets/icons/glass/ic_glass_bag.png" />}
          />
        </Grid>

        <Grid xs={12} sm={6} md={4}>
          <AnalyticsWidgetSummary
            title="Home.awaiting_fulfillment"
            total={6}
            color="warning"
            buttonCta="Home.view_orders"

          // icon={<img alt="icon" src="/assets/icons/glass/ic_glass_buy.png" />}
          />
        </Grid>

        <Grid xs={12} sm={6} md={4}>
          <AnalyticsWidgetSummary
            title="Home.delayed_orders"
            total={1}
            color="error"
            buttonCta="Home.view_orders"
          />
        </Grid>

        <Grid xs={12} md={12} lg={12}>
          <DashboardNotificationsTable
            title="Urgent Notifications"
            notifications={urgentNotifications}
            isLoading={urgentNotificationsLoading || urgentNotificationsFetching}
          />
        </Grid>
        
        <Grid xs={12} md={12} lg={12}>
          <DashboardNotificationsTable
            title="Notifications"
            notifications={notifications}
            isLoading={notificationsLoading || notificationsFetching}
          />
        </Grid>
        
        <Grid xs={12} md={12} lg={12}>
          <AnalyticsWebsiteVisits
            title={trl('Home.orders_this_week')}
            // subheader="(+43%) than last year"
            chart={{
              labels: [
                '01/08/2023',
                '01/09/2023',
                '01/10/2023',
                '01/11/2023',
                '01/12/2023',
                '01/13/2023',
                '01/14/2023',
              ],
              series: [
                {
                  name: trl('Home.new_orders'),
                  type: 'area',
                  fill: 'gradient',
                  data: [23, 11, 22, 27, 13, 22, 37],
                },
                // {
                //   name: 'Fulfilled Orders',
                //   type: 'area',
                //   fill: 'gradient',
                //   data: [44, 55, 41, 67, 22, 43, 21],
                // },
                // {
                //   name: 'Revenue ($)',
                //   type: 'line',
                //   fill: 'solid',
                //   data: [3000, 2500, 3600, 3000, 4500, 3500, 6400],
                // },
              ],
            }}
          />
        </Grid>

        {/* <Grid xs={12} md={6} lg={4}>
          <AnalyticsCurrentVisits
            title="Current Visits"
            chart={{
              series: [
                { label: 'America', value: 4344 },
                { label: 'Asia', value: 5435 },
                { label: 'Europe', value: 1443 },
                { label: 'Africa', value: 4443 },
              ],
            }}
          />
        </Grid> */}
        {/* 
        <Grid xs={12} md={6} lg={8}>
          <AnalyticsConversionRates
            title="Conversion Rates"
            subheader="(+43%) than last year"
            chart={{
              series: [
                { label: 'Italy', value: 400 },
                { label: 'Japan', value: 430 },
                { label: 'China', value: 448 },
                { label: 'Canada', value: 470 },
                { label: 'France', value: 540 },
                { label: 'Germany', value: 580 },
                { label: 'South Korea', value: 690 },
                { label: 'Netherlands', value: 1100 },
                { label: 'United States', value: 1200 },
                { label: 'United Kingdom', value: 1380 },
              ],
            }}
          />
        </Grid> */}
        {/* 
        <Grid xs={12} md={6} lg={4}>
          <AnalyticsCurrentSubject
            title="Current Subject"
            chart={{
              categories: ['English', 'History', 'Physics', 'Geography', 'Chinese', 'Math'],
              series: [
                { name: 'Series 1', data: [80, 50, 30, 40, 100, 20] },
                { name: 'Series 2', data: [20, 30, 40, 80, 20, 80] },
                { name: 'Series 3', data: [44, 76, 78, 13, 43, 10] },
              ],
            }}
          />
        </Grid>

        <Grid xs={12} md={6} lg={8}>
          <AnalyticsNews title="News" list={_analyticPosts} />
        </Grid>

        <Grid xs={12} md={6} lg={4}>
          <AnalyticsOrderTimeline title="Order Timeline" list={_analyticOrderTimeline} />
        </Grid>

        <Grid xs={12} md={6} lg={4}>
          <AnalyticsTrafficBySite title="Traffic by Site" list={_analyticTraffic} />
        </Grid>

        <Grid xs={12} md={6} lg={8}>
          <AnalyticsTasks title="Tasks" list={_analyticTasks} />
        </Grid> */}
      </Grid>
    </Container>
  );
}
