import PropTypes from 'prop-types';
import { useSnackbar } from 'notistack';
import { useState, useEffect } from 'react';
import { useElements, AddressElement } from '@stripe/react-stripe-js';

import { Stack } from '@mui/system';
import Button from '@mui/material/Button';
import Dialog from '@mui/material/Dialog';
import { Input, InputLabel } from '@mui/material';
import LoadingButton from '@mui/lab/LoadingButton';
import DialogTitle from '@mui/material/DialogTitle';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';

import { useBoolean } from 'src/hooks/use-boolean';

import { useAuthContext } from 'src/auth/hooks';
import { useUpdateDeliveryAddressMutation } from 'src/redux/api/myAccount';

// ----------------------------------------------------------------------

export default function AddressUpdateForm({ open, onClose, currentAddress }) {
  const { refresh } = useAuthContext();
  const elements = useElements();
  const { enqueueSnackbar } = useSnackbar();
  const [address, setAddress] = useState({
    line1: currentAddress.address_1,
    line2: currentAddress.address_2,
    city: currentAddress.city,
    state: currentAddress.state,
    postal_code: currentAddress.postcode,
    country: currentAddress.country,
  });
  const [name, setName] = useState(`${currentAddress.first_name} ${currentAddress.last_name}`);
  const [phone, setPhone] = useState(currentAddress.phone);
  const [company, setCompany] = useState(currentAddress.company);
  const isLoading = useBoolean();

  const [updateDeliveryAddress, updateDeliveryAddressResult] = useUpdateDeliveryAddressMutation();

  const handleClose = () => {
    const addressElement = elements.getElement('address');
    setAddress({});
    setName(null);
    setPhone(null);
    setCompany(null);
    addressElement.clear();

    setTimeout(() => {
      onClose();
    }, 1);
  };

  const handleUpdateAddress = () => {
    if (!address) {
      enqueueSnackbar('Please enter address', { variant: 'error' });
      return;
    }
    if (!name) {
      enqueueSnackbar('Please enter name', { variant: 'error' });
      return;
    }
    if (!phone) {
      enqueueSnackbar('Please enter phone number', { variant: 'error' });
      return;
    }

    updateDeliveryAddress({
      body: {
        id: currentAddress.id,
        address,
        phone,
        name,
        company,
      },
    });

    isLoading.onTrue();
  };

  useEffect(() => {
    if (updateDeliveryAddressResult.isSuccess) {
      isLoading.onFalse();
      enqueueSnackbar(updateDeliveryAddressResult.data.data, { variant: 'success' });
      refresh();
      handleClose();
    }
    if (updateDeliveryAddressResult.isError) {
      enqueueSnackbar(updateDeliveryAddressResult.error.data.data, { variant: 'error' });
      isLoading.onFalse();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [updateDeliveryAddressResult]);

  return (
    <Dialog fullWidth maxWidth="sm" open={open} onClose={() => handleClose()}>
      <DialogTitle>Update address</DialogTitle>
      <DialogContent>
        <AddressElement
          options={{
            mode: 'billing',
            defaultValues: {
              name,
              address,
            },
          }}
          onChange={(event) => {
            if (event.complete) {
              setAddress(event.value.address);
              setName(event.value.name);
            }
          }}
        />
        <Stack sx={{ mt: 2 }}>
          <InputLabel sx={{ color: '#30313D' }}>Phone Number</InputLabel>
          <Input
            type="number"
            placeholder="123-456-7890"
            onChange={(e) => setPhone(e.target.value)}
            disableUnderline
            value={phone}
            sx={{
              border: '1px solid #e6e6e6',
              borderRadius: '5px',
              padding: '6.5px 12px',
              boxShadow: '0px 1px 1px rgba(0, 0, 0, 0.03), 0px 3px 6px rgba(0, 0, 0, 0.02)',
            }}
          />
        </Stack>
        <Stack sx={{ mt: 2 }}>
          <InputLabel sx={{ color: '#30313D' }}>Company</InputLabel>
          <Input
            type="text"
            placeholder="Capzula Inc"
            onChange={(e) => setCompany(e.target.value)}
            disableUnderline
            value={company}
            sx={{
              border: '1px solid #e6e6e6',
              borderRadius: '5px',
              padding: '6.5px 12px',
              boxShadow: '0px 1px 1px rgba(0, 0, 0, 0.03), 0px 3px 6px rgba(0, 0, 0, 0.02)',
            }}
          />
        </Stack>
      </DialogContent>

      <DialogActions>
        <Button color="inherit" variant="outlined" onClick={() => handleClose()}>
          Cancel
        </Button>

        <LoadingButton
          type="submit"
          variant="contained"
          onClick={() => handleUpdateAddress()}
          loading={updateDeliveryAddressResult.isLoading}
        >
          Update Address
        </LoadingButton>
      </DialogActions>
    </Dialog>
  );
}

AddressUpdateForm.propTypes = {
  onClose: PropTypes.func,
  open: PropTypes.bool,
  currentAddress: PropTypes.object,
};
