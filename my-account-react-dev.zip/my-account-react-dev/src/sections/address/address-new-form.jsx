import * as Yup from 'yup';
import PropTypes from 'prop-types';
import { useSnackbar } from 'notistack';
import { useForm } from 'react-hook-form';
import { useState, useEffect } from 'react';
import { yupResolver } from '@hookform/resolvers/yup';

import { Box, Stack } from '@mui/system';
import Button from '@mui/material/Button';
import Dialog from '@mui/material/Dialog';
import LoadingButton from '@mui/lab/LoadingButton';
import DialogTitle from '@mui/material/DialogTitle';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';

import { useAuthContext } from 'src/auth/hooks';
import {
  useAddDeliveryAddressMutation,
  useUpdateDeliveryAddressMutation,
} from 'src/redux/api/myAccount';

import AddressFields from 'src/components/forms/Address';
import FormProvider from 'src/components/hook-form/form-provider';
import { RHFTelField, RHFTextField } from 'src/components/hook-form';

// ----------------------------------------------------------------------

export function AddressNewFormContent({ open, onClose, isEditing, addressData, checkout }) {
  const [countryStateCodes, setCountryStateCodes] = useState(null);
  const [, setRequiresState] = useState(false);
  const NewAddressSchema = Yup.object().shape({
    firstName: Yup.string().required('First name is required'),
    lastName: Yup.string().required('Last name is required'),
    phone: Yup.string().required('Phone number is required'),
    address: Yup.object().shape({
      address_1: Yup.string().required('Address is required'),
      address_2: Yup.string().nullable(),
      city: Yup.string().required('City is required'),
      postcode: Yup.string().required('Postal code is required'),
      // state: Yup.string().test('isRequired', 'State is required', (value) => {
      //   const statesForCountry = countryStateCodes?.states[formValues.address.country];

      //   // Make state required only when its not an empty array
      //   return statesForCountry?.length > 0 ? !!value : true;
      // }),
      country: Yup.string().required('Country is required'),
      state: Yup.string().required('State is required'),
    }),
    company: Yup.string(),
  });

  const defaultValues = {
    firstName: isEditing ? addressData.first_name : '',
    lastName: isEditing ? addressData.last_name : '',
    phone: isEditing ? addressData.phone : '',
    address: {
      address_1: isEditing ? addressData.address_1 : '',
      address_2: isEditing ? addressData.address_2 : '',
      city: isEditing ? addressData.city : '',
      postcode: isEditing ? addressData.postcode : '',
      state: isEditing ? addressData.state : '',
      country: isEditing ? addressData.country : '',
    },
    company: isEditing ? addressData.company : '',
  };

  const methods = useForm({
    resolver: yupResolver(NewAddressSchema),
    defaultValues,
  });

  const { refresh } = useAuthContext();

  const [addDeliveryAddress, addDeliveryAddressResult] = useAddDeliveryAddressMutation();
  const [updateDeliveryAddress, updateDeliveryAddressResult] = useUpdateDeliveryAddressMutation();

  const { enqueueSnackbar } = useSnackbar();

  const handleClose = () => {
    onClose();
  };

  const {
    handleSubmit,
    formState: { isSubmitting },
    getValues,
    setValue,
  } = methods;

  const formValues = getValues();

  const onSubmit = handleSubmit(async (data) => {
    try {
      if (isEditing) {
        updateDeliveryAddress({
          body: {
            id: addressData.id,
            address: data.address,
            phone: data.phone,
            firstName: data.firstName,
            lastName: data.lastName,
            company: data.company,
          },
        });
      } else {
        addDeliveryAddress({
          body: {
            address: data.address,
            phone: data.phone,
            firstName: data.firstName,
            lastName: data.lastName,
            company: data.company,
          },
        });
      }
      // onClose();
    } catch (e) {
      console.error(e);
    }
  });

  useEffect(() => {
    if (updateDeliveryAddressResult.isSuccess) {
      enqueueSnackbar(updateDeliveryAddressResult.data.data, { variant: 'success' });
      refresh();
      handleClose();
    }
    if (updateDeliveryAddressResult.isError) {
      enqueueSnackbar(updateDeliveryAddressResult.error.data.data, { variant: 'error' });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [updateDeliveryAddressResult]);

  useEffect(() => {
    if (addDeliveryAddressResult.isSuccess) {
      enqueueSnackbar(addDeliveryAddressResult.data.data, { variant: 'success' });
      refresh();
      handleClose();
    }
    if (addDeliveryAddressResult.isError) {
      enqueueSnackbar(addDeliveryAddressResult.error.data.data, { variant: 'error' });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [addDeliveryAddressResult]);

  return (
    <FormProvider methods={methods} onSubmit={onSubmit}>
      <Stack spacing={2} sx={{ pb: 2, pt: 1 }}>
        <Box
          rowGap={2}
          columnGap={2}
          display="grid"
          gridTemplateColumns={{
            xs: 'repeat(1, 1fr)',
            sm: 'repeat(2, 1fr)',
          }}
        >
          <RHFTextField name="firstName" label="First Name" />
          <RHFTextField name="lastName" label="Last Name" />
        </Box>
        <Box>
          <RHFTelField name="phone" label="Phone Number" />
        </Box>
        <Box>
          <RHFTextField name="company" label="Company" />
        </Box>
      </Stack>
      <AddressFields
        formValues={formValues}
        setValue={setValue}
        onCountryStateCodesReceived={(data) => setCountryStateCodes(data)}
        setRequiresState={setRequiresState}
      />

      {checkout ? (
        <LoadingButton
          sx={{ mt: 4 }}
          type="submit"
          size="large"
          color="primary"
          variant="contained"
          fullWidth
          disabled={!countryStateCodes}
          loading={
            addDeliveryAddressResult.isLoading ||
            updateDeliveryAddressResult.isLoading ||
            isSubmitting
          }
        >
          Continue
        </LoadingButton>
      ) : (
        <DialogActions sx={{ px: 0 }}>
          <Button color="inherit" variant="outlined" onClick={() => handleClose()}>
            Cancel
          </Button>

          <LoadingButton
            type="submit"
            variant="contained"
            disabled={!countryStateCodes}
            loading={
              addDeliveryAddressResult.isLoading ||
              updateDeliveryAddressResult.isLoading ||
              isSubmitting
            }
          >
            Save Address
          </LoadingButton>
        </DialogActions>
      )}
    </FormProvider>
  );
}

AddressNewFormContent.propTypes = {
  onClose: PropTypes.func,
  open: PropTypes.bool,
  isEditing: PropTypes.bool,
  addressData: PropTypes.object,
  checkout: PropTypes.bool,
};

export default function AddressNewForm(props) {
  const { open, onClose } = props;
  const { embeded } = props;
  if (embeded) {
    return <AddressNewFormContent {...props} />;
  }

  return (
    <Dialog fullWidth maxWidth="sm" open={open} onClose={() => onClose()}>
      <DialogTitle>New address</DialogTitle>

      <DialogContent>
        <AddressNewFormContent {...props} />
      </DialogContent>
    </Dialog>
  );
}

AddressNewForm.propTypes = {
  open: PropTypes.bool,
  onClose: PropTypes.func,
  embeded: PropTypes.bool,
};
