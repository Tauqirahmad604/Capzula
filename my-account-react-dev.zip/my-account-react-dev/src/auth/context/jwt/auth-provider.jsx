import Cookies from 'js-cookie';
import PropTypes from 'prop-types';
import { useMemo, useEffect, useReducer, useCallback } from 'react';

// import { useMeMutation } from 'src/redux/api/myAccount';

import { axiosBaseQuery, refreshTokenCall } from 'src/redux/api/baseQuery';
import { HOST_API, PARENT_HOST_URL, WP_MY_ACCOUNT_BASE_URL } from 'src/config-global';

import { isValidToken } from './utils';
import { AuthContext } from './auth-context';

// ----------------------------------------------------------------------

// NOTE:
// We only build demo at basic level.
// Customer will need to do some extra handling yourself if you want to extend the logic and other features...

// ----------------------------------------------------------------------

const initialState = {
  user: null,
  loading: true,
  twoFaToken: null,
};

const reducer = (state, action) => {
  if (action.type === 'INITIAL') {
    return {
      loading: false,
      user: action.payload.user,
      // twoFaToken: 'test',xrw
    };
  }
  if (action.type === 'TWO_FA_TOKEN_PROVIDED') {
    return {
      ...state,
      twoFaToken: action.payload,
    };
  }
  if (action.type === 'LOGIN') {
    return {
      ...state,
      user: action.payload.user,
    };
  }
  if (action.type === 'REGISTER') {
    return {
      ...state,
      user: action.payload.user,
    };
  }
  if (action.type === 'LOGOUT') {
    return {
      ...state,
      user: null,
    };
  }
  return state;
};

// ----------------------------------------------------------------------

export function AuthProvider({ children }) {
  const [state, dispatch] = useReducer(reducer, initialState);

  const logout = useCallback(() => {
    Cookies.remove('cpz_session_token');
    window.parent.location.href = `${WP_MY_ACCOUNT_BASE_URL}/customer-logout`;
  }, []);

  const initialize = useCallback(async () => {
    try {
      let accessToken = Cookies.get('cpz_session_token');
      // const refreshToken = Cookies.get('cpz_refresh_token');

      // isValidToken(refreshToken, 'refresh');
      // console.log(refreshToken, 'refreshToken');
      // if (!refreshToken || !isValidToken(refreshToken, 'refresh')) {
      //   throw Error('Refresh token invalid');
      // }

      if (!accessToken || !isValidToken(accessToken)) {
        accessToken = await refreshTokenCall();
      }
      // const response = await axios.get(`v1${endpoints.auth.refresh}`);
      // const accessToken = response.data.data.token;
      // Cookies.set('cpz_session_token', accessToken);
      // const accessToken = Cookies.set('cpz_session_token', accessToken);

      if (accessToken && isValidToken(accessToken)) {
        const axiosSession = axiosBaseQuery({
          baseUrl: `${HOST_API}v1/`,
        });

        const { data: userDetails } = await axiosSession({ url: 'auth/me' });

        const { user } = userDetails;

        // if (!user.email_verified && window.location.pathname !== '/auth/verify-email') {
        //   return window.location.replace('/auth/verify-email');
        // }

        return dispatch({
          type: 'INITIAL',
          payload: {
            user: {
              ...user,
              accessToken,
            },
            // twoFaToken: user.twoFaToken //@TODO: uncomment this line when twoFaToken is available
          },
        });
      }

      throw Error('Session token invalid');
    } catch (error) {
      console.log(error);
      return false;
      // return logout();
    }
    // }, [logout]);
  }, []);

  useEffect(() => {
    initialize();
  }, [initialize]);

  useEffect(() => {
    const receiveMessage = (event) => {
      if (event.origin !== PARENT_HOST_URL) {
        return;
      }
      const data = event.data ? JSON.parse(event.data) : null;

      if (data?.action === 'REFRESH_USER_DATA') {
        initialize();
      }
    };

    window.addEventListener('message', receiveMessage);

    return () => {
      window.removeEventListener('message', receiveMessage);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // ----------------------------------------------------------------------

  const checkAuthenticated = state.user ? 'authenticated' : 'unauthenticated';

  const status = state.loading ? 'loading' : checkAuthenticated;

  const representativeUserId = useMemo(() => {
    if (!state.user) {
      return '';
    }

    if (state.user.parent_id) {
      return state.user.parent_id;
    }

    if (state.user.emulated_user_id) {
      return state.user.emulated_user_id;
    }

    return state.user.id;
  }, [state.user]);

  const setTwoFaToken = (twoFaToken) => {
    dispatch({
      type: 'TWO_FA_TOKEN_PROVIDED',
      payload: twoFaToken,
    });
  };

  const memoizedValue = useMemo(
    () => ({
      user: state.user,
      representativeUserId,
      method: 'jwt',
      loading: status === 'loading',
      authenticated: status === 'authenticated',
      unauthenticated: status === 'unauthenticated',
      refresh: initialize,
      setTwoFaToken,
      twoFaToken: state.twoFaToken,
      logout,
    }),
    [state.user, status, initialize, representativeUserId, state.twoFaToken, logout]
  );

  return <AuthContext.Provider value={memoizedValue}>{children}</AuthContext.Provider>;
}

AuthProvider.propTypes = {
  children: PropTypes.node,
};
