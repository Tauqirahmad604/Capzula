import PropTypes from 'prop-types';
import { Navigate } from 'react-router-dom';

import { paths } from 'src/routes/paths';

import { SplashScreen } from 'src/components/loading-screen';

import { useAuthContext } from '../hooks';
// ----------------------------------------------------------------------

export default function GuestGuard({ children, ignoreTwoFa = false }) {
  const { loading } = useAuthContext();

  return <>{loading ? <SplashScreen /> : <Container ignoreTwoFa> {children}</Container>}</>;
}

GuestGuard.propTypes = {
  children: PropTypes.node,
  ignoreTwoFa: PropTypes.bool,
};

// ----------------------------------------------------------------------

function Container({ children, ignoreTwoFa = false }) {
  // const searchParams = useSearchParams();

  // const returnTo = searchParams.get('returnTo') || paths.dashboard.root;

  const { user } = useAuthContext();

  // const check = useCallback(() => {
  //   if (authenticated) {
  //     router.replace(returnTo);
  //   }
  // }, [authenticated, returnTo, router]);

  // useEffect(() => {
  //   if (user?.two_fa.session.enabled && user?.two_fa.session.valid && !ignoreTwoFa) {
  //     // redirect to auth/2fa
  //     router.replace(paths.dashboard.root);
  //   }
  //   if (user?.setup_progress.business_details_complete && user?.docs.approved) {
  //     // redirect to auth/2fa
  //     router.replace(paths.dashboard.root);
  //   }
  // }, [ignoreTwoFa, router, user]);

  if (user?.two_fa.session.enabled && user?.two_fa.session.valid && !ignoreTwoFa) {
    return <Navigate to={paths.dashboard.root} />;
  }

  if (
    user?.setup_progress.business_details_complete &&
    user?.docs.approved &&
    !user.account_locked
  ) {
    return <Navigate to={`${paths.dashboard.root}/?approved=true`} />;
  }

  return <>{children}</>;
}

Container.propTypes = {
  children: PropTypes.node,
  ignoreTwoFa: PropTypes.bool,
};
