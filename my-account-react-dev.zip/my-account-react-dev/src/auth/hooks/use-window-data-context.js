import { useContext } from 'react';

import { WindowDataContext } from '../../context/window-data/window-data-context';

// ----------------------------------------------------------------------

export const useWindowDataContext = () => {
  const context = useContext(WindowDataContext);

  if (!context) throw new Error('useWindowDataContext context must be use inside AuthProvider');

  return context;
};
