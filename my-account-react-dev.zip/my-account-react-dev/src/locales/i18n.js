import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';
import LanguageDetector from 'i18next-browser-languagedetector';

import { localStorageGetItem } from 'src/utils/storage-available';

import { defaultLang } from './config-lang';
import translationEn from './langs/en.json';
import translationFr from './langs/fr.json';
import translationVi from './langs/vi.json';
import translationCn from './langs/cn.json';
import translationAr from './langs/ar.json';
import translationEs from './langs/es.json';
import translationTr from './langs/tr.json';

// ----------------------------------------------------------------------
// const languageUrl = new URL(window.location.href).searchParams.get('lang');
// const parentLanguageCookie = Cookies.get('selected_lang');
// const languageCookie = parentLanguageCookie ? parentLanguageCookie.split('_')[0] : 'en';

const lng = localStorageGetItem('i18nextLng', defaultLang.value);

i18n
  .use(LanguageDetector)
  .use(initReactI18next)
  .init({
    resources: {
      en: { translations: translationEn },
      fr: { translations: translationFr },
      vi: { translations: translationVi },
      cn: { translations: translationCn },
      ar: { translations: translationAr },
      es: { translations: translationEs },
      tr: { translations: translationTr },
    },
    lng,
    fallbackLng: lng,
    debug: false,
    ns: ['translations'],
    defaultNS: 'translations',
    interpolation: {
      escapeValue: false,
    },
  });

export const trl = (key) => {
  const currentLanguage = i18n.language || window.localStorage.i18nextLng;
  const translation = i18n.t(key, { lng: currentLanguage });

  return translation !== key ? translation : key;
};
export default i18n;
