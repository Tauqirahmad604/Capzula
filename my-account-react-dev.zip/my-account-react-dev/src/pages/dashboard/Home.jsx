import { Crisp } from 'crisp-sdk-web';
import { Helmet } from 'react-helmet-async';
import { useLocation } from 'react-router-dom';

import Chip from '@mui/material/Chip';
import Table from '@mui/material/Table';
import Paper from '@mui/material/Paper';
import TableRow from '@mui/material/TableRow';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import Container from '@mui/material/Container';
import IconButton from '@mui/material/IconButton';
import Typography from '@mui/material/Typography';
import TableContainer from '@mui/material/TableContainer';
import { Card, Alert, Button, CardContent } from '@mui/material';

import { useRouter } from 'src/routes/hooks';

import { trl } from 'src/locales/i18n';
import { useAuthContext } from 'src/auth/hooks';
import { PARENT_HOST_URL } from 'src/config-global';

import Iconify from 'src/components/iconify';

import { OverviewAnalyticsView } from 'src/sections/analytics/view';

// ----------------------------------------------------------------------

export default function Page() {
  const router = useRouter();
  // const { approved } = useParams();
  const { search } = useLocation();
  const params = new URLSearchParams(search);
  const { user } = useAuthContext();

  const documets_alert =
    (user.account_status?.document_upload_outstanding ||
      user.account_status?.documents_approval_outstanding) &&
    user.account_status?.documents_required;
  const documents_awaiting_approval =
    user.account_status?.documents_approval_outstanding &&
    !user.account_status?.document_upload_outstanding;

  // const action_alerts =
  //   user.account_status?.documets_alert ||
  //   user.account_status?.billing_address_alert ||
  //   user.account_status?.business_details_alert ||
  //   user.account_status?.payments_alert ||
  //   user.account_status?.warehouse_alert ||
  //   user.account_status?.store_details_outstanding;

  const store_details_alert = user.account_status?.store_details_outstanding;

  const warehouse_alert = user.account_status?.is_customer
    ? user.account_status?.warehouse_outstanding
    : false;
  const payments_alert = user.account_status?.cards_outstanding;
  const business_details_alert = user.account_status?.business_details_outstanding;
  const billing_address_alert = user.account_status?.billing_address_outstanding;

  return (
    <Container maxWidth="xl">
      <Helmet>
        <title> Dashboard</title>
      </Helmet>

      <Typography
        variant="h4"
        sx={{
          mb: 0,
        }}
      >
        {trl('Home.welcome')}, {user?.first_name} 👋
      </Typography>

      <Typography variant="body1" sx={{ mb: 2 }}>
        Customer No: {user?.cpz_id}
      </Typography>
      {/* <Button onClick={refresh}>refresh</Button> */}
      {params.get('approved') && (
        <Card>
          <CardContent>
            <Alert severity="success" sx={{ mb: 2 }}>
              <Typography variant="body2" fontWeight={600}>
                Your account has been approved
              </Typography>

              <Typography variant="body2">
                You can now browse and purchase from our international verified sellers.
              </Typography>
            </Alert>
            <Button
              color="primary"
              onClick={() => window.open(PARENT_HOST_URL)}
              size="large"
              variant="contained"
            >
              {trl('Navbar.shop_now')}
              <Iconify sx={{ ml: 1 }} width={16} icon="radix-icons:open-in-new-window" />
            </Button>

            <Button
              // color="success"
              sx={{ ml: 1 }}
              size="large"
              onClick={() => Crisp.chat.open()}
              // variant="outlined"
            >
              I need help
              {/* <Iconify sx={{ ml: 1 }} width={16} icon="solar:chat-dots-bold" /> */}
            </Button>
          </CardContent>
        </Card>
      )}

      {/* {(warehouse_alert ||
        payments_alert ||
        business_details_alert ||
        store_details_alert ||
        billing_address_alert) &&
        !user.account_status?.document_upload_outstanding && (
          <Alert severity="warning" sx={{ mb: 2 }}>
            To enable purchasing, please complete the following
          </Alert>
        )} */}

      {/* {action_alerts && is_staff_member && (
        <div>
          {user.account_status?.document_upload_outstanding && (
            <div className="notice notice--error mb-4">
              <div className="notice__icon">
                <i className="fa fa-chevron-down" />
              </div>
              <div className="notice__content">
                To enable purchasing, please complete the following
              </div>
            </div>
          )}
        </div>
      )} */}

      <TableContainer sx={{ mb: 5 }} component={Paper}>
        <Table sx={{ minWidth: 650 }} aria-label="simple table">
          <TableBody>
            {documets_alert && (
              <TableRow sx={{ '&:last-child td, &:last-child th': { border: 0 } }}>
                <TableCell component="th" scope="row">
                  <strong>{trl('Global.documents')}</strong>
                </TableCell>
                <TableCell width="50%">
                  {documents_awaiting_approval ? (
                    <>{trl('Home.documents_waiting_aproval')}</>
                  ) : (
                    <>
                      {user.account_status?.doc_reject_reason ? (
                        user.account_status?.doc_reject_reason
                      ) : (
                        <>{trl('Home.please_upload_documents')}</>
                      )}
                    </>
                  )}
                </TableCell>
                <TableCell align="right">
                  {documents_awaiting_approval ? (
                    <Chip color="warning" label={trl('Global.inProgress')} />
                  ) : (
                    <>
                      {user.account_status?.doc_reject_reason ? (
                        <Chip color="error" label={trl('Global.rejected')} />
                      ) : (
                        <Chip color="secondary" label={trl('Global.pending')} />
                      )}
                    </>
                  )}
                </TableCell>
                <TableCell align="right">
                  <IconButton onClick={() => router.push('/account/documents')} color="default">
                    <Iconify icon="iconoir:arrow-right-circle-solid" />
                  </IconButton>
                </TableCell>
              </TableRow>
            )}

            {business_details_alert && (
              <TableRow sx={{ '&:last-child td, &:last-child th': { border: 0 } }}>
                <TableCell component="th" scope="row">
                  <strong>Business Details</strong>
                </TableCell>
                <TableCell width="50%">Add your business details</TableCell>
                <TableCell align="right">
                  <Chip color="secondary" label="Pending" />
                </TableCell>
                <TableCell align="right">
                  {' '}
                  <IconButton
                    onClick={() => router.push('/account/business-details')}
                    color="default"
                  >
                    <Iconify icon="iconoir:arrow-right-circle-solid" />
                  </IconButton>
                </TableCell>
              </TableRow>
            )}

            {warehouse_alert && user.role === 'customer' && (
              <TableRow sx={{ '&:last-child td, &:last-child th': { border: 0 } }}>
                <TableCell component="th" scope="row">
                  <strong>Logistical Parners</strong>
                </TableCell>
                <TableCell width="50%">
                  With Capzula, you can purchase from different countries. Please select logistical
                  partners for the countries you would like to purchase from.
                </TableCell>
                <TableCell align="right">
                  <Chip color="secondary" label="Pending" />
                </TableCell>
                <TableCell align="right">
                  {' '}
                  <IconButton
                    onClick={() => router.push('/account/logistical-partners')}
                    color="default"
                  >
                    <Iconify icon="iconoir:arrow-right-circle-solid" />
                  </IconButton>
                </TableCell>
              </TableRow>
            )}

            {payments_alert && user.role === 'customer' && (
              <TableRow sx={{ '&:last-child td, &:last-child th': { border: 0 } }}>
                <TableCell component="th" scope="row">
                  <strong>Payment Methods</strong>
                </TableCell>
                <TableCell width="50%">
                  Add a payment method to allow you to instantly buy products in our live streams.
                </TableCell>
                <TableCell align="right">
                  <Chip color="secondary" label="Pending" />
                </TableCell>
                <TableCell align="right">
                  {' '}
                  <IconButton
                    onClick={() => router.push('/account/payment-methods')}
                    color="default"
                  >
                    <Iconify icon="iconoir:arrow-right-circle-solid" />
                  </IconButton>
                </TableCell>
              </TableRow>
            )}

            {store_details_alert && user.role === 'vendor' && (
              <TableRow sx={{ '&:last-child td, &:last-child th': { border: 0 } }}>
                <TableCell component="th" scope="row">
                  <strong>Store Details</strong>
                </TableCell>
                <TableCell width="50%">Please provide details about your store.</TableCell>
                <TableCell align="right">
                  <Chip color="secondary" label="Pending" />
                </TableCell>
                <TableCell align="right">
                  {' '}
                  <IconButton onClick={() => router.push('/account/manage-store')} color="default">
                    <Iconify icon="iconoir:arrow-right-circle-solid" />
                  </IconButton>
                </TableCell>
              </TableRow>
            )}

            {billing_address_alert && user.role === 'customer' && (
              <TableRow sx={{ '&:last-child td, &:last-child th': { border: 0 } }}>
                <TableCell component="th" scope="row">
                  <strong>Billing Addresses</strong>
                </TableCell>
                <TableCell width="50%">
                  Please provide your billing address for your payments & invoices
                </TableCell>
                <TableCell align="right">
                  <Chip color="secondary" label="Pending" />
                </TableCell>
                <TableCell align="right">
                  {' '}
                  <IconButton
                    onClick={() => router.push('/account/billing-addresses')}
                    color="default"
                  >
                    <Iconify icon="iconoir:arrow-right-circle-solid" />
                  </IconButton>
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </TableContainer>

      <OverviewAnalyticsView />
      
    </Container>
  );
}
