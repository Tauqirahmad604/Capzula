import { Helmet } from 'react-helmet-async';

import FavVendorsView from 'src/sections/fav-vendors/view';

// ----------------------------------------------------------------------

export default function Page() {
  return (
    <>
      <Helmet>
        <title>Favourite Vendors</title>
      </Helmet>

      <FavVendorsView />
    </>
  );
}
