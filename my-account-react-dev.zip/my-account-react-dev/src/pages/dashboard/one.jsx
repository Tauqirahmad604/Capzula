import { Helmet } from 'react-helmet-async';

import OrderListView from 'src/sections/order/view/order-list-view';

// ----------------------------------------------------------------------

export default function Page() {
  return (
    <>
      <Helmet>
        <title> Dashboard: One..</title>
      </Helmet>

      <OrderListView />
    </>
  );
}
