import { Helmet } from 'react-helmet-async';

import TransactionsListView from 'src/sections/transactions/transactions-list';


// ----------------------------------------------------------------------

export default function TransactionsPage() {
  return (
    <>
      <Helmet>
        <title> Transactions </title>
      </Helmet>

      <TransactionsListView 
        transactionType={false}
      />
    </>
  );
}
