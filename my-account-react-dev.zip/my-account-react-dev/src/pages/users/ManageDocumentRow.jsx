/* eslint-disable no-nested-ternary */
import PropTypes from 'prop-types';
import { useState, useEffect } from 'react';
import { enqueueSnackbar } from 'notistack';

import { LoadingButton } from '@mui/lab';
import {
  Radio,
  TableRow,
  TableCell,
  TextField,
  Typography,
  RadioGroup,
  FormControl,
  FormControlLabel,
} from '@mui/material';

import { useSupabaseContext } from 'src/supabase/hooks';

import Iconify from 'src/components/iconify';

function downloadBlob(blob, fileName) {
  return new Promise((resolve, reject) => {
    const url = window.URL.createObjectURL(new Blob([blob]));
    const a = document.createElement('a');
    a.href = url;
    a.download = fileName;
    document.body.appendChild(a);
    a.click();
    window.URL.revokeObjectURL(url);
    document.body.removeChild(a);
    return resolve();
  });
}

export default function ManageDocumentRow({
  allDocsUploaded,
  userId,
  uuid,
  docs,
  docType,
  onChange,
}) {
  const [action, setAction] = useState(docs[docType] ? docs[docType].status : null);
  const [reason, setReason] = useState(docs[docType] ? docs[docType].rejected_reason : null);
  const [isDownloading, setIsDownloading] = useState(false);

  const { makeAPICall } = useSupabaseContext();

  const docTypeKeys = {
    article_of_incorporation: 'Article of Incorporation',
    identification_document: 'Identification Document',
    sales_permit: 'Sales Permit',
  };

  const openUserDoc = async (fileUuid, file_name) => {
    const file = `${fileUuid}/${file_name}`;

    setIsDownloading(true);

    const { data, error: urlError } = await makeAPICall((apiClient) =>
      apiClient.storage.from('documents').download(file)
    );

    if (urlError) {
      enqueueSnackbar('Error downloading file', { variant: 'error' });
      setIsDownloading(false);
      return;
    }

    await downloadBlob(data, file);

    setIsDownloading(false);
  };

  useEffect(() => {
    onChange({
      action,
      docType,
      userId,
      reason,
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [action, reason]);

  if (!docs || !docs[docType]) {
    return null;
  }

  return (
    docs[docType] && (
      <TableRow>
        <TableCell>
          <Typography variant="body2">{docTypeKeys[docType] || docType}</Typography>
        </TableCell>
        <TableCell sx={{ textAlign: 'center' }}>
          {docs[docType].file_name ? (
            <Iconify
              color="green"
              sx={{ mr: 1 }}
              width={25}
              icon="solar:check-circle-bold-duotone"
            />
          ) : (
            <Iconify width={25} color="red" sx={{ mr: 1 }} icon="solar:close-circle-bold-duotone" />
          )}
        </TableCell>
        <TableCell sx={{ textAlign: 'center' }}>
          {docs[docType].status === 'approved' ? (
            <Iconify
              width={25}
              color="green"
              sx={{ mr: 1 }}
              icon="solar:check-circle-bold-duotone"
            />
          ) : docs[docType].file_name ? (
            <Iconify
              width={25}
              color="orange"
              sx={{ mr: 1 }}
              icon="solar:shield-warning-bold-duotone"
            />
          ) : (
            <Iconify width={25} color="red" sx={{ mr: 1 }} icon="solar:close-circle-bold-duotone" />
          )}
        </TableCell>
        <TableCell>
          <FormControl>
            <RadioGroup
              aria-labelledby="demo-controlled-radio-buttons-group"
              name="controlled-radio-buttons-group"
              value={action}
              onChange={(e) => {
                setAction(e.target.value);
                setReason(null);
              }}
            >
              <FormControlLabel
                disabled={!allDocsUploaded}
                value="approved"
                control={<Radio />}
                label="Approved"
              />
              <FormControlLabel
                disabled={!allDocsUploaded}
                value="rejected"
                control={<Radio />}
                label="Rejected"
              />
            </RadioGroup>

            {action === 'rejected' && (
              <TextField
                sx={{ mt: 1 }}
                value={reason}
                disabled={!allDocsUploaded}
                error={reason && reason.length < 10}
                helperText={reason && reason.length < 10 && 'Reason must be at least 5 characters'}
                onChange={(e) => setReason(e.target.value)}
                id="outlined-basic"
                label="Reason"
                variant="outlined"
              />
            )}
          </FormControl>
        </TableCell>
        <TableCell>
          <LoadingButton
            // variant="outlined"
            loading={isDownloading}
            disabled={isDownloading || !docs[docType].file_name}
            sx={{ borderRadius: 0.75 }}
            onClick={() => openUserDoc(uuid, docs[docType].file_name)}
          >
            <Iconify icon="solar:download-square-bold" width={20} />
          </LoadingButton>
        </TableCell>
      </TableRow>
    )
  );
}

ManageDocumentRow.propTypes = {
  allDocsUploaded: PropTypes.bool.isRequired,
  userId: PropTypes.string.isRequired,
  uuid: PropTypes.string.isRequired,
  docs: PropTypes.object.isRequired,
  docType: PropTypes.string.isRequired,
  onChange: PropTypes.func.isRequired,
};
