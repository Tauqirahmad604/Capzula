import PropTypes from 'prop-types';
import debounce from 'lodash.debounce';
import { Helmet } from 'react-helmet-async';
import { enqueueSnackbar } from 'notistack';
import { useRef, useState, useEffect, useCallback } from 'react';

import { Box, alpha, Stack, Container } from '@mui/system';
import {
  Tab,
  Tabs,
  Card,
  Menu,
  Table,
  Button,
  Avatar,
  Select,
  Tooltip,
  Divider,
  TableRow,
  Skeleton,
  MenuItem,
  TableCell,
  TableHead,
  TableBody,
  TextField,
  Typography,
  InputLabel,
  IconButton,
  FormControl,
  OutlinedInput,
  InputAdornment,
  CircularProgress,
} from '@mui/material';

import { useRouter } from 'src/routes/hooks';

import { fTimestampToDate } from 'src/utils/format-time';

import { useAuthContext } from 'src/auth/hooks';
import DocumentsDialog from 'src/pages/users/DocumentsDialog';
import {
  useGetUsersQuery,
  useGetUserRolesQuery,
  useDeleteUserMutation,
  useResetPasswordMutation,
  useToggleLockAccountMutation,
  useStartEmulatingUserMutation,
} from 'src/redux/api/myAccount';

import Label from 'src/components/label';
import Iconify from 'src/components/iconify';
import Scrollbar from 'src/components/scrollbar';
import { LoadingScreen } from 'src/components/loading-screen';
import EmptyContent from 'src/components/empty-content/empty-content';
import TablePaginationCustom from 'src/components/table/_table-pagination-custom';

const accountRoles = {
  yith_vendor: 'Vendor',
  vendor_staff: 'Staff Member',
  customer: 'Buyer',
  admin: 'Admin',
  capzula_staff: 'Capzula staff',
  logistics_partner: 'Logistics Partner',
  payment_partner: 'Payment Partner',
};

const LoadingRow = () => (
  <TableRow>
    <TableCell>
      {' '}
      <Skeleton height={25} />
    </TableCell>
    <TableCell>
      {' '}
      <Skeleton height={25} />
    </TableCell>
    <TableCell>
      {' '}
      <Skeleton height={25} />
    </TableCell>
    <TableCell>
      {' '}
      <Skeleton height={25} />
    </TableCell>
    <TableCell>
      {' '}
      <Skeleton height={25} />
    </TableCell>
    <TableCell>
      <Skeleton height={25} />
    </TableCell>
    <TableCell>
      <Skeleton height={25} />
    </TableCell>
    <TableCell>
      <Skeleton height={25} />
    </TableCell>
  </TableRow>
);

const hasRejections = (docs) => {
  if (!docs) {
    return false;
  }
  const rejectedDocs = Object.keys(docs?.file_statuses).filter(
    (key) => docs.file_statuses[key].status === 'rejected'
  );
  return rejectedDocs.length > 0;
};

const allDocsUploaded = (docs) => {
  if (!docs) {
    return false;
  }
  const docsUploaded = Object.keys(docs?.file_statuses).filter(
    (key) => docs.file_statuses[key].file_name
  );
  return docsUploaded.length > 0;
};
const RenderDocumentUploadedIcon = ({ docs }) => {
  if (docs?.approved === 'N/A') {
    return '';
  }

  if (allDocsUploaded(docs) && docs?.approved) {
    return (
      <Tooltip title="Uploaded">
        <Iconify width={25} sx={{ mr: 1 }} color="green" icon="solar:check-circle-bold-duotone" />
      </Tooltip>
    );
  }

  if (!docs?.verification_ready) {
    if (hasRejections(docs)) {
      return (
        <Tooltip title="Rejected">
          <Iconify width={25} sx={{ mr: 1 }} color="red" icon="solar:close-circle-bold-duotone" />
        </Tooltip>
      );
    }

    return (
      <Tooltip title="Not uploaded">
        <Iconify width={25} sx={{ mr: 1, opacity: 0.4 }} icon="solar:close-circle-bold-duotone" />
      </Tooltip>
    );
  }

  if (docs?.verification_ready) {
    if (docs?.approved) {
      return (
        <Tooltip title="Approved">
          <Iconify width={25} color="green" sx={{ mr: 1 }} icon="solar:check-circle-bold-duotone" />
        </Tooltip>
      );
    }
    return (
      <Tooltip title="Awaiting Approval">
        <Iconify
          width={25}
          color="orange"
          sx={{ mr: 1 }}
          icon="solar:shield-warning-bold-duotone"
        />
      </Tooltip>
    );
  }
  return null;
};

RenderDocumentUploadedIcon.propTypes = {
  docs: PropTypes.object,
};

const RenderDocumentApprovedIcon = ({ docs }) => {
  if (docs?.approved === 'N/A') {
    return 'N/A';
  }

  if (!docs?.approved) {
    return (
      <Iconify width={25} sx={{ mr: 1, opacity: 0.4 }} icon="solar:close-circle-bold-duotone" />
    );
  }

  if (docs?.approved) {
    return (
      <Tooltip title="Approved">
        <Iconify width={25} color="green" sx={{ mr: 1 }} icon="solar:check-circle-bold-duotone" />
      </Tooltip>
    );
  }
  return null;
};

RenderDocumentApprovedIcon.propTypes = {
  docs: PropTypes.object,
};

// isLoading={() =>
//   deleteUserResults.isLoading || startEmulatingUserResults.isLoading
// }
// onClickViewDocuments={
//   user?.docs?.approved !== 'N/A' ? () => setViewDocuments(user) : null
// }
// onClickSendMessage={
//   user?.docs?.approved !== 'N/A'
//     ? () => router.push(`/chats?to=${user.uuid}`)
//     : null
// }
// onClickManage={() =>
//   startEmulatingUser({ emulate_user_id: user?.wp_id })
// }
// onClickDelete={() => deleteUser({ id: user?.wp_id })}

function UserRowActionMenu({
  startEmulatingUserIsLoading,
  deleteUserIsLoading,
  onClickViewDocuments,
  onClickSendMessage,
  onClickManage,
  onClickDelete,
  onClickResetPassword,
  onClickToggleLockAccount,
  resetPasswordIsLoading,
  toggleLockAccountIsLoading,
  userAccountLocked,
  isAdminOrCpzStaff,
}) {
  const [anchorEl, setAnchorEl] = useState(null);
  const open = Boolean(anchorEl);
  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };
  const handleClose = () => {
    setAnchorEl(null);
  };

  return (
    <div>
      <IconButton onClick={handleClick}>
        <Iconify icon="eva:more-vertical-fill" />
      </IconButton>
      <Menu id="basic-menu" anchorEl={anchorEl} open={open} onClose={handleClose}>
        {onClickManage && (
          <MenuItem
            sx={{ px: 2, py: 1 }}
            onClick={onClickManage}
            disabled={startEmulatingUserIsLoading}
          >
            {startEmulatingUserIsLoading ? (
              <CircularProgress size={20} sx={{ mr: 1, color: '#222' }} />
            ) : (
              <Iconify sx={{ mr: 1 }} icon="solar:user-bold" />
            )}
            Manage Account{' '}
          </MenuItem>
        )}
        {onClickSendMessage && (
          <MenuItem sx={{ px: 2, py: 1 }} onClick={onClickSendMessage}>
            <Iconify sx={{ mr: 1 }} icon="solar:chat-line-bold" /> Send Message
          </MenuItem>
        )}

        {onClickViewDocuments && (
          <MenuItem sx={{ px: 2, py: 1 }} onClick={onClickViewDocuments}>
            <Iconify sx={{ mr: 1 }} icon="solar:document-add-bold" /> View Documents
          </MenuItem>
        )}

        <Divider />

        {onClickDelete && (
          <MenuItem
            sx={{ px: 2, py: 1 }}
            onClick={onClickResetPassword}
            disabled={resetPasswordIsLoading}
          >
            {resetPasswordIsLoading ? (
              <CircularProgress size={20} sx={{ mr: 1, color: '#222' }} />
            ) : (
              <Iconify sx={{ mr: 1 }} icon="solar:lock-password-bold" />
            )}
            Reset Password
          </MenuItem>
        )}

        {onClickToggleLockAccount && (
          <MenuItem
            sx={{ px: 2, py: 1 }}
            onClick={onClickToggleLockAccount}
            disabled={toggleLockAccountIsLoading}
          >
            {toggleLockAccountIsLoading ? (
              <CircularProgress size={20} sx={{ mr: 1, color: '#222' }} />
            ) : (
              <Iconify sx={{ mr: 1 }} icon="solar:user-block-bold" />
            )}
            {userAccountLocked ? 'Unlock' : 'Lock'} Account
          </MenuItem>
        )}

        {onClickDelete && (
          <MenuItem
            sx={{ px: 2, py: 1, color: 'error.main' }}
            onClick={onClickDelete}
            disabled={deleteUserIsLoading}
          >
            {deleteUserIsLoading ? (
              <CircularProgress size={20} sx={{ mr: 1, color: 'error.main' }} />
            ) : (
              <Iconify sx={{ mr: 1 }} icon="solar:trash-bin-2-bold" />
            )}
            Delete
          </MenuItem>
        )}
      </Menu>
    </div>
  );
}

UserRowActionMenu.propTypes = {
  startEmulatingUserIsLoading: PropTypes.bool,
  deleteUserIsLoading: PropTypes.bool,
  onClickViewDocuments: PropTypes.func,
  onClickSendMessage: PropTypes.func,
  onClickManage: PropTypes.func,
  onClickDelete: PropTypes.func,
  onClickResetPassword: PropTypes.func,
  resetPasswordIsLoading: PropTypes.bool,
  onClickToggleLockAccount: PropTypes.func,
  toggleLockAccountIsLoading: PropTypes.bool,
  userAccountLocked: PropTypes.bool,
  isAdminOrCpzStaff: PropTypes.bool,
};

export default function Page() {
  const [currentPage, setCurrentPage] = useState(0);
  const [filteredRole, setFilteredRole] = useState('all');
  const [filteredSearch, setFilteredSearch] = useState('');
  const [filteredOption, setFilteredOption] = useState(null);
  const [viewDocuments, setViewDocuments] = useState(null);

  const { user: authedUser } = useAuthContext();
  const router = useRouter();

  const debouncedSearch = useRef(debounce(setFilteredSearch, 800));

  const handleSearch = useCallback((e) => {
    if (e.target.value === '') {
      setFilteredSearch('');
    } else {
      debouncedSearch.current(e.target.value);
    }
  }, []);

  const {
    data: usersQuery,
    isLoading: usersQueryIsLoading,
    isFetching: usersQueryIsFetching,
    refetch: refetchUsersQuery,
  } = useGetUsersQuery({
    pageNum: currentPage,
    role: filteredRole === 'all' ? null : filteredRole,
    search: filteredSearch,
    option: filteredOption,
  });

  const {
    data: userRolesQuery,
    // isLoading: userRolesIsLoading,
    // refetch: refetchUserRolesQuery,
  } = useGetUserRolesQuery({
    pageNum: 1,
  });

  const userList = usersQuery?.data?.users || [];
  const pagination = usersQuery?.data?.pagination || [];
  const userRoles = userRolesQuery?.data || [];

  const [startEmulatingUser, startEmulatingUserResults] = useStartEmulatingUserMutation();
  const [deleteUser, deleteUserResults] = useDeleteUserMutation();
  const [resetPassword, resetPasswordResults] = useResetPasswordMutation();
  const [toggleLockAccount, toggleLockAccountResults] = useToggleLockAccountMutation();

  const handleFilterRole = (event, newValue) => {
    setCurrentPage(0);
    setFilteredRole(newValue);
  };

  useEffect(() => {
    if (startEmulatingUserResults.isSuccess) {
      document.location.replace('/');
    } else if (startEmulatingUserResults.isError) {
      enqueueSnackbar('Failed to start managing another user', { variant: 'error' });
    }
  }, [startEmulatingUserResults.isSuccess, startEmulatingUserResults.isError]);

  useEffect(() => {
    if (resetPasswordResults.isSuccess) {
      enqueueSnackbar('User password reset email sent successful', { variant: 'success' });
    }
    if (resetPasswordResults.isError) {
      enqueueSnackbar('Failed to reset user password', { variant: 'error' });
    }
  }, [resetPasswordResults.isSuccess, resetPasswordResults.isError]);

  useEffect(() => {
    if (toggleLockAccountResults.isSuccess) {
      enqueueSnackbar('Account lock update successful', { variant: 'success' });
    }
    if (toggleLockAccountResults.isError) {
      enqueueSnackbar('Failed to change account lock status', { variant: 'error' });
    }
  }, [toggleLockAccountResults.isSuccess, toggleLockAccountResults.isError]);

  return (
    <>
      <Helmet>
        <title>Users</title>
      </Helmet>

      <Button onClick={refetchUsersQuery}>Refresh</Button>
      <Container maxWidth="xl">
        {usersQueryIsLoading ? (
          <LoadingScreen />
        ) : (
          <Card>
            <Tabs
              value={filteredRole}
              onChange={handleFilterRole}
              sx={{
                px: 2.5,
                boxShadow: (theme) => `inset 0 -2px 0 0 ${alpha(theme.palette.grey[500], 0.08)}`,
                // pb: 2,
              }}
            >
              <Tab key="all" iconPosition="end" value="all" label="All" active />
              {userRoles?.map((role) => (
                <Tab
                  key={role.value}
                  iconPosition="end"
                  value={role.value}
                  label={role.name}
                  icon={
                    <Label
                    // variant={
                    // ((role.value === 'all' || role.value === role.status) && 'filled') || 'soft'
                    // }
                    >
                      {role.userCount}
                    </Label>
                  }
                />
              ))}
            </Tabs>

            <Box sx={{ display: 'flex', justifyContent: 'flex-end', p: 2, gap: 2 }}>
              <TextField
                fullWidth
                // value={filteredSearch}
                onChange={handleSearch}
                placeholder="Search Name, Email, Tel, Customer Number..."
                InputProps={{
                  startAdornment: (
                    <InputAdornment position="start">
                      <Iconify icon="eva:search-fill" sx={{ color: 'text.disabled' }} />
                    </InputAdornment>
                  ),
                }}
              />
              <FormControl sx={{ width: '50%' }}>
                <InputLabel>Filter</InputLabel>
                <Select
                  value={filteredOption || 'all'}
                  onChange={(e) => setFilteredOption(e.target.value)}
                  input={<OutlinedInput label="Filter by Status" />}
                >
                  <MenuItem value="all">All</MenuItem>
                  <MenuItem value="DOCS_NOT_UPLOADED">Documents not uploaded</MenuItem>
                  <MenuItem value="DOCS_AWAITING_APPROVAL">Documents awaiting approval</MenuItem>
                  <MenuItem value="DOCS_REJECTED">Documents rejected</MenuItem>
                  <MenuItem value="DOCS_APPROVED">Documents approved</MenuItem>
                </Select>
              </FormControl>
            </Box>

            {userList.length <= 0 ? (
              <EmptyContent
                title="No users found"
                action={
                  <Button
                    // size="large"
                    sx={{ mt: 1 }}
                    // color="success"
                    onClick={() => {
                      setFilteredRole('all');
                      setFilteredSearch('');
                    }}
                    variant="contained"
                  >
                    Clear filters
                  </Button>
                }
                sx={{ p: 2 }}
              />
            ) : (
              <Scrollbar>
                <Table sx={{ minWidth: 1200 }}>
                  <TableHead>
                    <TableRow>
                      <TableCell width="5%">#</TableCell>
                      {/* <TableCell>Customer ID</TableCell> */}
                      <TableCell width="20%">Business Name</TableCell>
                      <TableCell width="20%">Customer Name</TableCell>
                      {/* <TableCell>Approved</TableCell> */}
                      <TableCell width="5%">Email</TableCell>
                      <TableCell width="5%">Role</TableCell>
                      <TableCell>Documents</TableCell>
                      <TableCell width="10%">Last Active</TableCell>
                      <TableCell />
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {usersQueryIsFetching ? (
                      <>
                        <LoadingRow />
                        <LoadingRow />
                        <LoadingRow />
                        <LoadingRow />
                        <LoadingRow />
                        <LoadingRow />
                        <LoadingRow />
                        <LoadingRow />
                        <LoadingRow />
                        <LoadingRow />
                        <LoadingRow />
                        <LoadingRow />
                        <LoadingRow />
                        <LoadingRow />
                        <LoadingRow />
                        <LoadingRow />
                        <LoadingRow />
                        <LoadingRow />
                        <LoadingRow />
                        <LoadingRow />
                      </>
                    ) : (
                      userList?.map((user) => (
                        <TableRow
                          key={user.wp_id}
                          sx={{ bgcolor: user.account_locked ? '#fef3f3' : '' }}
                        >
                          <TableCell>{user?.cpz_id}</TableCell>

                          <TableCell>
                            <Box
                              sx={{
                                display: 'flex',
                                alignContent: 'center',
                                alignItems: 'center',
                                gap: 1,
                              }}
                            >
                              <Avatar
                                onClick={() => {
                                  console.log(user);
                                }}
                                src={user?.profile_photo}
                                alt={user?.full_name}
                                sx={{
                                  width: 36,
                                  height: 36,
                                  border: (theme) =>
                                    `solid 2px ${theme.palette.background.default}`,
                                }}
                              />
                              <Typography variant="body2" fontWeight={500}>
                                {user?.business_details?.business_name}
                                {user.account_locked && (
                                  <Tooltip title="Account Locked">
                                    <Iconify
                                      width={25}
                                      color="red"
                                      sx={{ mr: 1, pt: 1 }}
                                      icon="fe:disabled"
                                    />
                                  </Tooltip>
                                )}
                              </Typography>
                            </Box>
                          </TableCell>
                          <TableCell>{user?.full_name}</TableCell>
                          <TableCell>{user?.email}</TableCell>

                          <TableCell>
                            {accountRoles[user?.role] ? accountRoles[user?.role] : user?.role}
                          </TableCell>

                          <TableCell>
                            <Stack alignContent="center" alignItems="center">
                              {user.docs && <RenderDocumentUploadedIcon docs={user.docs} />}
                            </Stack>
                          </TableCell>
                          <TableCell>
                            {user?.last_active_time
                              ? fTimestampToDate(user?.last_active_time)
                              : 'Never'}
                            {/* {user?.last_active_time} */}
                          </TableCell>
                          <TableCell>
                            <UserRowActionMenu
                              deleteUserIsLoading={deleteUserResults.isLoading}
                              startEmulatingUserIsLoading={startEmulatingUserResults.isLoading}
                              onClickViewDocuments={
                                user?.docs?.approved !== 'N/A' ? () => setViewDocuments(user) : null
                              }
                              onClickSendMessage={
                                user?.docs?.approved !== 'N/A'
                                  ? () => router.push(`/chats?to=${user.id}`)
                                  : null
                              }
                              onClickManage={() =>
                                startEmulatingUser({ emulate_user_id: user?.wp_id })
                              }
                              onClickDelete={
                                authedUser.role === 'admin'
                                  ? () => deleteUser({ id: user?.wp_id })
                                  : null
                              }
                              onClickResetPassword={() => {
                                resetPassword({ id: user?.wp_id });
                              }}
                              resetPasswordIsLoading={resetPasswordResults.isLoading}
                              userAccountLocked={user?.account_locked}
                              toggleLockAccountIsLoading={toggleLockAccountResults.isLoading}
                              onClickToggleLockAccount={() => {
                                toggleLockAccount({ id: user?.wp_id });
                              }}
                              isAdminOrCpzStaff={
                                authedUser.role === 'admin' || authedUser.role === 'capzula_staff'
                              }
                            />
                          </TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              </Scrollbar>
            )}
            <TablePaginationCustom
              count={pagination.total_users}
              page={currentPage}
              rowsPerPage={pagination.per_page}
              rowsPerPageOptions={-1}
              onPageChange={(e, page) => {
                window.scrollTo({ top: 0, behavior: 'smooth' });
                setCurrentPage(page);
              }}
            />
          </Card>
        )}
      </Container>

      {/* user?.docs?.article_of_incorporation
                                ? `/documents/${user.uuid}/${user.docs.article_of_incorporation.file_name}`
                                : '' */}

      <DocumentsDialog
        name={viewDocuments?.full_name}
        role={viewDocuments?.role}
        open={!!viewDocuments}
        userId={viewDocuments?.wp_id}
        uuid={viewDocuments?.id}
        docs={viewDocuments?.docs?.file_statuses}
        setViewDocuments={setViewDocuments}
      />
    </>
  );
}
