import PropTypes from 'prop-types';
import { enqueueSnackbar } from 'notistack';
import { useState, useEffect, useCallback } from 'react';

import { LoadingButton } from '@mui/lab';
import {
  Table,
  Alert,
  Dialog,
  TableRow,
  TableCell,
  TableHead,
  TableBody,
  DialogTitle,
  DialogContent,
} from '@mui/material';

import { useVerifyDocsMutation } from 'src/redux/api/myAccount';
import ManageDocumentRow from 'src/pages/users/ManageDocumentRow';

export default function DocumentsDialog({ open, name, userId, uuid, docs, setViewDocuments }) {
  const [verifyDocs, verifyDocsResults] = useVerifyDocsMutation();

  const [payload, setPayload] = useState({});

  const prepDocKeys = useCallback(() => {
    if (!docs) {
      return [];
    }
    return Object.keys(docs);
  }, [docs]);

  const allDocsUploaded = () => {
    const docKeys = prepDocKeys();
    return docKeys.every((key) => !!docs[key].file_name);
  };

  const prepPayload = (rowPayload) =>
    setPayload((prev) => ({
      ...prev,
      [rowPayload.docType]: {
        status: rowPayload.action,
        reason: rowPayload.reason,
      },
    }));

  const canSubmit = useCallback(() => {
    const docKeys = prepDocKeys();
    const validDocKeys = docKeys.filter((docKey) => {
      if (!payload[docKey]) {
        return false;
      }
      if (payload[docKey].status === 'rejected' && payload[docKey].reason) {
        return payload[docKey].reason.length >= 10;
      }
      if (payload[docKey].status === 'approved') {
        return true;
      }
      return false;
    });

    return validDocKeys.length === docKeys.length;
  }, [payload, prepDocKeys]);

  const handleSubmit = () => {
    console.log('submitting...', payload);
    verifyDocs({
      ...payload,
      user_id: userId,
    });
  };

  useEffect(() => {
    if (verifyDocsResults.isSuccess) {
      enqueueSnackbar('Documents verified successfully', { variant: 'success' });
      setViewDocuments(null);
    }

    if (verifyDocsResults.isError) {
      enqueueSnackbar('An error occurred while verifing documents', { variant: 'error' });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [verifyDocsResults.isSuccess, verifyDocsResults.isError]);

  return (
    <Dialog fullWidth maxWidth="sm" open={open} onClose={() => setViewDocuments(null)}>
      {userId && docs && (
        <>
          <DialogTitle sx={{ pb: 1 }}>Documents for {name}</DialogTitle>
          <DialogContent sx={{ p: 3 }}>
            {!allDocsUploaded() && (
              <Alert severity="warning" sx={{ mt: 1, mb: 2 }}>
                To review documents, the user needs to finish uploading all documents
              </Alert>
            )}
            <Table>
              <TableHead>
                <TableRow>
                  <TableCell width="23%">Document</TableCell>
                  <TableCell width="10%">Uploaded</TableCell>
                  <TableCell width="10%">Approved</TableCell>
                  <TableCell width="40%">Actions</TableCell>
                  <TableCell width="1%" />
                </TableRow>
              </TableHead>
              <TableBody>
                {Object.keys(docs).map((docType) => (
                  <ManageDocumentRow
                    allDocsUploaded={allDocsUploaded()}
                    docs={docs}
                    userId={userId}
                    uuid={uuid}
                    docType={docType}
                    onChange={prepPayload}
                  />
                ))}
              </TableBody>
            </Table>

            <LoadingButton
              size="large"
              sx={{ mt: 1 }}
              disabled={!allDocsUploaded() ? true : !canSubmit()}
              fullWidth
              color="success"
              variant="contained"
              onClick={handleSubmit}
              loading={verifyDocsResults.isLoading}
            >
              Save
            </LoadingButton>
          </DialogContent>
        </>
      )}
    </Dialog>
  );
}

DocumentsDialog.propTypes = {
  open: PropTypes.bool,
  userId: PropTypes.string,
  uuid: PropTypes.string,
  docs: PropTypes.object,
  setViewDocuments: PropTypes.func.isRequired,
  name: PropTypes.string,
};
