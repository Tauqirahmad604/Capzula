import PropTypes from 'prop-types';
import { combineLatest } from 'rxjs';
import { useState, useEffect } from 'react';

import { paths } from 'src/routes/paths';
import { useRouter } from 'src/routes/hooks';

import { PARENT_HOST_URL } from 'src/config-global';
import { useGet2FaSummaryMutation } from 'src/redux/api/myAccount';
import {
  twoFactor$,
  enableTwoFactor,
  setTwoFactorOnLoad,
  twoFactorOnLoadSubject,
  twoFactorSuccessSubject,
} from 'src/lib/observables';

import { LoadingScreen } from 'src/components/loading-screen';
// ----------------------------------------------------------------------

export default function IframePage({ src, lang, requires2fa }) {
  const [isLoading, setIsLoading] = useState(true);
  const [currentSrc, setCurrentSrc] = useState(false);
  const [twoFaValid, setTwoFaValid] = useState(false);
  const router = useRouter();

  const [get2FaSummary, get2FaSummaryResult] = useGet2FaSummaryMutation();
  useEffect(() => {
    console.log('requires2fa!!');
    if (requires2fa) {
      get2FaSummary({
        type: 'temporary',
      });
    }
  }, [get2FaSummary, requires2fa]);

  useEffect(() => {
    if (get2FaSummaryResult.isSuccess) {
      const twoFaSessionSummary = get2FaSummaryResult.data?.data;
      if (!twoFaSessionSummary?.active) {
        enableTwoFactor();

        setTwoFactorOnLoad({
          ...twoFaSessionSummary,
          request_method: 'get',
        });
      } else {
        setTwoFaValid(true);
      }
    }
  }, [get2FaSummaryResult.data, get2FaSummaryResult.isSuccess]);

  useEffect(() => {
    const subscription = twoFactorSuccessSubject.subscribe(() => {
      setTwoFaValid(true);
    });

    return () => {
      subscription.unsubscribe();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    const subscription = combineLatest([twoFactor$, twoFactorOnLoadSubject]).subscribe(
      ([{ action, isActive }, request]) => {
        if (action === 'CANCEL_2FA') {
          if (request.request_method === 'get') {
            router.push(paths.error['401']);
          }
        }
      }
    );

    return () => {
      subscription.unsubscribe();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [router]);

  const replace_src = (srcToAppendLang) => {
    if (lang === 'en') {
      return srcToAppendLang;
    }
    return srcToAppendLang.replace(PARENT_HOST_URL, `${PARENT_HOST_URL}/${lang}`);
  };
  useEffect(() => {
    setCurrentSrc(false);

    if (currentSrc !== src) {
      setIsLoading(true);
      setCurrentSrc(src);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [src]);

  if (requires2fa && twoFaValid === false) {
    return <LoadingScreen />;
  }
  return (
    <>
      {/* <Helmet>
        <title></title>
      </Helmet> */}

      {isLoading && <LoadingScreen />}

      {src && (
        <iframe
          width="100%"
          style={{ display: isLoading ? 'none' : 'block', height: 'calc(100vh - 92px)' }}
          onLoad={() => setIsLoading(false)}
          onError={() => console.error('did not load!!')}
          frameBorder={0}
          title="My Account"
          src={replace_src(src)}
        />
      )}
    </>
  );
}

IframePage.propTypes = {
  src: PropTypes.string,
  lang: PropTypes.string,
  requires2fa: PropTypes.bool,
};
