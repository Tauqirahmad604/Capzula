import { Helmet } from 'react-helmet-async';

import PromotionsListView from 'src/sections/promotions/promotions-list-view';

// ----------------------------------------------------------------------

export default function PromotionsPage() {
  return (
    <>
      <Helmet>
        <title> Promotions</title>
      </Helmet>

      <PromotionsListView />
    </>
  );
}
