import { Helmet } from 'react-helmet-async';

import PromotionTagsListView from 'src/sections/promotion-tags/promotion-tags-list-view';


// ----------------------------------------------------------------------

export default function PromotionTagsPage() {
  return (
    <>
      <Helmet>
        <title> Promotions</title>
      </Helmet>

      <PromotionTagsListView />
    </>
  );
}
