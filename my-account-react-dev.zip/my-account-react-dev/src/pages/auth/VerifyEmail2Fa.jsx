import { Helmet } from 'react-helmet-async';

import TwoFaModule from 'src/sections/TwoFaModule/TwoFaModule';

// ----------------------------------------------------------------------

export default function VerifyEmail2FaPage() {
  return (
    <>
      <Helmet>
        <title> Verify Your Email</title>
      </Helmet>
      <style>
        {`
        body {
          background-color: red;
        }
      `}
      </style>
      <TwoFaModule open fullScreen defaultTwoFaType="verify_email" />
    </>
  );
}
