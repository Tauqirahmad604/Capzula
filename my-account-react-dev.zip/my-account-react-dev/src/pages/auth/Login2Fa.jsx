import { Helmet } from 'react-helmet-async';

import TwoFaModule from 'src/sections/TwoFaModule/TwoFaModule';

// ----------------------------------------------------------------------

export default function Login2Fa() {
  return (
    <>
      <Helmet>
        <title> Two-Factor Authentication</title>
      </Helmet>
      <style>
        {`
        body {
          background-color: red;
        }
      `}
      </style>
      <TwoFaModule open fullScreen defaultTwoFaType="session" />
    </>
  );
}
