import { Helmet } from 'react-helmet-async';
import ReviewsListView from 'src/sections/reviews/reviews-list-view';



// ----------------------------------------------------------------------

export default function ReviewsPage() {
  return (
    <>
      <Helmet>
        <title> Reviews</title>
      </Helmet>


      <ReviewsListView />
    </>
  );
}
