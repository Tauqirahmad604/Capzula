import { Helmet } from 'react-helmet-async';

import { PreLaunch } from 'src/sections/error';

// ----------------------------------------------------------------------

export default function PreLaunchPage() {
  return (
    <>
      <Helmet>
        <title> Coming soon</title>
      </Helmet>

      <PreLaunch />
    </>
  );
}
