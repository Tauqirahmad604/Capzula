import { Helmet } from 'react-helmet-async';

import { View403 } from 'src/sections/error';

// ----------------------------------------------------------------------

export default function UnauthorizedPage() {
  return (
    <>
      <Helmet>
        <title> You do not have access to this page</title>
      </Helmet>

      <View403 />
    </>
  );
}
