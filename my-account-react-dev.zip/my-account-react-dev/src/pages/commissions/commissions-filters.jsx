import { useState } from 'react';
import PropTypes from 'prop-types';

import { Stack } from '@mui/system';
import {
  Select,
  MenuItem,
  TextField,
  InputLabel,
  FormControl,
  OutlinedInput,
  InputAdornment,
} from '@mui/material';

import Iconify from 'src/components/iconify';

export default function CommissionsFilters({
  status,
  setStatus,
  priority,
  setPriority,
  search,
  setSearch,
}) {
  // const { user } = useAuthContext();
  const [localSearch, setLocalSearch] = useState(search);

  return (
    <Stack flexDirection="row" spacing={2} sx={{ mb: 2, p: 2 }}>
      {/* <Stack flex="30%">
        <FormControl>
          <InputLabel>Filter by Status</InputLabel>
          <Select
            value={status}
            onChange={(e) => setStatus(e.target.value)}
            input={<OutlinedInput label="Filter by Status" />}
          >
            <MenuItem value="all">All</MenuItem>
            {Object.entries(internalStatuses).map(([key, value], i) => (
              <MenuItem key={key} value={value}>
                {getInternalStatusTitlesByRole(value, user.role).current_status}
              </MenuItem>
            ))}
          </Select>
        </FormControl>
      </Stack> */}
      <Stack flex="20%">
        <FormControl>
          <InputLabel>Filter by Priority</InputLabel>
          <Select
            value={priority}
            onChange={(e) => setPriority(e.target.value)}
            input={<OutlinedInput label="Filter by Priority" />}
          >
            <MenuItem value="all">All</MenuItem>
            <MenuItem value="on-track">On Track</MenuItem>
            <MenuItem value="due-today">Due Today</MenuItem>
            <MenuItem value="overdue">Overdue</MenuItem>
          </Select>
        </FormControl>
      </Stack>
      <Stack flex="50%">
        <FormControl>
          <TextField
            fullWidth
            value={localSearch}
            onChange={(e) => setLocalSearch(e.target.value)}
            onBlurCapture={() => setSearch(localSearch)}
            placeholder="Search by Order ID, etc."
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  <Iconify icon="eva:search-fill" sx={{ color: 'text.disabled' }} />
                </InputAdornment>
              ),
            }}
          />
        </FormControl>
      </Stack>
    </Stack>
  );
}

CommissionsFilters.propTypes = {
  status: PropTypes.string,
  setStatus: PropTypes.func,
  priority: PropTypes.string,
  setPriority: PropTypes.func,
  search: PropTypes.string,
  setSearch: PropTypes.func,
};
