import PropTypes from 'prop-types';
// eslint-disable-next-line import/no-extraneous-dependencies
import copy from 'copy-to-clipboard';
import { Link } from 'react-router-dom';
import { useState, useEffect } from 'react';

import { Stack } from '@mui/system';
import { LoadingButton } from '@mui/lab';
import { styled } from '@mui/material/styles';
import {
  List,
  Table,
  Badge,
  Avatar,
  Tooltip,
  ListItem,
  TableRow,
  Collapse,
  TableCell,
  TextField,
  Typography,
  IconButton,
  TableContainer,
  CircularProgress,
} from '@mui/material';

import { paths } from 'src/routes/paths';

import { useBoolean } from 'src/hooks/use-boolean';

import { fCurrency } from 'src/utils/format-number';

import { useAuthContext } from 'src/auth/hooks';
import { useChangeCommissionStatusMutation } from 'src/redux/api/myAccount';

import Iconify from 'src/components/iconify';

export default function CommissionQuickSummaryRow({ commission, status, key, handleNotice }) {
  const [transactionId, setTransactionId] = useState('');
  const { user } = useAuthContext();
  const collapse = useBoolean(false);
  const [changeCommissionStatus, changeCommissionStatusResult] =
    useChangeCommissionStatusMutation();

  const copyToClipboard = (text) => {
    try {
      copy(text);
      handleNotice('Copied to clipboard', 'info');
    } catch (e) {
      handleNotice('Failed to copy to clipboard', 'error');
    }
  };
  const handleChangeStatus = () => {
    // validate transaction id and pass custom payload
    if (!transactionId) {
      handleNotice('Transaction ID is required', 'error');
      return;
    }
    // eslint-disable-next-line no-case-declarations
    const commission_ids = commission?.commission_ids;

    const commissionData = {
      body: {
        ids: commission_ids,
        status,
        transactionId,
      },
    };
    changeCommissionStatus(commissionData);
  };
  useEffect(() => {
    if (changeCommissionStatusResult.isSuccess) {
      handleNotice('Commission status updated successfully', 'success');
      setTransactionId('');
    }
    if (changeCommissionStatusResult.isError) {
      handleNotice(changeCommissionStatusResult?.error?.data?.data, 'error');
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [changeCommissionStatusResult]);

  function areAllValuesFalse(obj) {
    // Get all the values of the object
    const values = Object.values(obj);

    // Filter the values to find those that are not false
    const nonFalseValues = values.filter(value => {
      // If the value is an object (but not an array), recursively check its values
      if (typeof value === 'object' && !Array.isArray(value)) {
        return !areAllValuesFalse(value);
      }
      // If the value is not false, keep it
      return value !== false;
    });

    // If the array of non-false values is empty, all values are false
    return nonFalseValues.length === 0;
  }

  const SmallAvatar = styled(Avatar)(({ theme }) => ({
    width: 22,
    height: 22,
    border: `2px solid ${theme.palette.background.paper}`,
  }));

  const renderSecondary = (
    <TableRow
      sx={{
        width: '100%',
      }}
    >
      <TableCell sx={{ p: 0 }} colSpan={100}>
        <Collapse
          in={collapse.value}
          unmountOnExit
        // sx={{ bgcolor: 'background.neutral' }}
        >
          <TableContainer>
            <Table size="small">
              {commission?.children &&
                Object.entries(commission?.children)?.map(([index, child]) => (
                  <TableRow
                    key={index}
                    sx={{
                      backgroundColor: child?.is_locked && 'background.neutral',
                      '*': { color: child?.is_locked && '#b8b8b8' },
                    }}
                  >
                    <TableCell width="8%">
                      <List sx={{ p: 0 }}>
                        {child.order_ids?.map((order_id) => (
                          <ListItem key={order_id} sx={{ p: 0 }}>
                            {user.role === 'admin' ? (
                              <Link to={`${paths.orders.edit}/${order_id}`} target="_blank">
                                {order_id}
                              </Link>
                            ) : (
                              order_id
                            )}
                          </ListItem>
                        ))}
                      </List>
                    </TableCell>
                    <TableCell width="18%">
                      <Tooltip title={child.vendor_data.name}>
                        <Stack flexDirection="row" alignItems="center" spacing={0}>
                          <Badge
                            overlap="circular"
                            anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
                            badgeContent={<SmallAvatar src={child.vendor_data.flag} />}
                          >
                            <Avatar
                              alt={child.vendor_data.name}
                              src={child.vendor_data.avatar}
                              sx={{ mr: 1, border: '1px solid rgba(0,0,0,0.1)' }}
                            />
                          </Badge>
                          <Typography variant="body2" noWrap>
                            {child.vendor_data.name}
                          </Typography>
                        </Stack>
                      </Tooltip>
                    </TableCell>
                    <TableCell width="15%">
                      <Stack direction="column" spacing={0.5} alignItems="center">
                        <Stack direction="column" alignItems="center">
                          {child?.outstanding_refunds && (
                            <>
                              <Typography
                                variant="body2"
                                sx={{ fontSize: 12, color: 'secondary.light' }}
                              >
                                <del>{fCurrency(child.original_amount)}</del>
                              </Typography>
                              {child?.outstanding_refunds?.refund_ids?.map((id, i) => (
                                <Typography variant="body2" sx={{ fontSize: 12, color: 'red' }}>
                                  {fCurrency(child?.outstanding_refunds?.refund_amounts[i])}
                                  <Tooltip title={`Refund for Id ${id}`}>
                                    <Iconify
                                      icon="mdi:alert-circle-outline"
                                      color="#333"
                                      width={12}
                                      sx={{ ml: '2px' }}
                                    />
                                  </Tooltip>
                                </Typography>
                              ))}
                            </>
                          )}
                          <Stack>{child?.amount ? fCurrency(child.amount) : '$0.00'}</Stack>
                        </Stack>
                      </Stack>
                    </TableCell>
                    <TableCell width="60%" />
                  </TableRow>
                ))}
            </Table>
          </TableContainer>
        </Collapse>
      </TableCell>
    </TableRow>
  );

  return (
    <>
      <TableRow
        key={key}
        sx={{
          backgroundColor: commission?.is_locked && 'background.neutral',
          '*': { color: commission?.is_locked && '#b8b8b8' },
        }}
      >
        <TableCell>
          {changeCommissionStatusResult.isLoading ? (
            <Stack justifyContent="center" alignItems="center">
              <CircularProgress size={20} thickness={5} color="secondary" />
            </Stack>
          ) : (
            <List>
              {commission?.children ? (
                <ListItem sx={{ p: 0 }}>{commission.order_ids.length} Orders</ListItem>
              ) : (
                commission.order_ids?.map((order_id) => (
                  <ListItem key={order_id} sx={{ p: 0 }}>
                    {user.role === 'admin' ? (
                      <Link to={`${paths.orders.edit}/${order_id}`} target="_blank">
                        {order_id}
                      </Link>
                    ) : (
                      order_id
                    )}
                  </ListItem>
                ))
              )}
            </List>
          )}
        </TableCell>
        <TableCell>
          {changeCommissionStatusResult.isLoading ? (
            <Stack justifyContent="center" alignItems="center">
              <CircularProgress size={20} thickness={5} color="secondary" />
            </Stack>
          ) : (
            <>
              {commission?.vendor_data ? (
                <Tooltip title={commission.vendor_data.name}>
                  <Stack flexDirection="row" alignItems="center" spacing={0}>
                    <Badge
                      overlap="circular"
                      anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
                      badgeContent={<SmallAvatar src={commission.vendor_data.flag} />}
                    >
                      <Avatar
                        alt={commission.vendor_data.name}
                        src={commission.vendor_data.avatar}
                        sx={{ mr: 1, border: '1px solid rgba(0,0,0,0.1)' }}
                      />
                    </Badge>
                    <Typography variant="body2" noWrap>
                      {commission.vendor_data.name}
                    </Typography>
                  </Stack>
                </Tooltip>
              ) : (
                <List>
                  {commission.vendor_names?.map((name, i) => (
                    <ListItem key={i} sx={{ p: 0 }}>
                      {name}
                    </ListItem>
                  ))}
                </List>
              )}
            </>
          )}
        </TableCell>
        <TableCell>
          {changeCommissionStatusResult.isLoading ? (
            <Stack justifyContent="center" alignItems="center">
              <CircularProgress size={20} thickness={5} color="secondary" />
            </Stack>
          ) : (
            <Stack direction="row" spacing={0.5} alignItems="center">
              <Stack>{commission?.amount ? fCurrency(commission.amount) : '$0.00'}</Stack>
              <Stack direction="row" alignItems="center">
                {commission?.outstanding_refunds && !areAllValuesFalse(commission?.outstanding_refunds) && (
                  <Tooltip
                    title={
                      <Stack>
                        <Typography variant="subtitle2"> {status !== 'payment_confirmed_at_bank' ? "Summary" : "There are outstanding refunds for these commissions. Expand for more details"} </Typography>
                        {commission?.outstanding_refunds?.refund_ids?.map((id, index) => (
                          <Typography variant="body2" sx={{ fontSize: 12 }}>
                            Refund for Order Id {id}:{' '}
                            {commission?.outstanding_refunds?.refund_amounts &&
                              fCurrency(commission?.outstanding_refunds?.refund_amounts[index])}
                          </Typography>
                        ))}
                      </Stack>
                    }



                  >
                    <Iconify icon="mdi:alert-circle-outline" color="#333" width={14} />
                  </Tooltip>
                )}
                <IconButton onClick={() => copyToClipboard(commission?.amount)}>
                  <Iconify icon="iconoir:paste-clipboard" color="#333" width={14} />
                </IconButton>
              </Stack>
            </Stack>
          )}
        </TableCell>
        <TableCell>
          {changeCommissionStatusResult.isLoading ? (
            <Stack justifyContent="center" alignItems="center">
              <CircularProgress size={20} thickness={5} color="secondary" />
            </Stack>
          ) : (
            <Stack>
              <Typography variant="subtitle2">IBAN</Typography>
              <Typography variant="body2">
                <Stack>{commission?.bank_details?.name}</Stack>
                <Stack direction="row" alignItems="center">
                  {commission?.bank_details?.iban}
                  <IconButton onClick={() => copyToClipboard(commission?.bank_details?.iban)}>
                    <Iconify icon="iconoir:paste-clipboard" color="#333" width={14} />
                  </IconButton>
                </Stack>
              </Typography>
            </Stack>
          )}
        </TableCell>
        <TableCell>
          {changeCommissionStatusResult.isLoading ? (
            <Stack justifyContent="center" alignItems="center">
              <CircularProgress size={20} thickness={5} color="secondary" />
            </Stack>
          ) : (
            <TextField
              label="Transaction ID"
              required
              onChange={(e) => setTransactionId(e.target.value)}
              value={transactionId}
              disabled={commission?.is_locked}
              sx={{
                minWidth: 200,
              }}
            />
          )}
        </TableCell>
        <TableCell>
          <Stack direction="row" spacing={1} justifyContent="end">
            {commission?.children && (
              <IconButton onClick={() => collapse.onToggle()}>
                <Iconify icon="eva:arrow-ios-downward-fill" color="#333" width={20} />
              </IconButton>
            )}
            {commission.is_locked ? (
              <LoadingButton variant="outlined" color="secondary" disabled>
                Confirm
              </LoadingButton>
            ) : (
              <LoadingButton
                variant="outlined"
                color="secondary"
                onClick={() => handleChangeStatus()}
                loading={changeCommissionStatusResult.isLoading}
              >
                Confirm
              </LoadingButton>
            )}
          </Stack>
        </TableCell>
      </TableRow>

      {commission?.children && renderSecondary}
    </>
  );
}

CommissionQuickSummaryRow.propTypes = {
  commission: PropTypes.object.isRequired,
  status: PropTypes.string.isRequired,
  key: PropTypes.string.isRequired,
  handleNotice: PropTypes.func.isRequired,
};
