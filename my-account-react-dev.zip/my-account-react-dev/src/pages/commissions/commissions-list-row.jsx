import PropTypes from 'prop-types';
import { Link } from 'react-router-dom';

import { Box, Stack } from '@mui/system';
import {
  Paper,
  Avatar,
  Tooltip,
  Divider,
  Collapse,
  TableRow,
  Checkbox,
  TableCell,
  IconButton,
  Typography,
  ListItemText,
  LinearProgress,
} from '@mui/material';

import { paths } from 'src/routes/paths';

import { useBoolean } from 'src/hooks/use-boolean';

import { fDate } from 'src/utils/format-time';
import { fCurrency } from 'src/utils/format-number';

import { useAuthContext } from 'src/auth/hooks';

import Label from 'src/components/label';
import Iconify from 'src/components/iconify';

import { internalStatuses, getInternalStatusTitlesByRole } from './constants';

export default function CommissionsListRow({
  row,
  status,
  setCommission,
  setViewCommission,
  getLabel,
  getTimeLapsed,
  selectedCommissions,
  setSelectedCommissions,
  allowBulkActions,
  getCommissionTotal,
}) {
  const { user } = useAuthContext();

  const collapse = useBoolean();

  // const nextInternalStatus = () => {
  //     if (user.role === 'admin') {
  //       switch (row?.internal_status) {
  //         case internalStatuses.AWAITING_PAYMENT_TO_BANK:
  //           return internalStatuses.PAYMENT_CONFIRMED_AT_BANK;
  //         case internalStatuses.PAYMENT_CONFIRMED_AT_BANK:
  //           return row?.is_international
  //             ? internalStatuses.FUNDS_TRANSFERED_TO_PAYMENT_PARTNER
  //             : internalStatuses.PAID;
  //         default:
  //           return false;
  //       }
  //     }

  //     if (user.role === 'payment_partner') {
  //       switch (row?.internal_status) {
  //         case internalStatuses.FUNDS_TRANSFERED_TO_PAYMENT_PARTNER:
  //           return internalStatuses.FUNDS_RECIEVED;
  //         case internalStatuses.FUNDS_RECIEVED:
  //           return internalStatuses.PAID;
  //         default:
  //           return false;
  //       }
  //     }
  //     return false;
  // };

  const getProgress = () => {
    if (row?.is_international) {
      switch (row?.internal_status) {
        case internalStatuses.AWAITING_PAYMENT_TO_BANK:
          return 20;
        case internalStatuses.PAYMENT_CONFIRMED_AT_BANK:
          return 40;
        case internalStatuses.FUNDS_TRANSFERED_TO_PAYMENT_PARTNER:
          return 60;
        case internalStatuses.FUNDS_RECIEVED:
          return 80;
        case internalStatuses.PAID:
          return 100;
        default:
          return 0;
      }
    }

    switch (row?.internal_status) {
      case internalStatuses.AWAITING_PAYMENT_TO_BANK:
        return 33.3;
      case internalStatuses.PAYMENT_CONFIRMED_AT_BANK:
        return 66.6;
      case internalStatuses.PAID:
        return 100;
      default:
        return 0;
    }
  };

  const renderPrimary = (
    <TableRow
      key={row.id}
      sx={{
        '&:last-child td, &:last-child th': { border: 0 },
        opacity:
          (user.role === 'payment_partner' &&
            row?.internal_status === internalStatuses.AWAITING_PAYMENT_TO_BANK) ||
            (user.role === 'payment_partner' &&
              row.internal_status === internalStatuses.PAYMENT_CONFIRMED_AT_BANK)
            ? '0.75'
            : '1',
        backgroundColor:
          (user.role === 'payment_partner' &&
            row?.internal_status === internalStatuses.AWAITING_PAYMENT_TO_BANK) ||
            (user.role === 'payment_partner' &&
              row.internal_status === internalStatuses.PAYMENT_CONFIRMED_AT_BANK)
            ? 'rgba(0,0,0,0.1)'
            : 'inherit',
      }}
    >
      {status !== 'all' &&
        status !== 'paid' &&
        (user.role === 'admin' || user.role === 'payment_partner') &&
        allowBulkActions && (
          <TableCell>
            <Checkbox
              onClick={() => {
                // save the entire commission object
                if (selectedCommissions.includes(row.id)) {
                  setSelectedCommissions(selectedCommissions.filter((id) => id !== row.id));
                } else {
                  setSelectedCommissions([...selectedCommissions, row.id]);
                }
              }}
              checked={selectedCommissions.length > 0 && selectedCommissions.includes(row.id)}
            />
          </TableCell>
        )}
      <TableCell>{fDate(row?.created_at)}</TableCell>
      <TableCell>
        <Link
          to={`${paths.orders.edit}/${row?.order_id}`}
          noWrap
          color="inherit"
          variant="subtitle2"
          sx={{ cursor: 'pointer' }}
        >
          #{row?.order_id}
        </Link>
      </TableCell>
      <TableCell>
        <Tooltip title={row?.vendor.name}>
          <Stack flexDirection="row" alignItems="center">
            <Avatar
              alt={row?.vendor.name}
              src={row?.vendor.avatar}
              sx={{ mr: 2, border: '1px solid rgba(0,0,0,0.1)' }}
            />
            <Typography variant="body2" noWrap>
              {' '}
              {row?.vendor.name}{' '}
            </Typography>
          </Stack>
        </Tooltip>
      </TableCell>
      <TableCell>
        <Stack spacing={0.5} flexDirection="row" alignItems="center">

          {fCurrency(row.original_amount - row.amount)}
          <Tooltip
            title={
              <Stack spacing={0.5}>
                {row?.fee_breakdown?.map((fee, index) => (
                  <Stack key={index} direction="row" spacing={3} justifyContent="space-between" >
                    <Typography variant="body4" sx={{ color: 'white' }}>
                      {fee.key}
                    </Typography>
                    <Typography variant="body4" sx={{ color: fee.color }} >
                      {fee.prefix && `${fee.prefix} `}
                      {fCurrency(fee.value)}
                      {fee.showDivider && <Divider sx={{ backgroundColor: 'white', mt:0.5 }} />}
                    </Typography>
                  </Stack>
                ))}
                <Stack direction="row" spacing={3} justifyContent="space-between" alignItems="center">
                  <Typography variant="body4" color="text.light">
                    Commission Amount
                  </Typography>
                  <Typography variant="body2" color="text.light">
                    {fCurrency(row.amount)}
                  </Typography>
                </Stack>

              </Stack>
            }
          >
            <Iconify icon="mdi:alert-circle-outline" color="#333" width={14} />
          </Tooltip>
        </Stack>
      </TableCell>
      <TableCell>
        
        {parseFloat(getCommissionTotal(row)) !== parseFloat(row.amount) ? (
          <>
          <Tooltip title="Some refunds we're recovered on this commission, View more details in expanded summary">
            <Typography variant="body2" color="secondary.light">
              <Stack direction="row" gap={0.5} alignItems="center" >
                <del>{fCurrency(row.amount)}</del>
                <Iconify icon="mdi:alert-circle-outline" color="secondary.light" width={12} />
              </Stack>
            </Typography>
          </Tooltip>
          <Typography variant="body2" >
           {fCurrency(getCommissionTotal(row))}
          </Typography>
          </>
        ) : (
          fCurrency(getCommissionTotal(row))
        )}
        {/* {row.amount ? fCurrency(row.amount) : fCurrency('0')} */}


      </TableCell>
      {user.role === 'admin' && <TableCell>{fCurrency(row?.original_amount)}</TableCell>}
      {(user.role === 'admin' || user.role === 'payment_partner') && (
        <TableCell>{getTimeLapsed(row?.updated_at, row?.internal_status)}</TableCell>
      )}
      {(user.role === 'admin' || user.role === 'payment_partner') && (
        <TableCell>
          <Label>
            {getInternalStatusTitlesByRole(row?.internal_status, user.role).current_status}
          </Label>
        </TableCell>
      )}

      <TableCell>{getLabel(row?.status)}</TableCell>
      <TableCell>
        <LinearProgress variant="determinate" value={getProgress()} />
      </TableCell>
      <TableCell>
        <Stack flexDirection="row" justifyContent="flex-end">
          <IconButton onClick={() => collapse.onToggle()}>
            <Iconify icon="eva:arrow-ios-downward-fill" />
          </IconButton>
          <IconButton
            onClick={() => {
              setCommission(row);
              setViewCommission();
            }}
            color="default"
          >
            <Iconify icon="solar:eye-bold" />
          </IconButton>
          {/* {(user.role === 'admin' || user.role === 'payment_partner') && (
                        <IconButton onClick={(e) => handleOpenPopover(e)}>
                            <Iconify icon="eva:more-vertical-fill" />
                        </IconButton>
                    )} */}
        </Stack>
      </TableCell>
    </TableRow>
  );

  const renderSecondary = (
    <TableRow>
      <TableCell sx={{ p: 0, border: 'none' }} colSpan={12}>
        <Collapse
          in={collapse.value}
          timeout="auto"
          unmountOnExit
          sx={{ bgcolor: 'background.neutral' }}
        >
          <Stack flexDirection="column" component={Paper} sx={{ m: 1.5 }}>
            {row?.product.map((product) => (
              <Stack
                flexDirection="row"
                alignItems="center"
                sx={{
                  p: (theme) => theme.spacing(1.5, 2, 1.5, 1.5),
                  '&:not(:last-of-type)': {
                    borderBottom: (theme) => `solid 2px ${theme.palette.background.neutral}`,
                  },
                }}
              >
                <Avatar
                  alt={product?.name}
                  src={product?.image}
                  variant="rounded"
                  sx={{ width: 64, height: 64, mr: 2 }}
                />

                <ListItemText
                  width="100%"
                  disableTypography
                  primary={
                    <Link
                      noWrap
                      color="inherit"
                      variant="subtitle2"
                      onClick={() => window.open(product?.permalink, '_blank')}
                      sx={{ cursor: 'pointer' }}
                    >
                      {product?.name}
                    </Link>
                  }
                  secondary={
                    <Box component="div" sx={{ typography: 'body2', color: 'text.disabled' }}>
                      {product?.sku}
                    </Box>
                  }
                />
              </Stack>
            ))}
          </Stack>
        </Collapse>
      </TableCell>
    </TableRow>
  );

  return (
    <>
      {renderPrimary}

      {renderSecondary}
    </>
  );
}

CommissionsListRow.propTypes = {
  row: PropTypes.object.isRequired,
  status: PropTypes.string,
  setCommission: PropTypes.func,
  setViewCommission: PropTypes.func,
  getLabel: PropTypes.func,
  getTimeLapsed: PropTypes.func,
  selectedCommissions: PropTypes.array,
  setSelectedCommissions: PropTypes.func,
  allowBulkActions: PropTypes.string,
  getCommissionTotal: PropTypes.func,
};
