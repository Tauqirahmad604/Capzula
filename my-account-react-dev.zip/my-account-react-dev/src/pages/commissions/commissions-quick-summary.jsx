import PropTypes from 'prop-types';
// eslint-disable-next-line import/no-extraneous-dependencies

import { useEffect } from 'react';
import { useSnackbar } from 'notistack';

import { Stack } from '@mui/system';
import { LoadingButton } from '@mui/lab';
import {
  Table,
  Dialog,
  TableRow,
  TableHead,
  TableCell,
  TableBody,
  DialogTitle,
  DialogActions,
  DialogContent,
  TableContainer,
  DialogContentText,
} from '@mui/material';

import { fCurrency } from 'src/utils/format-number';

import { useGetCalculatedCommissionAmountQuery } from 'src/redux/api/myAccount';

import EmptyContent from 'src/components/empty-content';
import { LoadingScreen } from 'src/components/loading-screen';

import CommissionQuickSummaryRow from './summary/commission-quick-summary-row';

export default function CommissionsQuickSummary({
  open,
  onClose,
  commissions,
  selectedCommissions,
  status,
  handleProceed,
  isLoading,
}) {
  const {
    data: calculatedCommissionsData,
    isFetching,
    isError,
    error,
  } = useGetCalculatedCommissionAmountQuery({ ids: selectedCommissions, status });

  useEffect(() => {
    if (calculatedCommissionsData?.data.length === 0) {
      onClose();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [calculatedCommissionsData]);

  const { enqueueSnackbar } = useSnackbar();

  const handleNotice = (message, variant) => {
    enqueueSnackbar(message, { variant });
  }

  const handleChangeStatus = () => {
    switch (status) {
      case 'awaiting_payment_to_bank':
        handleProceed();
        break;
      default:
        break;
    }
  };

  return (
    <Dialog fullWidth maxWidth="xl" open={open} onClose={onClose}>
      <DialogTitle>Quick Summary</DialogTitle>
      {isFetching && <LoadingScreen />}
      {isError &&
        <DialogContent>
          <Stack alignItems="center" sx={{p: 3}}>
            <EmptyContent title={error?.data?.data || 'An error occured while fetching commissions'} />
            
          </Stack>
        </DialogContent>
      }

      {!isFetching && !isError && (
        <>
          <DialogContent>
            <DialogContentText>
              {status === 'awaiting_payment_to_bank' &&
                'You are about to confirm that the payment has arrived for the following commissions:'}
              {status === 'payment_confirmed_at_bank' &&
                'You are required to confirm transfer of funds to the following accounts and enter the transaction identifier:'}
              {status === 'funds_recieved' &&
                'You are required to confirm that the payment has been made to the seller for the following commissions:'}
            </DialogContentText>
            <Stack sx={{ mt: 2 }}>
              {status === 'awaiting_payment_to_bank' && (
                <TableContainer>
                  <Table>
                    <TableHead>
                      <TableRow>
                        <TableCell>Order ID</TableCell>
                        <TableCell>Amount</TableCell>
                      </TableRow>
                    </TableHead>
                    <TableBody>
                      {commissions.map(
                        (commission) =>
                          selectedCommissions.includes(commission.id) && (
                            <TableRow key={commission.id}>
                              <TableCell>{commission.order_id}</TableCell>
                              <TableCell>{fCurrency(commission.original_amount)}</TableCell>
                            </TableRow>
                          )
                      )}
                    </TableBody>
                  </Table>
                </TableContainer>
              )}
              {(status === 'payment_confirmed_at_bank' || status === 'funds_recieved') && (
                <TableContainer>
                  <Table>
                    <TableHead>
                      <TableRow>
                        <TableCell width="10%">Order ID</TableCell>
                        <TableCell width="20%">Seller</TableCell>
                        <TableCell width="10%">Amount</TableCell>
                        <TableCell width="30%">Bank Account</TableCell>
                        <TableCell width="30%">Transaction Id</TableCell>
                        <TableCell width="10%">Action</TableCell>
                      </TableRow>
                    </TableHead>
                    <TableBody>
                      {Object.entries(calculatedCommissionsData?.data).map(([key, commission]) => (
                        <CommissionQuickSummaryRow
                          key={key}
                          status={status}
                          commission={commission}
                          handleNotice={(message, variant) => handleNotice(message, variant)}
                        />
                      ))}
                    </TableBody>
                  </Table>
                </TableContainer>
              )}
            </Stack>
          </DialogContent>
          <DialogActions>
            <LoadingButton variant="outlined" color="error" onClick={onClose} disabled={isLoading}>
              Cancel
            </LoadingButton>
            {status !== 'payment_confirmed_at_bank' && status !== 'funds_recieved' && (
              <LoadingButton
                variant="contained"
                color="secondary"
                loading={isLoading}
                onClick={handleChangeStatus}
              >
                Proceed
              </LoadingButton>
            )}
          </DialogActions>
        </>
      )}
    </Dialog>
  );
}

CommissionsQuickSummary.propTypes = {
  open: PropTypes.bool,
  onClose: PropTypes.func,
  commissions: PropTypes.object,
  selectedCommissions: PropTypes.array,
  status: PropTypes.string,
  handleProceed: PropTypes.func,
  isLoading: PropTypes.bool,
};
