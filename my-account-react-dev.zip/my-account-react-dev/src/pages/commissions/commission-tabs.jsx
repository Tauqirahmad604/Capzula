import PropTypes from 'prop-types';

import { Stack } from '@mui/system';
import { Tab, Tabs, CircularProgress } from '@mui/material';

import Label from 'src/components/label';

export default function CommissionTabs({
  role,
  status,
  setStatus,
  setSelectedCommissions,
  commissionCount,
  isLoading,
}) {
  const handleChange = (event, newValue) => {
    setStatus(newValue);
    setSelectedCommissions([]);
  };
  const getLabel = (label, count) => (
    <Stack direction="row" alignItems="center">
      {label}
      <Label
        sx={{
          ml: 2,
        }}
      >
        {isLoading ? <CircularProgress size={14} color="secondary" /> : count}
      </Label>
    </Stack>
  );
  return (
    <Tabs sx={{ p: 2, pb: 0 }} onChange={handleChange} value={status}>
      <Tab label={getLabel('All', commissionCount?.all)} value="all" />
      {role === 'admin' && (
        <Tab
          label={getLabel('Awaiting Payment To Bank', commissionCount?.awaiting_payment_to_bank)}
          value="awaiting_payment_to_bank"
        />
      )}
      {role === 'admin' && (
        <Tab
          label={getLabel('Confirm funds transfered', commissionCount?.payment_confirmed_at_bank)}
          value="payment_confirmed_at_bank"
        />
      )}
      <Tab
        label={getLabel(
          'Confirm funds received',
          commissionCount?.funds_transfered_to_payment_partner
        )}
        value="funds_transfered_to_payment_partner"
      />
      <Tab
        label={getLabel('Confirm payment to Seller', commissionCount?.funds_recieved)}
        value="funds_recieved"
      />
      <Tab label={getLabel('Paid', commissionCount?.paid)} value="paid" />
    </Tabs>
  );
}

CommissionTabs.propTypes = {
  role: PropTypes.string,
  status: PropTypes.string,
  setStatus: PropTypes.func,
  setSelectedCommissions: PropTypes.func,
  commissionCount: PropTypes.object,
  isLoading: PropTypes.bool,
};
