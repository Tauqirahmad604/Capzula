import PropTypes from 'prop-types';
import { useState, useEffect } from 'react';
import { enqueueSnackbar } from 'notistack';

import { Box } from '@mui/system';
import {
  Card,
  Alert,
  Button,
  Dialog,
  Checkbox,
  IconButton,
  Typography,
  CardContent,
  DialogTitle,
  DialogContent,
  DialogActions,
  CircularProgress,
} from '@mui/material';

import { paths } from 'src/routes/paths';
import { useRouter } from 'src/routes/hooks';
import { RouterLink } from 'src/routes/components';

import {
  useAddLogisticCompanyMutation,
  useRemoveLogisticCompanyMutation,
  useGetLogisticPartnersSummaryQuery,
} from 'src/redux/api/myAccount';

import Iconify from 'src/components/iconify';
import AddressWithName from 'src/components/AddressWithName/AddressWithName';

import LogisticPartnerRow from './LogisticPartnerRow';

function EditLogisticPartnersContent({
  countryId,
  stateId,
  addLp,
  logisticSummaryIsLoading,
  logisticSummaryIsFetching,
  countryStatePartners,
  // showForm,
  // checkout,
}) {
  const [removeLogisticCompany, removeLogisticCompanyResults] = useRemoveLogisticCompanyMutation();
  const [addLogisticCompany, addLogisticCompanyResults] = useAddLogisticCompanyMutation();
  const [lastTouchedI, setLastTouchedI] = useState(null);
  const [addYourOwn, setAddYourOwn] = useState(false);
  useEffect(() => {
    if (removeLogisticCompanyResults.isSuccess) {
      enqueueSnackbar('Removed logistics company', { variant: 'success' });
    }
    if (removeLogisticCompanyResults.isError) {
      enqueueSnackbar('Unable to remove logistics company', { variant: 'error' });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [removeLogisticCompanyResults]);

  useEffect(() => {
    if (addLogisticCompanyResults.isSuccess) {
      enqueueSnackbar('Selected logistics company', { variant: 'success' });
    }
    if (addLogisticCompanyResults.isError) {
      enqueueSnackbar('Unable to select logistics company', { variant: 'error' });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [addLogisticCompanyResults]);

  const toggleLogisticPartner = (e, partnerId) => {
    const { checked } = e.target;
    if (!checked) {
      removeLogisticCompany({
        country_code: countryId,
        state_code: stateId,
      });
    }

    if (checked) {
      addLogisticCompany({
        country_code: countryId,
        state_code: stateId,
        partner_id: partnerId,
      });
    }
  };

  const isLoading = () =>
    addLogisticCompanyResults.isLoading ||
    removeLogisticCompanyResults.isLoading ||
    logisticSummaryIsLoading ||
    logisticSummaryIsFetching;

  return (
    <div>
      {countryStatePartners?.useMyOwn && (
        <Alert severity="secondary" sx={{ mb: 2 }}>
          <Typography variant="body2">
            You have selected to use your own logistics company to export your items. If you would
            like to use one of our logistics partners instead, please remove your logistics company.
          </Typography>
          <Button
            onClick={() =>
              removeLogisticCompany({
                country_code: countryId,
                state_code: stateId,
              })
            }
            variant="outlined"
            color="error"
            sx={{ mt: 2 }}
          >
            Remove this logistics company
          </Button>
        </Alert>
      )}
      {addYourOwn ? (
        <AddressWithName
          data={countryStatePartners?.selectedLogisticBusinessData?.business_details}
        />
      ) : (
        <>
          {countryStatePartners?.partners?.length <= 0 ? (
            <Alert severity="warning">
              <Typography variant="body2">
                We do not have logistic partners in this state. Please add your own logistics
                company below.
              </Typography>
            </Alert>
          ) : (
            countryStatePartners?.partners?.map((partner, i) => (
              <Card key={partner.id} sx={{ mb: 2 }}>
                <CardContent>
                  <Box gap={2} display="flex" alignItems="center">
                    <LogisticPartnerRow businessData={partner} />
                    <Box>
                      {isLoading() && i === lastTouchedI ? (
                        <CircularProgress size={30} />
                      ) : (
                        <Checkbox
                          onChange={(e) => {
                            setLastTouchedI(i);
                            toggleLogisticPartner(e, partner.id);
                          }}
                          checked={partner.is_selected}
                          id="test"
                          name="test"
                          disabled={isLoading()}
                        />
                      )}
                    </Box>
                  </Box>
                </CardContent>
              </Card>
            ))
          )}

          <Box sx={{ mt: 2 }} textAlign="center" justifyContent="center" width="100%">
            <Typography variant="body2" fontWeight="600">
              Already have your own Logistics Company to export your items?{' '}
            </Typography>
            <Button
              // size="small"
              onClick={() => setAddYourOwn(true)}
              sx={{ mt: 1 }}
              variant="outlined"
            >
              Add your own
            </Button>
          </Box>
        </>
      )}
    </div>
  );
}

EditLogisticPartnersContent.propTypes = {
  countryId: PropTypes.string,
  stateId: PropTypes.string,
  addLp: PropTypes.bool,
  logisticSummaryIsLoading: PropTypes.bool,
  logisticSummaryIsFetching: PropTypes.bool,
  countryStatePartners: PropTypes.object,
  // showForm: PropTypes.bool,
  // checkout: PropTypes.bool,
};

export default function EditLogisticPartnersDialog({
  countryId,
  stateId,
  addLp,
  embeded,
  checkout,
  isOpen = null,
  onClose = null,
}) {
  const {
    data,
    isLoading: logisticSummaryIsLoading,
    isFetching: logisticSummaryIsFetching,
  } = useGetLogisticPartnersSummaryQuery();

  const router = useRouter();

  const getSelectedCountryStatePartners = () => {
    if (data) {
      const countryStates = data.data.find((country) => country.country_code === countryId);
      return {
        countryName: countryStates?.country_title,
        stateName: countryStates?.by_state?.[stateId]?.state_name,
        partners: countryStates?.by_state?.[stateId]?.partners,
        useMyOwn: countryStates?.by_state?.[stateId]?.selected_logistic_business_data?.use_my_own,
        selectedLogisticBusinessData:
          countryStates?.by_state?.[stateId]?.selected_logistic_business_data,
      };
    }
    return null;
  };

  const countryStatePartners = getSelectedCountryStatePartners();

  const showForm = countryStatePartners?.useMyOwn || addLp;

  return (
    <>
      {embeded ? (
        <EditLogisticPartnersContent
          logisticSummaryIsLoading={logisticSummaryIsLoading}
          logisticSummaryIsFetching={logisticSummaryIsFetching}
          countryId={countryId}
          stateId={stateId}
          addLp={addLp}
          countryStatePartners={countryStatePartners}
          showForm={showForm}
        />
      ) : (
        <Dialog
          fullWidth
          maxWidth="sm"
          onClose={() => {
            if (onClose) {
              return onClose();
            }
            return router.push(paths.logisticPartners.root);
          }}
          open={isOpen !== null ? isOpen : countryId && stateId}
        >
          <DialogTitle>
            {addLp && (
              <IconButton
                component={RouterLink}
                // onClick={
                //   () => navigate(-1)
                // }
              >
                <Iconify icon="eva:arrow-ios-back-fill" />
              </IconButton>
            )}
            {showForm ? 'Add your own Logistics Company' : 'Manage Logistic Partners'}

            {/* {isLoading() && <CircularProgress size={20} sx={{ ml: 1 }} />} */}
            <Typography variant="body2">
              {countryStatePartners?.stateName}, {countryStatePartners?.countryName}
            </Typography>
          </DialogTitle>

          <DialogContent>
            <EditLogisticPartnersContent
              countryStatePartners={countryStatePartners}
              logisticSummaryIsLoading={logisticSummaryIsLoading}
              logisticSummaryIsFetching={logisticSummaryIsFetching}
              countryId={countryId}
              stateId={stateId}
              addLp={addLp}
              showForm={showForm}
              checkout={checkout}
            />
          </DialogContent>
          {!showForm && (
            <DialogActions>
              {/* <Button onClick={() => setChangeCountry(false)}>Cancel</Button>
        <Button color="success" variant="contained">
        Save
        </Button> */}
            </DialogActions>
          )}
        </Dialog>
      )}
    </>
  );
}

EditLogisticPartnersDialog.propTypes = {
  countryId: PropTypes.string,
  stateId: PropTypes.string,
  addLp: PropTypes.bool,
  embeded: PropTypes.bool,
  checkout: PropTypes.bool,
  isOpen: PropTypes.bool,
  onClose: PropTypes.func,
};
