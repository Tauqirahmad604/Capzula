import PropTypes from 'prop-types';
import { Helmet } from 'react-helmet-async';

import { Box, Container } from '@mui/system';
import { Card, Alert, Button, Typography, CardContent } from '@mui/material';

import { paths } from 'src/routes/paths';
import { useParams, useRouter } from 'src/routes/hooks';

import { useGetLogisticPartnersSummaryQuery } from 'src/redux/api/myAccount';

import Iconify from 'src/components/iconify';
import CustomBreadcrumbs from 'src/components/custom-breadcrumbs/custom-breadcrumbs';

import LogisticPartnerRow from './LogisticPartnerRow';
import EditLogisticPartnersDialog from './EditLogisticPartnersDialog';

export default function LogisticPartnersCountries({ addLp }) {
  const { data, refetch } = useGetLogisticPartnersSummaryQuery();

  const params = useParams();
  const router = useRouter();
  return (
    <div>
      <Helmet>
        <title>Logistic Partners</title>
      </Helmet>
      <Container maxWidth="xl">
        <CustomBreadcrumbs
          heading="Logistic Partners"
          links={[
            {
              name: 'Logstic Partners',
              href: paths.logisticPartners.root,
            },
            // {
            //   name: 'Logistic Partners',
            // },
          ]}
          sx={{
            mb: 2,
            mt: 2,
          }}
        />

        <Button onClick={refetch}>Refresh</Button>

        {data?.data?.map((country) => (
          <Box key={country.country_title} sx={{ mb: 4 }}>
            <Typography variant="h5" sx={{ mb: 1 }}>
              {country.country_title}
            </Typography>
            {country?.by_state.length <= 0 ? (
              <Card>
                <CardContent>
                  <Alert variant="outlined" severity="warning">
                    We do not offer logistic services in this country at this moment in time
                  </Alert>
                </CardContent>
              </Card>
            ) : (
              Object.keys(country?.by_state)?.map((key, i) => (
                <Card
                  key={key}
                  sx={{ mb: Object.keys(country?.by_state).length === i + 1 ? 0 : 2 }}
                >
                  <CardContent>
                    <Box
                      sx={{
                        width: '100%',
                        mb: country?.by_state[key]?.has_selected ? 2 : 0,
                        display: 'flex',
                      }}
                      alignContent="center"
                      justifyContent="center"
                    >
                      <Box fontWeight={500} display="flex">
                        <Typography variant="body1" fontWeight={500}>
                          {country?.by_state[key]?.has_selected ? (
                            <Iconify
                              color="green"
                              sx={{ mr: 1 }}
                              height={25}
                              width={25}
                              style={{ position: 'relative', top: 7 }}
                              icon="solar:check-circle-bold-duotone"
                            />
                          ) : (
                            <Iconify
                              height={25}
                              width={25}
                              sx={{ mr: 1, opacity: 0.4, position: 'relative', top: 5 }}
                              icon="solar:close-circle-bold-duotone"
                            />
                          )}
                          {country?.by_state[key]?.state_name}
                        </Typography>
                      </Box>

                      <Button
                        sx={{ mr: 0, ml: 'auto' }}
                        onClick={() => router.push(`${country.country_code}/${key}`)}
                        variant="outlined"
                      >
                        {country?.by_state[key]?.has_selected ? 'Change' : 'Select a partner'}
                      </Button>
                    </Box>
                    {country?.by_state[key]?.selected_logistic_business_data && (
                      <Box
                      // sx={{
                      //   mb:
                      //     country?.by_state[key]?.partners.length === 1
                      //       ? 0
                      //       : country?.by_state[key]?.partners.length === i + 1
                      //         ? 0
                      //         : 5,
                      // }}
                      >
                        <LogisticPartnerRow
                          businessData={country?.by_state[key]?.selected_logistic_business_data}
                        />
                      </Box>
                    )}
                  </CardContent>
                </Card>
              ))
            )}

            {/* ))} */}
          </Box>
        ))}
      </Container>

      <EditLogisticPartnersDialog
        countryId={params.countryId}
        stateId={params.stateId}
        addLp={addLp}
      />
    </div>
  );
}

LogisticPartnersCountries.propTypes = {
  addLp: PropTypes.bool,
};
