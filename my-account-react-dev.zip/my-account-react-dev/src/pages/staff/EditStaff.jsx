import * as Yup from 'yup';
import { useEffect } from 'react';
import PropTypes from 'prop-types';
import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';

import Stack from '@mui/material/Stack';
import LoadingButton from '@mui/lab/LoadingButton';
import { Table, TableRow, TableBody, TableCell, TableHead, TableContainer } from '@mui/material';

import { useRouter } from 'src/routes/hooks';

import { useSnackbar } from 'src/components/snackbar';
import { LoadingScreen } from 'src/components/loading-screen';
import FormProvider, { RHFCheckbox, RHFTextField } from 'src/components/hook-form';

import { useCreateStaffMutation, useUpdateStaffMutation } from '../../redux/api/myAccount';

export default function EditStaff({ staff, create }) {
  const [updateStaff, updateStaffResult] = useUpdateStaffMutation();
  const [createStaff, createStaffResult] = useCreateStaffMutation();
  const router = useRouter();
  const { enqueueSnackbar } = useSnackbar();

  const isValidEmail = (value) => {
    const emailRegex = /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i;
    return emailRegex.test(value);
  };

  const EditStaffSchema = Yup.object().shape({
    first_name: Yup.string().required('First name is required'),
    last_name: Yup.string().required('Last name is required'),
    email: Yup.string()
      .test('valid-email', 'Invalid email address', isValidEmail)
      .required('Email is required'),
  });

  const defaultValues = {
    first_name: staff?.first_name,
    last_name: staff?.last_name,
    email: staff?.email,
    manage_orders_view: staff?.permissions?.manage_orders_view || false,
    manage_orders_edit: staff?.permissions?.manage_orders_edit || false,
    manage_products_view: staff?.permissions?.manage_products_view || false,
    manage_products_edit: staff?.permissions?.manage_products_edit || false,
    manage_promos_edit: staff?.permissions?.manage_promos_edit || false,
    manage_promos_view: staff?.permissions?.manage_promos_view || false,
    manage_store_edit: staff?.permissions?.manage_store_edit || false,
    manage_commissions_view: staff?.permissions?.manage_commissions_view || false,
    manage_chats_edit: staff?.permissions?.manage_chats_edit || false,
    manage_reports_view: staff?.permissions?.manage_reports_view || false,
  };

  const methods = useForm({
    resolver: yupResolver(EditStaffSchema),
    defaultValues,
  });

  const { reset, handleSubmit } = methods;

  useEffect(() => {
    if (staff) {
      reset(defaultValues);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [staff]);

  const onSubmit = handleSubmit(async (data) => {
    console.log(data);
    if (create) {
      createStaff({
        body: data,
      });
    } else {
      updateStaff({
        id: staff.id,
        body: data,
      });
    }
  });

  useEffect(() => {
    if (updateStaffResult.isSuccess || createStaffResult.isSuccess) {
      reset();
      const message = updateStaffResult.isSuccess
        ? 'Staff account updated'
        : 'Staff account created';
      enqueueSnackbar(message);
      router.push('/staff');
    }

    if (createStaffResult.isError) {
      enqueueSnackbar(
        createStaffResult.error.data?.data?.message ||
          "There's been a problem creating staff account. Please try again.",
        { variant: 'error' }
      );
    }
    if (updateStaffResult.isError) {
      enqueueSnackbar(
        updateStaffResult.error.data?.data?.message ||
          "There's been a problem updating staff account. Please try again.",
        { variant: 'error' }
      );
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [
    updateStaffResult.isSuccess,
    createStaffResult.isSuccess,
    updateStaffResult.isError,
    createStaffResult.isError,
  ]);

  const renderForm = (
    <Stack spacing={2.5} sx={{ pt: 2 }}>
      {!staff && !create ? (
        <LoadingScreen />
      ) : (
        <>
          <RHFTextField name="first_name" label="First Name" />
          <RHFTextField name="last_name" label="Last Name" />
          <RHFTextField name="email" label="Email Address" />

          <TableContainer>
            <Table sx={{ minWidth: 650 }} aria-label="simple table">
              <TableHead>
                <TableRow>
                  {/* <TableCell width="5%">ID</TableCell> */}
                  <TableCell>Permission</TableCell>
                  <TableCell>View</TableCell>
                  <TableCell>Manage</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                <TableRow>
                  <TableCell>Orders</TableCell>
                  <TableCell>
                    {' '}
                    <RHFCheckbox
                      name="manage_orders_view"
                      checked={staff?.permissions?.manage_orders_view}
                    />
                  </TableCell>
                  <TableCell>
                    {' '}
                    <RHFCheckbox
                      name="manage_orders_edit"
                      checked={staff?.permissions?.manage_orders_edit}
                    />
                  </TableCell>
                </TableRow>
                <TableRow>
                  <TableCell>Products</TableCell>
                  <TableCell>
                    {' '}
                    <RHFCheckbox
                      name="manage_products_view"
                      checked={staff?.permissions?.manage_products_view}
                    />
                  </TableCell>
                  <TableCell>
                    {' '}
                    <RHFCheckbox
                      name="manage_products_edit"
                      checked={staff?.permissions?.manage_products_edit}
                    />
                  </TableCell>
                </TableRow>

                <TableRow>
                  <TableCell>Promotions</TableCell>
                  <TableCell>
                    {' '}
                    <RHFCheckbox
                      name="manage_promos_view"
                      checked={staff?.permissions?.manage_promos_view}
                    />
                  </TableCell>
                  <TableCell>
                    {' '}
                    <RHFCheckbox
                      name="manage_promos_edit"
                      checked={staff?.permissions?.manage_promos_edit}
                    />
                  </TableCell>
                </TableRow>
                <TableRow>
                  <TableCell>Store</TableCell>
                  <TableCell />
                  <TableCell>
                    {' '}
                    <RHFCheckbox
                      name="manage_store_edit"
                      checked={staff?.permissions?.manage_store_edit}
                    />
                  </TableCell>
                </TableRow>
                <TableRow>
                  <TableCell>Chat</TableCell>
                  <TableCell> </TableCell>
                  <TableCell>
                    {' '}
                    <RHFCheckbox
                      name="manage_chats_edit"
                      checked={staff?.permissions?.manage_chats_edit}
                    />
                  </TableCell>
                </TableRow>
                {/* <TableRow>
                  <TableCell>Reports</TableCell>
                  <TableCell>
                    {' '}
                    <RHFCheckbox
                      name="manage_reports_view"
                      checked={staff?.permissions?.manage_reports_view}
                    />
                  </TableCell>
                </TableRow> */}
                <TableRow>
                  <TableCell>Payouts</TableCell>
                  <TableCell>
                    {' '}
                    <RHFCheckbox
                      name="manage_commissions_view"
                      checked={staff?.permissions?.manage_commissions_view}
                    />
                  </TableCell>
                </TableRow>
              </TableBody>
            </Table>
          </TableContainer>

          <LoadingButton
            fullWidth
            color="inherit"
            size="large"
            type="submit"
            variant="contained"
            loading={updateStaffResult.isLoading || createStaffResult.isLoading}
          >
            {create ? 'Create' : 'Save'}
          </LoadingButton>
        </>
      )}
    </Stack>
  );

  return (
    <FormProvider methods={methods} onSubmit={onSubmit}>
      {renderForm}
    </FormProvider>
  );
}

EditStaff.propTypes = {
  staff: PropTypes.object,
  create: PropTypes.bool,
};
