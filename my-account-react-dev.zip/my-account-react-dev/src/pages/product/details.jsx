import { Helmet } from 'react-helmet-async';

import { useParams } from 'src/routes/hooks';

import { ProductCreateView } from 'src/sections/product-single/view';

// ----------------------------------------------------------------------

export default function ProductShopDetailsPage() {
  const params = useParams();

  const { id } = params;

  return (
    <>
      <Helmet>
        <title> Product: Details</title>
      </Helmet>

      <ProductCreateView id={`${id}`} />
    </>
  );
}
