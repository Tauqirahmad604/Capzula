import { Helmet } from 'react-helmet-async';

import ProductCreateBulkUpsert from 'src/sections/product-bulk/upsert-view';

// ----------------------------------------------------------------------

export default function CreateBulkProductUpsert() {
  return (
    <>
      <Helmet>
        <title>Create bulk product</title>
      </Helmet>
      <ProductCreateBulkUpsert />
    </>
  );
}
