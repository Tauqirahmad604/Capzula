import { Helmet } from 'react-helmet-async';

import { Container } from '@mui/system';
import { Table, TableRow, TableCell, TableHead, TableBody } from '@mui/material';

import { useGetAccessLogsQuery } from 'src/redux/api/myAccount';

import { LoadingScreen } from 'src/components/loading-screen';

export default function Page() {
  const { data: accessLogs, isLoading } = useGetAccessLogsQuery({
    pageNum: 1,
  });

  const prepActionData = (actionData) => {
    if (!actionData) {
      return [];
    }

    try {
      const data = Object.keys(JSON.parse(actionData)).reduce((acc, key) => {
        acc.push(`${key}: ${JSON.parse(actionData)[key]}`);
        return acc;
      }, []);
      console.log(data, ',data');
      return data;
    } catch (err) {
      return [];
    }
  };
  return (
    <>
      <Helmet>
        <title>Access Logs</title>
      </Helmet>

      <Container maxWidth="xl">
        {isLoading ? (
          <LoadingScreen />
        ) : (
          <Table>
            <TableHead>
              <TableRow>
                <TableCell>User</TableCell>
                <TableCell>Page</TableCell>
                <TableCell>Action</TableCell>
                <TableCell>Details</TableCell>
                <TableCell>Date</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {accessLogs?.data?.map((log) => (
                <TableRow>
                  <TableCell>{log?.user?.name}</TableCell>
                  <TableCell>{log.action_realm}</TableCell>
                  <TableCell>{log.action_performed}</TableCell>
                  <TableCell>
                    {prepActionData(log.action_data).map((action) => (
                      <>
                        {action}
                        <br />
                      </>
                    ))}
                  </TableCell>
                  <TableCell>{log.created_at}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </Container>
    </>
  );
}
