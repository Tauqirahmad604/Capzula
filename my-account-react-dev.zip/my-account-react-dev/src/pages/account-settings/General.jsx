import * as Yup from 'yup';
import { useForm } from 'react-hook-form';
import { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet-async';
import { enqueueSnackbar } from 'notistack';
import { isValidNumber } from 'libphonenumber-js';
import { yupResolver } from '@hookform/resolvers/yup';

import { LoadingButton } from '@mui/lab';
import { Box, Stack, Container } from '@mui/system';
import {
  Card,
  Alert,
  Button,
  Dialog,
  Skeleton,
  Typography,
  CardContent,
  DialogTitle,
  DialogActions,
} from '@mui/material';

import { useAuthContext } from 'src/auth/hooks';
import {
  useGetAccountSettingsQuery,
  usePutAccountSettingsMutation,
  useUploadProfilePhotoMutation,
} from 'src/redux/api/myAccount';

import Image from 'src/components/image';
import FormProvider from 'src/components/hook-form/form-provider';
import { RHFTelField, RHFTextField } from 'src/components/hook-form';

import UploadProfilePhoto from './UploadProfilePhoto';
import AccountSettingsTabs from './AccountSettingsTabs';

export default function Page() {
  const { data: accountSettingsPayload, isFetching } = useGetAccountSettingsQuery();
  const accountSettingsData = accountSettingsPayload?.data;
  const { user, refresh } = useAuthContext();
  const [putAccountSettings, putAccountSettingsResults] = usePutAccountSettingsMutation();
  const [uploadNewProfilePhoto, setUploadNewProfilePhoto] = useState(false);
  const [uploadProfilePhoto, uploadProfilePhotoResults] = useUploadProfilePhotoMutation();
  // const [resendVerificationEmail, resendVerificationEmailResults] =
  //   useResendVerificationEmailMutation();

  const NewAddressSchema = Yup.object().shape({
    firstName: Yup.string().required('First name is required'),
    lastName: Yup.string().required('Last name is required'),
    phone: Yup.string()
      .test('phone', 'Invalid phone number', (value) => {
        if (!value) return false;
        return isValidNumber(value);
      })
      .required('Phone number is required'),
    email: Yup.string().required('Email is required'),
  });

  const defaultValues = {
    firstName: accountSettingsData?.first_name || '',
    lastName: accountSettingsData?.last_name || '',
    phone: accountSettingsData?.phone_number || '',
    email: accountSettingsData?.email || '',
  };

  const methods = useForm({
    resolver: yupResolver(NewAddressSchema),
    defaultValues,
  });

  const {
    handleSubmit,
    formState: { isSubmitting },
    reset,
  } = methods;

  useEffect(() => {
    reset(defaultValues);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [accountSettingsData]);

  useEffect(() => {
    // refresh();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const onSubmit = handleSubmit(async (data) => {
    try {
      putAccountSettings(data);
    } catch (e) {
      console.error(e);
    }
  });

  useEffect(() => {
    if (putAccountSettingsResults.isSuccess) {
      refresh();
      enqueueSnackbar('Account settings updated successfully', { variant: 'success' });
    }
    if (putAccountSettingsResults.isError) {
      if (putAccountSettingsResults.error?.data?.data?.email_exists) {
        enqueueSnackbar('Email already exists', { variant: 'error' });
      } else {
        enqueueSnackbar('Error updating account settings', { variant: 'error' });
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [putAccountSettingsResults.isSuccess, putAccountSettingsResults.isError]);

  useEffect(() => {
    if (uploadProfilePhotoResults.isSuccess) {
      refresh();
      enqueueSnackbar('Profile photo updated', { variant: 'success' });
    }
    if (uploadProfilePhotoResults.isError) {
      enqueueSnackbar('Unable to update profile photo', { variant: 'error' });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [uploadProfilePhotoResults.isSuccess, uploadProfilePhotoResults.isError]);

  return (
    <>
      <Helmet>
        <title>Account Settings</title>
      </Helmet>
      <Container maxWidth="md">
        <AccountSettingsTabs activeTab="" />

        <Card>
          <CardContent>
            <Box sx={{ mb: 1 }}>
              <Typography variant="h4">General</Typography>
            </Box>

            <FormProvider methods={methods} onSubmit={onSubmit}>
              <Stack spacing={2} sx={{ pt: 1 }}>
                <Box
                  rowGap={2}
                  sx={{ mb: 2 }}
                  columnGap={2}
                  display="grid"
                  alignItems="center"
                  justifyContent="center"
                  gridTemplateColumns={{
                    xs: 'repeat(1, 1fr)',
                    sm: 'repeat(2, 1fr)',
                  }}
                >
                  <Stack alignItems="center" justifyContent="center">
                    {isFetching || uploadProfilePhotoResults.isLoading ? (
                      <Skeleton sx={{ mb: 0 }} variant="circular" height={150} width={150} />
                    ) : (
                      <>
                        <Image
                          onClick={() => setUploadNewProfilePhoto(true)}
                          sx={{
                            height: '150px',
                            width: '150px',
                            borderRadius: '100%',
                            cursor: 'pointer',
                          }}
                          src={accountSettingsData?.profile_photo}
                        />
                        <Button
                          variant="outlined"
                          sx={{ mt: 2 }}
                          onClick={() => setUploadNewProfilePhoto(true)}
                        >
                          Change Profile Photo
                        </Button>
                      </>
                    )}
                  </Stack>

                  <div>
                    {isFetching ? (
                      <>
                        <Skeleton sx={{ mb: 0 }} variant="text" width="100%" height={80} />
                        <Skeleton sx={{ mb: 0 }} variant="text" width="100%" height={80} />
                      </>
                    ) : (
                      <>
                        <RHFTextField
                          sx={{ mb: 2 }}
                          disabled={!user?.is_emulating}
                          name="firstName"
                          label="First Name"
                        />
                        <RHFTextField
                          disabled={!user?.is_emulating}
                          name="lastName"
                          label="Last Name"
                        />
                        {!user?.is_emulating && (
                          <Typography variant="body2" sx={{ mt: 2 }}>
                            Please contact us if you require changes to your first or last name
                          </Typography>
                        )}
                      </>
                    )}
                  </div>
                </Box>
                <Box>
                  {isFetching ? (
                    <Skeleton sx={{ mb: 0 }} variant="text" width="100%" height={80} />
                  ) : (
                    <Box sx={{ mb: 2 }}>
                      <RHFTelField
                        label="Phone Number"
                        name="phone"
                        defaultCountry={user?.address?.country || 'US'}
                      />
                    </Box>
                  )}
                </Box>
                <Box>
                  {isFetching ? (
                    <Skeleton sx={{ mb: 0 }} variant="text" width="100%" height={80} />
                  ) : (
                    <>
                      <RHFTextField
                        sx={{ mb: 2 }}
                        name="email"
                        type="email"
                        label="Email Address"
                      />
                      {!accountSettingsData?.email_verified && (
                        <Alert severity="warning" sx={{ mt: 1 }}>
                          {accountSettingsData?.change_email_to ? (
                            <>
                              <Typography variant="body2" fontWeight={500}>
                                Email change request to {accountSettingsData?.change_email_to}
                              </Typography>
                              To complete your email change, please verify your new email address.{' '}
                            </>
                          ) : (
                            <Typography variant="body2" fontWeight={500}>
                              Email is not verified. Please verify your email address.{' '}
                            </Typography>
                          )}
                          {/* <LoadingButton
                              size="small"
                              loading={resendVerificationEmailResults.isLoading}
                              variant="outlined"
                              onClick={resendVerificationEmail}
                            >
                              {' '}
                              Resend email
                            </LoadingButton> */}
                        </Alert>
                      )}
                    </>
                  )}
                </Box>
              </Stack>

              <DialogActions sx={{ px: 0, pb: 0 }}>
                <LoadingButton
                  type="submit"
                  size="large"
                  variant="contained"
                  loading={putAccountSettingsResults.isLoading || isSubmitting}
                  // loading={
                  //   addDeliveryAddressResult.isLoading ||
                  //   updateDeliveryAddressResult.isLoading ||
                  //   isSubmitting
                  // }
                >
                  Save
                </LoadingButton>
              </DialogActions>
            </FormProvider>
          </CardContent>
        </Card>
      </Container>

      <Dialog fullWidth maxWidth="sm" disableBackdropClick open={uploadNewProfilePhoto}>
        <DialogTitle>Change Profile Photo </DialogTitle>

        <UploadProfilePhoto
          setUploadNewProfilePhoto={setUploadNewProfilePhoto}
          onComplete={(photoUrl) => {
            setUploadNewProfilePhoto(false);
            uploadProfilePhoto({
              photo_url: photoUrl,
            });
          }}
        />
      </Dialog>
    </>
  );
}
