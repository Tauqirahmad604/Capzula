import PropTypes from 'prop-types';
import { v4 as uuidv4 } from 'uuid';
import Cropper from 'react-easy-crop';
import { FileUploader } from 'react-drag-drop-files';
import React, { useState, useEffect, useCallback } from 'react';

import { Box } from '@mui/system';
import { LoadingButton } from '@mui/lab';
import { Button, DialogActions, DialogContent } from '@mui/material';

import { useSupabaseContext } from 'src/supabase/hooks';

import { LoadingScreen } from 'src/components/loading-screen';

// import { getCroppedImg } from './cropUtils'; // A utility function to handle cropping logic

const fileTypes = ['JPG', 'JPEG', 'PNG', 'GIF', 'WEBP'];

export const getCroppedImg = (imageSrc, pixelCrop) => {
  const image = new Image();
  image.src = imageSrc;

  return new Promise((resolve) => {
    image.onload = () => {
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d');

      canvas.width = pixelCrop.width;
      canvas.height = pixelCrop.height;

      ctx.drawImage(
        image,
        pixelCrop.x,
        pixelCrop.y,
        pixelCrop.width,
        pixelCrop.height,
        0,
        0,
        pixelCrop.width,
        pixelCrop.height
      );

      canvas.toBlob(
        (blob) => {
          resolve(blob);
        },
        'image/jpeg',
        1
      );
    };
  });
};

function CropPhoto({ src, onChange }) {
  const [crop, setCrop] = useState({ x: 0, y: 0 });
  const [zoom, setZoom] = useState(1);

  const onCropChange = (newCrop) => {
    setCrop(newCrop);
  };

  const onZoomChange = (newZoom) => {
    setZoom(newZoom);
  };

  // const onCropCompleteHandler = useCallback((croppedArea, croppedAreaPixels) => {
  //   setCroppedAreaPixels(croppedAreaPixels);
  // }, []);
  const onCropComplete = (croppedArea, croppedAreaPixels) => {
    onChange(croppedArea, croppedAreaPixels);
  };

  return (
    <div>
      <div className="crop-container">
        <Cropper
          cropShape="round"
          image={src}
          crop={crop}
          zoom={zoom}
          onCropComplete={onCropComplete}
          aspect={1}
          onCropChange={onCropChange}
          onZoomChange={onZoomChange}
        />
      </div>
    </div>
  );
}

CropPhoto.propTypes = {
  src: PropTypes.string.isRequired,
  onChange: PropTypes.func.isRequired,
};

export default function UploadPhoto({ onComplete, setUploadNewProfilePhoto }) {
  const [file, setFile] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [croppedAreaPixels, setCroppedAreaPixels] = useState(false);
  const { makeAPICall } = useSupabaseContext();

  const uploadImage = useCallback(
    async (uploadedBlob) => {
      setIsLoading(true);

      const fileName = `${uuidv4()}.jpeg`;
      const blobToFile = new File([uploadedBlob], fileName, { type: 'image/jpeg' });
      const { error } = await makeAPICall((dbClient) =>
        dbClient.storage.from('profile_photos').upload(fileName, blobToFile, {
          cacheControl: '3600',
          upsert: false,
        })
      );

      if (error) {
        console.error(error);
        return { error };
      }

      const { data: urlData } = await makeAPICall((dbClient) =>
        dbClient.storage.from('profile_photos').getPublicUrl(fileName)
      );

      setIsLoading(false);

      return urlData.publicUrl;
    },
    [makeAPICall]
  );

  const handleFileUpload = (fileUploaded) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      setFile(e.target.result);
    };
    reader.readAsDataURL(fileUploaded);
  };

  const onCropChange = (croppedArea, croppedAreaPixelsData) => {
    setCroppedAreaPixels(croppedAreaPixelsData);
  };

  const cropAndSave = useCallback(async () => {
    if (croppedAreaPixels) {
      const croppedImage = await getCroppedImg(file, croppedAreaPixels);
      const publicUrl = await uploadImage(croppedImage);
      onComplete(publicUrl);
      setFile(null);
      setIsLoading(true);
    }
  }, [croppedAreaPixels, file, onComplete, uploadImage]);

  useEffect(() => {
    setIsLoading(false);
  }, []);
  return (
    <>
      <DialogContent>
        {isLoading ? (
          <LoadingScreen />
        ) : (
          <>
            {file ? (
              <Box sx={{ minHeight: '50vh', position: 'relative' }}>
                <CropPhoto
                  onChange={onCropChange}
                  src={file}
                  // setCroppedAreaPixels={setCroppedAreaPixels}
                />
              </Box>
            ) : (
              <FileUploader handleChange={handleFileUpload} name="file" types={fileTypes} />
            )}
          </>
        )}
      </DialogContent>
      <DialogActions>
        {file && (
          <LoadingButton
            loading={isLoading}
            color="success"
            variant="contained"
            sx={{ zIndex: '500', position: 'relative' }}
            onClick={cropAndSave}
          >
            Save
          </LoadingButton>
        )}
        <Button
          disabled={isLoading}
          color="inherit"
          variant="outlined"
          onClick={() => setUploadNewProfilePhoto(false)}
        >
          Cancel
        </Button>
      </DialogActions>
    </>
  );
}

UploadPhoto.propTypes = {
  onComplete: PropTypes.func.isRequired,
  setUploadNewProfilePhoto: PropTypes.func.isRequired,
};
