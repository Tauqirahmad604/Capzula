import * as Yup from 'yup';
import PropTypes from 'prop-types';
import { useRef, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';

import { Stack } from '@mui/system';
import { LoadingButton } from '@mui/lab';
import { Dialog, DialogTitle, DialogContent } from '@mui/material';

import {
  usePostTariffServiceMutation,
  useUpdateTariffServiceMutation,
} from 'src/redux/api/myAccount';

import { RHFTextField } from 'src/components/hook-form';
import { enqueueSnackbar } from 'src/components/snackbar';
import FormProvider from 'src/components/hook-form/form-provider';

export default function EditServiceDialog({
  createService,
  countryCode,
  stateCode,
  editService,
  setEditService,
  setCreateService,
}) {
  const [postTariffService, postTariffServiceResult] = usePostTariffServiceMutation();
  const [updateTariffService, updateTariffServiceResult] = useUpdateTariffServiceMutation();

  const nameField = useRef(null);
  const EditServiceSchema = Yup.object().shape({
    service_name: Yup.string().required('Service name is required'),
    service_description: Yup.string(),
    delivery_days: Yup.number().typeError('Must be a number').required('Delivery days is required'),
  });

  const defaultValues = {
    service_name: editService?.service_name || '',
    service_description: editService?.service_description || '',
    delivery_days: editService?.delivery_days || '',
  };

  const methods = useForm({
    resolver: yupResolver(EditServiceSchema),
    defaultValues,
  });

  const { reset, handleSubmit } = methods;

  useEffect(() => {
    if (createService || editService) {
      reset(defaultValues);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [createService, editService]);

  const onSubmit = handleSubmit(async (data) => {
    const payload = {
      ...data,
      country_code: countryCode,
      state_code: stateCode,
    };

    if (createService) {
      return postTariffService(payload);
    }

    if (editService) {
      payload.id = editService?.id;
      return updateTariffService(payload);
    }

    return () => null;
  });

  useEffect(() => {
    if (postTariffServiceResult.isSuccess || updateTariffServiceResult.isSuccess) {
      enqueueSnackbar(editService ? `Service updated` : 'Service created', { variant: 'success' });
      setCreateService(false);
      setEditService(false);
    }
    if (postTariffServiceResult.isError || updateTariffServiceResult.isError) {
      enqueueSnackbar(editService ? `Error updateding service` : 'Error creating service', {
        variant: 'error',
      });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [
    postTariffServiceResult.isSuccess,
    postTariffServiceResult.isError,
    updateTariffServiceResult.isSuccess,
    updateTariffServiceResult.isError,
    setCreateService,
  ]);

  const focusInput = () => {
    setTimeout(() => {
      nameField?.current?.focus();
      nameField?.current?.setAttribute('autofocus', 'autofocus');
    }, 200);
  };
  useEffect(() => {
    if (createService === 'create') {
      focusInput();
    }
  }, [createService]);

  // const canSubmit = serviceName && serviceDescription && deliveryDays;

  const renderForm = (
    <Stack spacing={2.5} sx={{ pt: 2 }}>
      <>
        <RHFTextField
          ref={nameField}
          name="service_name"
          label="Service Name"
          placeholder="SkyAir Express"
        />

        <RHFTextField name="service_description" label="Service Description" />

        <RHFTextField type="number" name="delivery_days" label="Delivery Days" />
        <LoadingButton
          fullWidth
          color="inherit"
          size="large"
          type="submit"
          variant="contained"
          loading={postTariffServiceResult.isLoading || updateTariffServiceResult.isLoading}
        >
          {createService ? 'Create' : 'Save'}
        </LoadingButton>
      </>
    </Stack>
  );

  return (
    <Dialog
      fullWidth
      maxWidth="sm"
      open={!!createService || !!editService}
      onClose={() => {
        setCreateService(false);
        setEditService(false);
      }}
    >
      <DialogTitle sx={{ pb: 1 }}>
        {createService === 'create' ? 'Add a' : 'Edit'} service
      </DialogTitle>
      <DialogContent sx={{ p: 3 }}>
        <FormProvider methods={methods} onSubmit={onSubmit}>
          {renderForm}
        </FormProvider>
      </DialogContent>
    </Dialog>
  );
}
EditServiceDialog.propTypes = {
  countryCode: PropTypes.string,
  createService: PropTypes.oneOfType([PropTypes.bool, PropTypes.string]),
  setCreateService: PropTypes.func,
  stateCode: PropTypes.string,
  editService: PropTypes.oneOfType([PropTypes.bool, PropTypes.object]),
  setEditService: PropTypes.func,
};
