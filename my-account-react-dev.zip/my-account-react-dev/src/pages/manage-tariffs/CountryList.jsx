import PropTypes from 'prop-types';
import debounce from 'lodash.debounce';
import { Helmet } from 'react-helmet-async';
import { memo, useRef, useState, useEffect, useCallback } from 'react';

import { Box, Container } from '@mui/system';
import {
  Card,
  Input,
  Table,
  Button,
  TableRow,
  TableBody,
  Accordion,
  TableCell,
  Typography,
  AccordionSummary,
  AccordionDetails,
} from '@mui/material';

import { useRouter } from 'src/routes/hooks';

import { useGetTariffCountriesQuery } from 'src/redux/api/myAccount';

import Iconify from 'src/components/iconify';
import { LoadingScreen } from 'src/components/loading-screen';
import CustomBreadcrumbs from 'src/components/custom-breadcrumbs/custom-breadcrumbs';

function CountryStates({ countryName, countryCode, states, countryLevelTariffServices }) {
  // const entries = Object.entries(states);
  const router = useRouter();

  return (
    <Table>
      <TableBody>
        <TableRow>
          <TableCell>
            <Box sx={{ display: 'flex', alignItems: 'center' }}>
              {countryLevelTariffServices?.length > 0 ? (
                <Iconify color="green" sx={{ mr: 1 }} icon="solar:check-circle-bold-duotone" />
              ) : (
                <Iconify sx={{ mr: 1, opacity: 0.4 }} icon="solar:close-circle-bold-duotone" />
              )}
              {countryName} (All States)
            </Box>
          </TableCell>
          <TableCell sx={{ textAlign: 'right' }}>
            {countryLevelTariffServices?.length > 0 ? (
              <Button
                onClick={() => router.push(`/manage-tariffs/${countryCode}/ALL`)}
                variant="outlined"
              >
                Manage service rates
              </Button>
            ) : (
              <Button
                onClick={() => router.push(`/manage-tariffs/${countryCode}/ALL`)}
                variant="contained"
              >
                Add a service rate
              </Button>
            )}
          </TableCell>
        </TableRow>

        {states &&
          states.map((state) => (
            <TableRow key={state.state_code}>
              <TableCell>
                <Box sx={{ display: 'flex', alignItems: 'center' }}>
                  {state?.services?.length > 0 ? (
                    <Iconify color="green" sx={{ mr: 1 }} icon="solar:check-circle-bold-duotone" />
                  ) : (
                    <Iconify sx={{ mr: 1, opacity: 0.4 }} icon="solar:close-circle-bold-duotone" />
                  )}
                  {state.state_name}
                </Box>
              </TableCell>
              <TableCell sx={{ textAlign: 'right' }}>
                {state?.services?.length > 0 ? (
                  <Button
                    onClick={() => router.push(`/manage-tariffs/${countryCode}/ALL`)}
                    variant="outlined"
                  >
                    Manage service rates
                  </Button>
                ) : (
                  <Button
                    onClick={() => router.push(`/manage-tariffs/${countryCode}/ALL`)}
                    variant="contained"
                  >
                    Add a service rate
                  </Button>
                )}
              </TableCell>
            </TableRow>
          ))}
      </TableBody>
    </Table>
  );
}

CountryStates.propTypes = {
  countryName: PropTypes.string,
  countryCode: PropTypes.string,
  states: PropTypes.oneOfType([PropTypes.bool, PropTypes.object]),
  countryLevelTariffServices: PropTypes.array,
};

const SingleCountry = ({ countryName, countryCode, states, countryLevelTariffServices }) => {
  const [expanded, setExpanded] = useState(false);

  return (
    <Card key={countryName} sx={{ mb: 2 }}>
      <Accordion onChange={() => setExpanded(!expanded)}>
        <AccordionSummary>
          {countryLevelTariffServices.length > 0 ? (
            <Iconify color="green" sx={{ mr: 1 }} icon="solar:check-circle-bold-duotone" />
          ) : (
            <Iconify sx={{ opacity: 0.4 }} icon="solar:close-circle-bold-duotone" />
          )}

          <Typography variant="subtitle2" sx={{ ml: 1 }}>
            {countryName}
          </Typography>
        </AccordionSummary>
        <AccordionDetails>
          {expanded && (
            <CountryStates
              countryLevelTariffServices={countryLevelTariffServices}
              countryCode={countryCode}
              countryName={countryName}
              states={states}
            />
          )}
        </AccordionDetails>
      </Accordion>
    </Card>
  );
};

SingleCountry.propTypes = {
  countryName: PropTypes.string,
  countryCode: PropTypes.string,
  states: PropTypes.oneOfType([PropTypes.bool, PropTypes.object]),
  countryLevelTariffServices: PropTypes.array,
};

const MemoSingleCountry = memo(SingleCountry);

export default function Page() {
  const { data: rawCountryData, isLoading } = useGetTariffCountriesQuery();
  const [countryData, setCountryData] = useState([]);

  const [searchQuery, setSearchQuery] = useState('');
  const debouncedSearch = useRef(debounce(setSearchQuery, 300));
  const handleSearch = useCallback((e) => {
    if (e.target.value === '') {
      setSearchQuery('');
    } else {
      debouncedSearch.current(e.target.value);
    }
  }, []);

  useEffect(() => {
    if (searchQuery) {
      const filteredData = rawCountryData?.data.filter((country) => {
        console.log(country);
        // return;
        if (country.country_name.toLowerCase().includes(searchQuery.toLowerCase())) {
          return true;
        }

        if (country.states) {
          const found = country.states.find((state) =>
            state.state_name.toLowerCase().includes(searchQuery.toLowerCase())
          );

          if (found) {
            return true;
          }
        }

        return false;
      });

      return setCountryData(filteredData);
    }

    return setCountryData(rawCountryData?.data || []);
  }, [rawCountryData, searchQuery]);

  return (
    <>
      <Helmet>
        <title>Manage Tariffs</title>
      </Helmet>

      <Container maxWidth="xl">
        <CustomBreadcrumbs
          heading="Manage Tariffs"
          links={[]}
          sx={{
            mb: 2,
            mt: 2,
          }}
        />

        {isLoading ? (
          <LoadingScreen />
        ) : (
          <>
            <Box sx={{ pb: 3 }}>
              <Input fullWidth autoFocus placeholder="Search..." onChange={handleSearch} />
            </Box>
            {countryData.map((country) => (
              <MemoSingleCountry
                key={country.country_name}
                countryName={country.country_name}
                countryLevelTariffServices={country.country_level_tariff_services}
                countryCode={country.country_code}
                states={country.states}
              />
            ))}
          </>
        )}
      </Container>
    </>
  );
}
