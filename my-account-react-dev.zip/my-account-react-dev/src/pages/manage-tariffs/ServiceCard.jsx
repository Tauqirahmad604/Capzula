import { useState } from 'react';
import PropTypes from 'prop-types';

import { Box } from '@mui/system';
import {
  Card,
  Table,
  TableRow,
  TableCell,
  TableHead,
  TableBody,
  CardHeader,
  IconButton,
  CircularProgress,
} from '@mui/material';

import Iconify from 'src/components/iconify';
import EmptyContent from 'src/components/empty-content/empty-content';

import RateRow from './RateRow';

const ServiceCard = ({ service, isFetching, isDeleting, onEdit, onDelete }) => {
  const [newRateActive, setNewRateActive] = useState(false);

  const getLastWeight = () => {
    const lastRate = service.rates[service.rates.length - 1];

    if (lastRate) {
      return Number(lastRate.to_kg);
    }
    return 0;
  };
  return (
    <Card sx={{ mt: 3, p: 2 }}>
      {isFetching && (
        <Box
          sx={{
            position: 'absolute',
            top: 0,
            right: 0,
            bottom: 0,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            left: 0,
            bgcolor: 'rgba(255,255,255,0.7)',
            zIndex: 100,
          }}
        >
          <CircularProgress size={40} />
        </Box>
      )}
      <>
        {' '}
        <CardHeader
          subheader={
            <>
              <strong>{service.delivery_days} Days Delivery </strong>
              {service.service_description ? `· ${service.service_description}` : ''}
            </>
          }
          title={service.service_name}
          sx={{ p: 0, mb: 2 }}
          action={
            <>
              <IconButton
                disabled={isDeleting}
                onClick={() => {
                  onEdit({
                    id: service.id,
                    service_name: service.service_name,
                    service_description: service.service_description,
                    delivery_days: service.delivery_days,
                  });
                }}
              >
                <Iconify icon="solar:pen-bold" />
              </IconButton>

              <IconButton
                color="error"
                disabled={isDeleting}
                onClick={() => {
                  onDelete(service.id);
                }}
              >
                <Iconify icon="solar:trash-bin-2-bold" />
              </IconButton>
            </>
          }
        />
        {service.rates.length === 0 && !newRateActive ? (
          <EmptyContent
            title="No rates created for this service"
            imgUrl={null}
            action={
              <IconButton
                size="large"
                sx={{ mt: 1 }}
                color="success"
                onClick={() => {
                  setNewRateActive(!newRateActive);
                }}
                variant="contained"
              >
                <Iconify width={40} icon="solar:add-circle-bold" />
              </IconButton>
            }
            sx={{ p: 2 }}
          />
        ) : (
          <>
            <Table>
              <TableHead>
                <TableRow>
                  <TableCell width="25%">From (kg)</TableCell>
                  <TableCell width="25%">To (kg)</TableCell>
                  <TableCell width="25%">price (per kg)</TableCell>
                  <TableCell width="25%" />
                </TableRow>
              </TableHead>
              <TableBody>
                {service.rates.map((rate) => (
                  <RateRow key={rate.id} rateData={rate} />
                ))}

                {newRateActive && (
                  <RateRow
                    newWeight={getLastWeight() + 1 || ''}
                    serviceId={service.id}
                    onSave={() => {
                      setNewRateActive(false);
                    }}
                    onCancel={() => setNewRateActive(false)}
                    newRate
                  />
                )}
              </TableBody>
            </Table>
            <Box
              sx={{
                textAlign: 'center',
              }}
            >
              {!newRateActive && (
                <IconButton
                  size="large"
                  sx={{ mt: 1 }}
                  color="success"
                  onClick={() => {
                    setNewRateActive(!newRateActive);
                  }}
                  variant="contained"
                >
                  <Iconify width={40} icon="solar:add-circle-bold" />
                </IconButton>
              )}
            </Box>
          </>
        )}
      </>
    </Card>
  );
};

ServiceCard.propTypes = {
  isFetching: PropTypes.bool,
  service: PropTypes.object,
  onEdit: PropTypes.func,
  onDelete: PropTypes.func,
  isDeleting: PropTypes.bool,
};

export default ServiceCard;
