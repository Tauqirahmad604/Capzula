import { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet-async';
import { enqueueSnackbar } from 'notistack';

import { Container } from '@mui/system';
import { Card, Button, Typography } from '@mui/material';

import { paths } from 'src/routes/paths';
import { useParams, useRouter } from 'src/routes/hooks';

import {
  useGetTariffStateServicesQuery,
  useDeleteTariffServiceMutation,
} from 'src/redux/api/myAccount';

import Iconify from 'src/components/iconify';
import { LoadingScreen } from 'src/components/loading-screen';
import EmptyContent from 'src/components/empty-content/empty-content';
import CustomBreadcrumbs from 'src/components/custom-breadcrumbs/custom-breadcrumbs';

import ServiceCard from './ServiceCard';
import EditServiceDialog from './EditServiceDialog';

export default function Page() {
  const { countryCode: country_code, stateCode: state_code } = useParams();
  const [createService, setCreateService] = useState(false);
  const [editService, setEditService] = useState(false);
  const [deleteTariffService, deleteTariffServiceResult] = useDeleteTariffServiceMutation();

  const {
    data: tariffStateServicesData,
    isLoading,
    isFetching,
    isError,
  } = useGetTariffStateServicesQuery({
    country_code,
    state_code,
  });

  useEffect(() => {
    if (deleteTariffServiceResult.isSuccess) {
      enqueueSnackbar('Service deleted', { variant: 'success' });
      setCreateService(false);
      setEditService(false);
    }
    if (deleteTariffServiceResult.isError) {
      enqueueSnackbar('Error deleting service', {
        variant: 'error',
      });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [deleteTariffServiceResult.isSuccess, deleteTariffServiceResult.isError]);

  useEffect(() => {
    if (isError) {
      return router.push('/404');
    }
    return () => null;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isError]);
  const handleEditService = (serviceData) => {
    setCreateService(false);
    setEditService(serviceData);
  };

  const handleDeleteService = (service_id) => {
    deleteTariffService({
      service_id,
    });
  };

  const router = useRouter();

  if (isLoading) {
    return <LoadingScreen />;
  }

  return (
    <>
      <Helmet>
        <title>Edit Tariffs</title>
      </Helmet>

      <>
        <Container maxWidth="xl">
          <CustomBreadcrumbs
            action={
              tariffStateServicesData?.data?.services?.length !== 0 && (
                <Button
                  sx={{ mb: 2 }}
                  color="success"
                  onClick={() => {
                    setEditService(false);
                    setCreateService(true);
                  }}
                  variant="contained"
                >
                  Add a service
                </Button>
              )
            }
            heading="Manage Service Rates"
            links={[
              {
                name: 'Manage Tariffs',
                href: paths.manageTariffs.root,
              },
              {
                name: `${tariffStateServicesData?.data?.country_data?.country_name} (${tariffStateServicesData?.data?.country_data?.state_name})`,
              },
            ]}
            sx={{
              mb: 2,
              mt: 2,
            }}
          />

          <Card sx={{ p: 2 }}>
            <Typography
              sx={{ alignItems: 'center', display: 'flex', mb: 0 }}
              variant="body2"
              fontWeight={500}
              gutterBottom
            >
              {tariffStateServicesData?.data?.dispatch_address?.company_name},{' '}
              {tariffStateServicesData?.data?.dispatch_address?.state_name},{' '}
              {tariffStateServicesData?.data?.dispatch_address?.country_name}
              <Iconify
                sx={{ ml: 1, mr: 1 }}
                color="#e96b92"
                icon="solar:alt-arrow-right-line-duotone"
              />
              {`${tariffStateServicesData?.data?.country_data?.country_name}, ${tariffStateServicesData?.data?.country_data?.state_name}`}
            </Typography>
          </Card>

          {tariffStateServicesData?.data?.services?.length === 0 ? (
            <EmptyContent
              title="No services added yet"
              action={
                <Button
                  sx={{ mt: 2 }}
                  color="success"
                  onClick={() => setCreateService('create')}
                  variant="contained"
                >
                  Add a service
                </Button>
              }
              sx={{ p: 2 }}
            />
          ) : (
            tariffStateServicesData?.data?.services?.map((service) => (
              <ServiceCard
                isDeleting={deleteTariffServiceResult.isLoading}
                onEdit={handleEditService}
                onDelete={(serviceId) => handleDeleteService(serviceId)}
                isFetching={isFetching}
                key={service.id}
                service={service}
              />
            ))
          )}
        </Container>

        <EditServiceDialog
          countryCode={country_code}
          stateCode={state_code}
          createService={createService}
          editService={editService}
          setCreateService={setCreateService}
          setEditService={setEditService}
        />
      </>
      {/* )} */}
    </>
  );
}
