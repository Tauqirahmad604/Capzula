import PropTypes from 'prop-types';
import { useRef, useState, useEffect } from 'react';

import { LoadingButton } from '@mui/lab';
import {
  Button,
  TableRow,
  TableCell,
  TextField,
  Typography,
  IconButton,
  InputAdornment,
  CircularProgress,
} from '@mui/material';

import {
  usePostTariffServiceRateMutation,
  useUpdateTariffServiceRateMutation,
  useDeleteTariffServiceRateMutation,
} from 'src/redux/api/myAccount';

import Iconify from 'src/components/iconify';
import { enqueueSnackbar } from 'src/components/snackbar';

const RateRow = ({ newWeight, rateData, serviceId, newRate = false, onCancel, onSave }) => {
  const secondInput = useRef(null);
  const [postTariffServiceRate, postTariffServiceRateResult] = usePostTariffServiceRateMutation();
  const [updateTariffServiceRate, updateTariffServiceRateResult] =
    useUpdateTariffServiceRateMutation();

  const [deleteTariffServiceRate, deleteTariffServiceRateResult] =
    useDeleteTariffServiceRateMutation();

  const [editActive, setEditActive] = useState(newRate);
  const [fromKg, setFromKg] = useState(newRate ? newWeight || '' : rateData.from_kg);
  const [toKg, setToKg] = useState(newRate ? '' : rateData.to_kg);
  const [priceKg, setPriceKg] = useState(newRate ? '' : rateData.price_kg);

  const handleCancel = () => {
    if (onCancel) {
      return onCancel();
    }

    return setEditActive(!editActive);
  };

  const handleSave = () => {
    const fromKgNumber = Number(fromKg);
    const toKgNumber = Number(toKg);
    const priceKgNumber = Number(priceKg);

    if (!fromKgNumber || !toKgNumber || !priceKgNumber) {
      return enqueueSnackbar('Please fill all fields', { variant: 'error' });
    }
    if (fromKgNumber <= 0 || toKgNumber <= 0 || priceKgNumber <= 0) {
      return enqueueSnackbar('Values cannot be less than 0', { variant: 'error' });
    }

    if (fromKgNumber >= toKgNumber) {
      return enqueueSnackbar('The to weight needs to be bigger than from', { variant: 'error' });
    }
    if (newRate) {
      return postTariffServiceRate({
        service_id: serviceId,
        from_kg: fromKg,
        to_kg: toKg,
        price_kg: priceKg,
      });
    }

    return updateTariffServiceRate({
      id: rateData.id,
      from_kg: fromKg,
      to_kg: toKg,
      price_kg: priceKg,
    });
  };

  const focusInput = () => {
    secondInput?.current?.focus();
    secondInput?.current?.setAttribute('autofocus', 'autofocus');
  };

  useEffect(() => {
    if (postTariffServiceRateResult.isSuccess || updateTariffServiceRateResult.isSuccess) {
      enqueueSnackbar('Rate saved', { variant: 'success' });
      setEditActive(false);

      if (onSave) {
        return onSave();
      }
    }
    if (postTariffServiceRateResult.isError || updateTariffServiceRate.isError) {
      return enqueueSnackbar('Error saving rate', { variant: 'error' });
    }
    return () => null;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [
    postTariffServiceRateResult.isSuccess,
    postTariffServiceRateResult.isError,
    updateTariffServiceRateResult.isError,
    updateTariffServiceRateResult.isSuccess,
  ]);

  useEffect(() => {
    if (deleteTariffServiceRateResult.isSuccess) {
      enqueueSnackbar('Rate deleted', { variant: 'success' });
    }
    if (deleteTariffServiceRateResult.isError) {
      enqueueSnackbar('Error deleting rate', { variant: 'error' });
    }
  }, [deleteTariffServiceRateResult.isSuccess, deleteTariffServiceRateResult.isError, rateData]);

  useEffect(() => {
    if (newRate) {
      return focusInput();
    }
    return () => null;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <TableRow>
      <TableCell>
        {editActive ? (
          <TextField
            disabled={postTariffServiceRateResult.isLoading}
            size="small"
            type="number"
            value={fromKg}
            onChange={(e) => setFromKg(e.target.value)}
            InputProps={{
              endAdornment: <InputAdornment position="end">kg</InputAdornment>,
            }}
          />
        ) : (
          <Typography variant="body2">{rateData.from_kg} kg</Typography>
        )}
      </TableCell>
      <TableCell>
        {editActive ? (
          <TextField
            inputRef={secondInput}
            disabled={postTariffServiceRateResult.isLoading}
            size="small"
            type="number"
            value={toKg}
            onChange={(e) => setToKg(e.target.value)}
            InputProps={{
              endAdornment: <InputAdornment position="end"> kg</InputAdornment>,
            }}
          />
        ) : (
          <Typography variant="body2">{rateData.to_kg} kg</Typography>
        )}
      </TableCell>
      <TableCell>
        {editActive ? (
          <TextField
            disabled={postTariffServiceRateResult.isLoading}
            size="small"
            type="number"
            value={priceKg}
            onChange={(e) => setPriceKg(e.target.value)}
            InputProps={{
              endAdornment: <InputAdornment position="end">/kg</InputAdornment>,
              startAdornment: <InputAdornment position="start">$</InputAdornment>,
            }}
          />
        ) : (
          <Typography variant="body2">${rateData.price_kg} /kg</Typography>
        )}
      </TableCell>
      <TableCell sx={{ textAlign: 'right' }}>
        {editActive ? (
          <>
            <LoadingButton
              variant="contained"
              color="success"
              loading={
                postTariffServiceRateResult.isLoading || updateTariffServiceRateResult.isLoading
              }
              onClick={handleSave}
              sx={{ mr: 1 }}
            >
              Save
            </LoadingButton>
            <LoadingButton
              loading={
                postTariffServiceRateResult.isLoading || updateTariffServiceRateResult.isLoading
              }
              onClick={handleCancel}
            >
              Cancel
            </LoadingButton>
          </>
        ) : (
          <>
            <Button
              variant="outlined"
              disabled={deleteTariffServiceRateResult.isLoading}
              sx={{ mr: 1 }}
              onClick={() => setEditActive(true)}
            >
              Edit
            </Button>

            <IconButton
              color="error"
              disabled={deleteTariffServiceRateResult.isLoading}
              onClick={() => {
                deleteTariffServiceRate({
                  rate_id: rateData.id,
                });
              }}
            >
              {deleteTariffServiceRateResult.isLoading ? (
                <CircularProgress size={20} />
              ) : (
                <Iconify icon="solar:trash-bin-2-bold" />
              )}
            </IconButton>
          </>
        )}
      </TableCell>
    </TableRow>
  );
};

RateRow.propTypes = {
  onCancel: PropTypes.func,
  onSave: PropTypes.func,
  rateData: PropTypes.object,
  serviceId: PropTypes.number,
  newRate: PropTypes.bool,
  newWeight: PropTypes.number,
};

export default RateRow;
