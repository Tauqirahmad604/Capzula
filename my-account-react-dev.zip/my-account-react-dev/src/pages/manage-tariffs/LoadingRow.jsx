import { TableRow, TableCell, CircularProgress } from '@mui/material';

const LoadingRow = () => (
  <TableRow>
    <TableCell sx={{ py: 3 }}>
      <CircularProgress size={15} />
    </TableCell>
    <TableCell sx={{ py: 3 }}>
      <CircularProgress size={15} />
    </TableCell>
    <TableCell sx={{ py: 3 }}>
      <CircularProgress size={15} />
    </TableCell>
    <TableCell sx={{ py: 3, textAlign: 'center' }}>
      <CircularProgress size={15} />
    </TableCell>
  </TableRow>
);

export default LoadingRow;
