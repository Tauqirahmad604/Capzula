/* eslint-disable react/prop-types */
import { Navigate } from 'react-router-dom';
import { enqueueSnackbar } from 'notistack';
import React, { useState, useEffect } from 'react';

import { Box } from '@mui/system';
import { LoadingButton } from '@mui/lab';
import { Card, CardContent } from '@mui/material';

import { useGetPaymentMethodsQuery, usePostFinalCheckoutMutation } from 'src/redux/api/myAccount';

import { LoadingScreen } from 'src/components/loading-screen';

import PaymentCardItemCompact from 'src/sections/payment/payment-card-item-compact';

import { useCheckoutContext } from '../../context/use-checkout-context';

export default function PaymentMethod() {
  const { data: cards, isLoading: getPaymentMethodsIsLoading } = useGetPaymentMethodsQuery();

  const [postFinalCheckout, postFinalCheckoutResults] = usePostFinalCheckoutMutation();
  const { checkoutData, actions, checkoutSummary } = useCheckoutContext();
  const [, setIsSubmitting] = useState(false);
  const isReady = () => checkoutData.payment_method_id;
  const progressToNextStep = () => {
    postFinalCheckout({
      ...checkoutData,
      nonce: checkoutSummary.checkout_nonce,
    });
  };

  useEffect(() => {
    if (postFinalCheckoutResults.isLoading) {
      setIsSubmitting(true);
    }

    if (postFinalCheckoutResults.isSuccess) {
      actions.reset();
      window.location.replace(postFinalCheckoutResults.data?.data.thankyou_url);
      actions.setIsLoading(true);
    }
    if (postFinalCheckoutResults.isError) {
      actions.setIsLoading(false);
      setIsSubmitting(false);

      enqueueSnackbar("There's been a problem completing your order, please try again", {
        variant: 'error',
      });
    }

    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [
    postFinalCheckoutResults.isSuccess,
    postFinalCheckoutResults.isLoading,
    postFinalCheckoutResults.isError,
    postFinalCheckoutResults.data?.data,
  ]);

  useEffect(() => {
    if (cards?.data && !checkoutData.payment_method_id) {
      const defaultCard = cards?.data.find((card) => card.default);
      actions.setPaymentMethodId(defaultCard?.payment_id);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [cards]);

  if (checkoutData) {
    if (checkoutData?.delivery_address_id === null) {
      return <Navigate to="/checkout" />;
    }

    if (checkoutData?.vendor_delivery_services_and_notes.length === 0) {
      return <Navigate to="/national-delivery" />;
    }
  }

  // if (getPaymentMethodsIsLoading || isSubmitting) {
  //   return <LoadingScreen />;
  // }
  return (
    <>
      {getPaymentMethodsIsLoading ? (
        <LoadingScreen />
      ) : (
        <Card>
          <CardContent>
            <Box
              rowGap={2.5}
              columnGap={2}
              display="grid"
              gridTemplateColumns={{
                xs: 'repeat(1, 1fr)',
                md: 'repeat(1, 1fr)',
              }}
            >
              {cards?.data?.map((card) => (
                <Box onClick={() => actions.setPaymentMethodId(card.payment_id)}>
                  <PaymentCardItemCompact
                    key={card.payment_id}
                    card={card}
                    selected={checkoutData.payment_method_id === card.payment_id}
                    editCard={console.log}
                    // deleteCard={handleConfirmDeleteCard}
                    // enableCard={handleEnableCard}
                    // setDefault={handleSetDefaultPaymentMethod}
                  />
                </Box>
              ))}
            </Box>
          </CardContent>
        </Card>
      )}
      <LoadingButton
        loading={postFinalCheckoutResults.isLoading}
        disabled={!isReady()}
        size="large"
        color="primary"
        variant="contained"
        fullWidth
        sx={{ mt: 3 }}
        onClick={progressToNextStep}
      >
        Place Order
      </LoadingButton>
    </>
  );
}
