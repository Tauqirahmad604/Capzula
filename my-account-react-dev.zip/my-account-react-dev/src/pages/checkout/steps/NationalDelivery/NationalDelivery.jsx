/* eslint-disable react/prop-types */
import debounce from 'lodash.debounce';
import { Navigate } from 'react-router';
import React, { useState, useEffect } from 'react';

import { Box } from '@mui/system';
import {
  Card,
  Grid,
  Alert,
  Button,
  Select,
  MenuItem,
  TextField,
  Typography,
  InputLabel,
  CardContent,
  FormControl,
  OutlinedInput,
} from '@mui/material';
import {
  Timeline,
  TimelineDot,
  TimelineItem,
  TimelineContent,
  TimelineConnector,
  TimelineSeparator,
  TimelineOppositeContent,
  timelineOppositeContentClasses,
} from '@mui/lab';

import { useRouter } from 'src/routes/hooks';

import { usePostPrepNationalDeliveryQuery } from 'src/redux/api/myAccount';

import { LoadingScreen } from 'src/components/loading-screen';

import { useCheckoutContext } from '../../context/use-checkout-context';

function VendorDeliveryServices({ deliveryServices, onChange, vendorSlug }) {
  const [selectedDeliveryCompany, setSelectedDeliveryCompany] = useState({});
  const [selectedDeliveryService, setSelectedDeliveryService] = useState({});
  const [notesForSeller, setNotesForSeller] = useState('');
  const [deliveryServiceList, setDeliveryServiceList] = useState(false);
  const deliveryCompanyList = Object.keys(deliveryServices);
  const { checkoutData } = useCheckoutContext();

  const getDefaultDeliveryCompany = () => {
    let defaultService = null;

    deliveryCompanyList.forEach((deliveryCompanyKey) =>
      deliveryServices[deliveryCompanyKey].forEach((service) => {
        if (service.default) {
          setSelectedDeliveryService(service.key);
          defaultService = service;
        }
      })
    );
    return defaultService;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  };

  useEffect(() => {
    // console.log();

    if (selectedDeliveryCompany) {
      const companyDeliveryServices = deliveryServices[selectedDeliveryCompany];
      if (companyDeliveryServices) {
        const vendorDeliveryData = checkoutData?.vendor_delivery_services_and_notes?.[vendorSlug];
        setDeliveryServiceList(companyDeliveryServices);
        if (!vendorDeliveryData?.delivery_method_service) {
          setSelectedDeliveryService(companyDeliveryServices[0].key);
        }
      }
    }
  }, [
    checkoutData?.vendor_delivery_services_and_notes,
    deliveryServices,
    selectedDeliveryCompany,
    vendorSlug,
  ]);

  useEffect(() => {
    const vendorDeliveryData = checkoutData?.vendor_delivery_services_and_notes?.[vendorSlug];

    if (vendorDeliveryData) {
      console.log(vendorDeliveryData, '< vendorDeliveryData');
      if (vendorDeliveryData?.delivery_notes) {
        setNotesForSeller(vendorDeliveryData.delivery_notes);
      }

      if (vendorDeliveryData.delivery_method_company) {
        setSelectedDeliveryCompany(vendorDeliveryData.delivery_method_company);
      }
      if (vendorDeliveryData.delivery_method_service) {
        console.log('adding delivery_method_service', vendorDeliveryData.delivery_method_service);
        setSelectedDeliveryService(vendorDeliveryData.delivery_method_service);
      }
    } else {
      const defaultDeliveryCompany = getDefaultDeliveryCompany(deliveryServices);
      if (defaultDeliveryCompany) {
        setSelectedDeliveryCompany(defaultDeliveryCompany.company_name);
      } else {
        setSelectedDeliveryCompany(deliveryCompanyList[0]);
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [deliveryServices]);

  const handleDeliveryCompanyChange = (companyKey) => {
    setSelectedDeliveryCompany(companyKey);
  };

  const handleDeliveryServiceChange = (serviceKey) => {
    setSelectedDeliveryService(serviceKey);
  };

  useEffect(() => {
    console.log(selectedDeliveryService, ' << selectedDeliveryService updated');
  }, [selectedDeliveryService]);

  useEffect(() => {
    onChange({ vendorSlug, selectedDeliveryCompany, selectedDeliveryService, notesForSeller });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedDeliveryCompany, selectedDeliveryService, vendorSlug]);

  const debouncedNotesForSeller = debounce((notesForSellerValue) => {
    // setNotesForSeller(notesForSellerValue);
    onChange({
      vendorSlug,
      selectedDeliveryCompany,
      selectedDeliveryService,
      notesForSeller: notesForSellerValue,
    });
  }, 800);

  // useEffect(() => {
  //   const vendorDeliveryData = checkoutData?.vendor_delivery_services_and_notes?.[vendorId];
  //   if (vendorDeliveryData?.delivery_notes) {
  //     setNotesForSeller(vendorDeliveryData.delivery_notes);
  //   }
  //   if (vendorDeliveryData?.delivery_method_company) {
  //     setSelectedDeliveryCompany(vendorDeliveryData.delivery_method_company);
  //   }
  //   if (vendorDeliveryData?.delivery_method_service) {
  //     setSelectedDeliveryService(vendorDeliveryData.delivery_method_service);
  //   }
  // }, []);

  return (
    <FormControl fullWidth sx={{ display: 'flex' }}>
      <Box
        rowGap={2}
        columnGap={2}
        display="grid"
        gridTemplateColumns={{
          xs: 'repeat(1, 1fr)',
          sm: 'repeat(2, 1fr)',
        }}
      >
        {' '}
        {deliveryServices ? (
          <>
            <FormControl>
              <InputLabel>Delivery Company</InputLabel>
              <Select
                value={selectedDeliveryCompany}
                onChange={(e) => handleDeliveryCompanyChange(e.target.value)}
                input={<OutlinedInput label="Delivery Company" />}
              >
                {deliveryCompanyList.map((deliveryServiceKey) => (
                  <MenuItem
                    key={deliveryServiceKey}
                    // selected={selectedDeliveryCompany.company_name === deliveryServiceKey}
                    value={deliveryServiceKey}
                  >
                    {deliveryServiceKey}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
            <FormControl>
              <InputLabel>Delivery Service</InputLabel>
              <Select
                value={selectedDeliveryService}
                onChange={(e) => handleDeliveryServiceChange(e.target.value)}
                input={<OutlinedInput label="Delivery Service" />}
              >
                {deliveryServiceList &&
                  deliveryServiceList?.map((deliveryService) => (
                    <MenuItem key={deliveryService.key} value={deliveryService.key}>
                      {deliveryService.service_name}
                    </MenuItem>
                  ))}
              </Select>
            </FormControl>
          </>
        ) : (
          <Alert severity="warning">
            <Typography variant="body2">
              This vendor has no delivery options set. Please chat to us to fix this.
              <Button>Chat Now</Button>
            </Typography>
          </Alert>
        )}
      </Box>

      <FormControl sx={{ mt: 2 }}>
        <TextField
          autoComplete="off"
          label="Notes for seller"
          fullWidth
          value={notesForSeller}
          onChange={(e) => setNotesForSeller(e.target.value)}
          onBlur={(e) => {
            debouncedNotesForSeller(e.target.value);
          }}
          placeholder=""
        />
      </FormControl>
    </FormControl>
  );
}
export default function NationalDelivery() {
  const {
    checkoutData,
    actions: { setVendorDeliveryServicesAndNotes },
  } = useCheckoutContext();

  const { data, refetch, isLoading } = usePostPrepNationalDeliveryQuery({
    delivery_address_id: checkoutData.delivery_address_id,
    // international_shipping_
  });

  const router = useRouter();

  if (checkoutData.delivery_address_id === null) {
    return <Navigate to="/checkout" />;
  }

  const progressToNextStep = () => {
    router.push('/checkout/payment-method');
  };

  const vendorList = data?.data?.vendors || {};
  const deliveryAddressDetails = data?.data?.delivery_address_details || {};

  if (isLoading) {
    return <LoadingScreen />;
  }

  const isReady = () =>
    checkoutData?.vendor_delivery_services_and_notes
      ? Object.keys(checkoutData?.vendor_delivery_services_and_notes).length > 0
      : false;

  const isInternational = (countryCodeKey, vendorSlug) =>
    vendorList[countryCodeKey][vendorSlug].delivering_to_logistic_company;
  return (
    <>
      <Button onClick={refetch}>Refresh</Button>

      {Object.keys(vendorList).map((countryCodeKey) => (
        <>
          {/* <h4>{countryCodeKey}</h4> */}
          {Object.keys(vendorList[countryCodeKey]).map((vendorSlug) => (
            <Card sx={{ mb: 3 }} key={`${countryCodeKey}-${vendorSlug}`}>
              <CardContent>
                <Grid container spacing={2}>
                  <Grid xs={12} sm={6} lg={6}>
                    <Timeline
                      sx={{
                        [`
                          min-width: 450px;
                          & .${timelineOppositeContentClasses.root}`]: {
                          flex: 0.2,
                        },
                      }}
                    >
                      <TimelineItem>
                        <TimelineOppositeContent color="textSecondary">
                          <Typography variant="body2" fontSize={12}>
                            Delivery From
                          </Typography>
                        </TimelineOppositeContent>
                        <TimelineSeparator>
                          <TimelineDot color="primary" />
                          <TimelineConnector
                            sx={{
                              bgcolor: 'primary.main',
                            }}
                          />
                        </TimelineSeparator>
                        <TimelineContent>
                          <Box sx={{ display: 'flex' }}>
                            <Box>
                              <Typography fontWeight={500} variant="body2">
                                {vendorList[countryCodeKey][vendorSlug].vendor_name}
                              </Typography>

                              <Typography flexWrap="wrap" variant="body2" fontSize={12}>
                                {vendorList[countryCodeKey][vendorSlug].address.state_name},{' '}
                                {vendorList[countryCodeKey][vendorSlug].address.country_name}
                              </Typography>
                            </Box>
                          </Box>
                        </TimelineContent>
                      </TimelineItem>

                      {isInternational(countryCodeKey, vendorSlug) && (
                        <TimelineItem>
                          <TimelineOppositeContent color="textSecondary">
                            <Typography variant="body2" fontSize={12}>
                              Logistics Partner
                            </Typography>
                          </TimelineOppositeContent>
                          <TimelineSeparator>
                            <TimelineDot color="primary" />
                            <TimelineConnector />
                          </TimelineSeparator>

                          <TimelineContent>
                            <Box sx={{ display: 'flex' }}>
                              <Box>
                                <Typography fontWeight={500} variant="body2">
                                  {
                                    vendorList[countryCodeKey][vendorSlug]
                                      .delivering_to_logistic_company.business_details.business_name
                                  }
                                </Typography>
                                <Typography variant="body2" fontSize={12}>
                                  {
                                    vendorList[countryCodeKey][vendorSlug]
                                      .delivering_to_logistic_company.business_details.address
                                      .state_name
                                  }
                                  ,{' '}
                                  {
                                    vendorList[countryCodeKey][vendorSlug]
                                      .delivering_to_logistic_company.business_details.address
                                      .country_name
                                  }
                                </Typography>
                              </Box>
                            </Box>
                          </TimelineContent>
                        </TimelineItem>
                      )}

                      {isInternational(countryCodeKey, vendorSlug) && (
                        <TimelineItem sx={{ opacity: 0.5 }}>
                          <TimelineOppositeContent color="textSecondary">
                            <Typography variant="body2" fontSize={12}>
                              Shipping To
                            </Typography>
                          </TimelineOppositeContent>
                          <TimelineSeparator>
                            <TimelineDot color="grey" />
                          </TimelineSeparator>

                          <TimelineContent>
                            <Box sx={{ display: 'flex', alignItems: 'center' }} gap={3}>
                              <Box
                                gap={3}
                                sx={{
                                  display: 'flex',
                                  alignItems: 'center',
                                }}
                              >
                                <Box sx={{ display: 'flex', alignItems: 'center' }}>
                                  <Box>
                                    <Typography fontWeight={500} variant="body2">
                                      {deliveryAddressDetails.customer_company}
                                    </Typography>
                                    <Typography variant="body2" fontSize={12}>
                                      {deliveryAddressDetails?.full_address?.address_1},{' '}
                                      {deliveryAddressDetails?.full_address?.address_2
                                        ? `${deliveryAddressDetails?.full_address?.address_2}, `
                                        : ''}
                                      {deliveryAddressDetails?.full_address?.city},{' '}
                                      {deliveryAddressDetails?.full_address?.postcode}
                                    </Typography>
                                  </Box>
                                </Box>
                              </Box>
                            </Box>
                          </TimelineContent>
                        </TimelineItem>
                      )}

                      {!isInternational(countryCodeKey, vendorSlug) && (
                        <TimelineItem>
                          <TimelineOppositeContent color="textSecondary">
                            <Typography variant="body2" fontSize={12}>
                              Shipping To
                            </Typography>
                          </TimelineOppositeContent>
                          <TimelineSeparator>
                            <TimelineDot color="primary" />
                            <TimelineConnector />
                          </TimelineSeparator>
                          <TimelineContent>
                            <Box sx={{ display: 'flex' }}>
                              <Box>
                                <Typography fontWeight={500} variant="body2">
                                  {deliveryAddressDetails.customer_company}
                                </Typography>
                                <Typography variant="body2" fontSize={12}>
                                  {deliveryAddressDetails.address_1},{' '}
                                  {deliveryAddressDetails.address_2
                                    ? `${deliveryAddressDetails.address_2}, `
                                    : ''}
                                  {deliveryAddressDetails.city}, {deliveryAddressDetails.postcode}
                                </Typography>
                              </Box>
                            </Box>
                          </TimelineContent>
                        </TimelineItem>
                      )}
                    </Timeline>
                  </Grid>
                  <Grid xs={12} sm={6} lg={6}>
                    {vendorList[countryCodeKey][vendorSlug].delivery_services && (
                      <Box sx={{ mt: 4 }}>
                        <VendorDeliveryServices
                          vendorId={vendorSlug}
                          // vendorSlug={vendorList[countryCodeKey][vendorSlug].vendor_slug}
                          vendorSlug={vendorSlug}
                          onChange={(vendorDeliveryServicesData) => {
                            setVendorDeliveryServicesAndNotes(vendorDeliveryServicesData);
                          }}
                          deliveryServices={
                            vendorList[countryCodeKey][vendorSlug].delivery_services
                          }
                        />
                      </Box>
                    )}
                  </Grid>
                </Grid>
              </CardContent>
            </Card>
          ))}
        </>
      ))}
      <Button
        disabled={!isReady()}
        size="large"
        color="primary"
        variant="contained"
        fullWidth
        onClick={progressToNextStep}
      >
        Continue
      </Button>
    </>
  );
}
