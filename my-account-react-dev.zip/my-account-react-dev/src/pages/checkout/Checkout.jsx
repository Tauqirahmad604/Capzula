/* eslint-disable react/prop-types */
import styled from '@emotion/styled';
import { css } from '@emotion/react';
import React, { useState, useCallback } from 'react';

import { Box, Step, Button, Stepper, StepLabel, Typography } from '@mui/material';

import { PARENT_HOST_URL } from 'src/config-global';

import Logo from 'src/components/logo';
import { LoadingScreen } from 'src/components/loading-screen';

import CheckoutSummary from './CheckoutSummary';
import PaymentMethod from './steps/PaymentMethod/PaymentMethod';
import { useCheckoutContext } from './context/use-checkout-context';
import CheckoutDeliveryAddress from './steps/DeliveryAddress/DeliveryAddress';
import CheckoutNationalDelivery from './steps/NationalDelivery/NationalDelivery';
import CheckoutInternationalShipping from './steps/InternationalShipping/InternationalShipping';

const HorizontalLinearAlternativeLabelStepper = React.memo(({ activeStep }) => {
  const { checkoutStatus } = useCheckoutContext();
  const stepsArray = useCallback(() => {
    const nav = ['Delivery Address', 'National Delivery', 'Payment Method'];
    if (!checkoutStatus.skip) {
      nav.splice(1, 0, 'International Shipping');
    }
    return nav;
  }, [checkoutStatus.skip]);

  const prepActiveStep = () => {
    if (checkoutStatus.skip && activeStep > 1) {
      return activeStep - 1;
    }
    return activeStep;
  };

  return (
    <Box sx={{ width: '100%', mt: 4 }}>
      <Stepper activeStep={prepActiveStep()} alternativeLabel>
        {stepsArray().map((label) => (
          <Step key={label}>
            <StepLabel>{label}</StepLabel>
          </Step>
        ))}
      </Stepper>
    </Box>
  );
});

const Header = React.memo(({ setSummaryIsOpen }) => (
  <Box
    sx={{
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      flexDirection: { xs: 'column', sm: 'row' },
      pb: 3,
    }}
  >
    <Box sx={{ marginBottom: { xs: 1, sm: 0 }, display: { xs: 'none', sm: 'block' } }}>
      <Logo />
    </Box>
    <Box sx={{ display: 'flex', alignItems: 'center' }}>
      <Button
        onClick={() => {
          window.location.href = `${PARENT_HOST_URL}/cart`;
        }}
        // variant="outlined"
        color="primary"
        size="small"
      >
        Return to cart
      </Button>
      <Button
        sx={{ ml: 2, display: { xs: 'block', md: 'none' } }}
        size="small"
        onClick={() => setSummaryIsOpen(true)}
        variant="outlined"
        color="primary"
      >
        Show Order Summary
      </Button>
    </Box>
  </Box>
));

const IsLoadingContainer = React.memo(({ children }) => {
  const { checkoutStatus } = useCheckoutContext();
  return (
    <>
      {checkoutStatus.isLoading && (
        <Box
          sx={{
            position: 'fixed',
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            zIndex: 200,
            bgcolor: 'white',
          }}
        >
          <LoadingScreen />
        </Box>
      )}
      {children}
    </>
  );
});

const PageContainer = styled.div`
  display: flex;
  width: 100%;
  height: 100vh;
`;

const FormContainer = styled.div`
  width: 100%;
  padding: 10px;
  overflow-y: scroll;
  height: 100vh;

  @media (min-width: 768px) {
    width: 60%;
    padding: 20px;
  }
  @media (min-width: 1000px) {
    padding: 40px;
  }
`;

const SummaryContainer = styled.div`
  background-color: white;
  width: 90%;
  padding: 20px;
  overflow-y: scroll;
  height: 100vh;
  position: fixed;
  transform: translateX(110%);
  transition: transform 0.3s ease-in-out;

  ${({ isOpen }) =>
    isOpen &&
    css`
      transform: translateX(10%);
    `}

  @media (min-width: 768px) {
    transform: unset;
    position: unset;
    width: 40%;
  }
`;

const BackgroundClose = styled.div`
  background-color: rgba(0, 0, 0, 0.3);
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  display: none;
  @media (max-width: 768px) {
    ${({ isOpen }) =>
      isOpen &&
      css`
        display: block;
      `}
  }
`;

export default function CheckoutPage({ step }) {
  const [summaryIsOpen, setSummaryIsOpen] = useState(false);

  const stepNumbers = (activeStep) => {
    switch (activeStep) {
      case 'delivery_address':
        return 0;
      case 'international_shipping':
        return 1;
      case 'national_delivery':
        return 2;
      case 'payment_method':
        return 3;
      default:
        return 0;
    }
  };

  const renderCheckoutSteps = (activeStep) => {
    switch (activeStep) {
      case 'delivery_address':
        return (
          <IsLoadingContainer>
            <Typography variant="h4" gutterBottom>
              Delivery address
            </Typography>
            <Typography variant="body2" sx={{ mb: 3 }}>
              Please select your delivery address
            </Typography>
            <CheckoutDeliveryAddress />
          </IsLoadingContainer>
        );
      case 'international_shipping':
        return (
          <IsLoadingContainer>
            <Typography variant="h4" gutterBottom>
              International Shipping
            </Typography>
            <Typography variant="body2" sx={{ mb: 3 }}>
              Please select your international shipping method
            </Typography>
            <CheckoutInternationalShipping />
          </IsLoadingContainer>
        );
      case 'national_delivery':
        return (
          <IsLoadingContainer>
            <Typography variant="h4" gutterBottom>
              National Delivery
            </Typography>
            <Typography variant="body2" sx={{ mb: 3 }}>
              National delivery details go here
            </Typography>
            <CheckoutNationalDelivery />
          </IsLoadingContainer>
        );
      case 'payment_method':
        return (
          <IsLoadingContainer>
            <Typography variant="h4" gutterBottom>
              Payment Method
            </Typography>
            <Typography variant="body2" sx={{ mb: 3 }}>
              Payment method details go here
            </Typography>
            <PaymentMethod />
          </IsLoadingContainer>
        );
      default:
        return <Box>Unknown step</Box>;
    }
  };

  return (
    <PageContainer>
      <FormContainer>
        <Header setSummaryIsOpen={setSummaryIsOpen} />
        <HorizontalLinearAlternativeLabelStepper activeStep={stepNumbers(step)} />
        <Box sx={{ mt: 6 }}>{renderCheckoutSteps(step)}</Box>
      </FormContainer>
      <BackgroundClose onClick={() => setSummaryIsOpen(!summaryIsOpen)} isOpen={summaryIsOpen} />
      <SummaryContainer isOpen={summaryIsOpen}>
        <CheckoutSummary />
      </SummaryContainer>
    </PageContainer>
  );
}
