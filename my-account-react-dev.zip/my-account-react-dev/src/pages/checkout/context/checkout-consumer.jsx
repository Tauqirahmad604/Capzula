import PropTypes from 'prop-types';

import { CheckoutContext } from './checkout-context';

// ----------------------------------------------------------------------

export function CheckoutConsumer({ children }) {
  return <CheckoutContext.Consumer>{children}</CheckoutContext.Consumer>;
}

CheckoutConsumer.propTypes = {
  children: PropTypes.node,
};
