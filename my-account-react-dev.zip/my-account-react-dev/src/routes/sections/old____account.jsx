import { lazy, Suspense } from 'react';
import { Outlet } from 'react-router-dom';

import { AuthGuard } from 'src/auth/guard';
import DashboardLayout from 'src/layouts/dashboard';
import { WP_MY_ACCOUNT_BASE_URL } from 'src/config-global';

import { LoadingScreen } from 'src/components/loading-screen';

const IFramePage = lazy(() => import('src/pages/iframe-page'));

export const accountRoutes = [
  {
    path: 'account',
    element: (
      <AuthGuard>
        <DashboardLayout>
          <Suspense fallback={<LoadingScreen />}>
            <Outlet />
          </Suspense>
        </DashboardLayout>
      </AuthGuard>
    ),
    children: [
      // { element: <DashboardHome />, index: true },
      {
        path: 'documents',
        element: (
          <IFramePage src={`${WP_MY_ACCOUNT_BASE_URL}/my-account/my-documents/?layout=none`} />
        ),
      },
      {
        path: 'business-details',
        element: (
          <IFramePage src={`${WP_MY_ACCOUNT_BASE_URL}/my-account/business-details/?layout=none`} />
        ),
      },

      {
        path: 'payment-methods',
        element: (
          <IFramePage src={`${WP_MY_ACCOUNT_BASE_URL}/my-account/payment-methods/?layout=none`} />
        ),
      },

      {
        path: 'personal-details',
        element: (
          <IFramePage src={`${WP_MY_ACCOUNT_BASE_URL}/my-account/my-details/?layout=none`} />
        ),
      },

      {
        path: 'account-details',
        element: (
          <IFramePage src={`${WP_MY_ACCOUNT_BASE_URL}/my-account/edit-account/?layout=none`} />
        ),
      },
    ],
  },
];
