import { lazy, Suspense } from 'react';
import { Outlet } from 'react-router-dom';

import { AuthGuard } from 'src/auth/guard';
import DashboardLayout from 'src/layouts/dashboard';
import PermissionsGuard from 'src/auth/guard/permissions-guard';

import { LoadingScreen } from 'src/components/loading-screen';

const ChatPage = lazy(() => import('src/pages/dashboard/Chat'));

export const chatsRoutes = [
  {
    path: 'chats',
    element: (
      <AuthGuard>
        <DashboardLayout>
          <Suspense fallback={<LoadingScreen />}>
            <Outlet />
          </Suspense>
        </DashboardLayout>
      </AuthGuard>
    ),
    children: [
      {
        element: (
          <PermissionsGuard
            permission="manage_chats_edit"
            roles={['vendor', 'customer', 'vendor_staff', 'logistics_partner']}
          >
            <ChatPage />
          </PermissionsGuard>
        ),
        index: true,
      },
    ],
  },
];
