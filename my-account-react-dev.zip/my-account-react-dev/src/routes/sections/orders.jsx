import { lazy, Suspense } from 'react';
import { Outlet } from 'react-router-dom';

import { AuthGuard } from 'src/auth/guard';
import DashboardLayout from 'src/layouts/dashboard';
import PermissionsGuard from 'src/auth/guard/permissions-guard';

import { LoadingScreen } from 'src/components/loading-screen';

const OrderListPage = lazy(() => import('src/pages/orders/OrderList'));

export const ordersRoutes = [
  {
    path: 'orders',
    element: (
      <AuthGuard>
        <DashboardLayout>
          <Suspense fallback={<LoadingScreen />}>
            <Outlet />
          </Suspense>
        </DashboardLayout>
      </AuthGuard>
    ),
    children: [
      {
        element: (
          <PermissionsGuard
            permission="manage_orders_view"
            roles={['vendor', 'customer', 'vendor_staff', 'logistics_partner']}
          >
            <OrderListPage />
          </PermissionsGuard>
        ),
        index: true,
      },
      {
        path: ':pageNum',
        element: (
          <PermissionsGuard
            permission="manage_orders_view"
            roles={['vendor', 'customer', 'vendor_staff', 'logistics_partner']}
          >
            <OrderListPage />
          </PermissionsGuard>
        ),
      },
      {
        path: 'sub/:orderId',
        element: (
          <PermissionsGuard
            permission="manage_orders_view"
            roles={['vendor', 'customer', 'vendor_staff', 'logistics_partner']}
          >
            <OrderListPage />
          </PermissionsGuard>
        ),
      },
    ],
  },
];
