import { lazy, Suspense } from 'react';
import { Outlet } from 'react-router-dom';

import { AuthGuard } from 'src/auth/guard';
import DashboardLayout from 'src/layouts/dashboard';
import PermissionsGuard from 'src/auth/guard/permissions-guard';

import { LoadingScreen } from 'src/components/loading-screen';

const Feed = lazy(() => import('src/pages/dashboard/FavVendors'));

export const feedRoutes = [
  {
    path: 'feed',
    element: (
      <AuthGuard>
        <DashboardLayout>
          <Suspense fallback={<LoadingScreen />}>
            <Outlet />
          </Suspense>
        </DashboardLayout>
      </AuthGuard>
    ),
    children: [
      {
        element: (
          <PermissionsGuard roles={['customer']}>
            <Feed />
          </PermissionsGuard>
        ),
        index: true,
      },
    ],
  },
];
