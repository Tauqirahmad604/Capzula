import { lazy, Suspense } from 'react';
import { Outlet } from 'react-router-dom';

import { AuthGuard } from 'src/auth/guard';
import DashboardLayout from 'src/layouts/dashboard';
import PermissionsGuard from 'src/auth/guard/permissions-guard';

import { LoadingScreen } from 'src/components/loading-screen';

const PaymentMethodsPage = lazy(() => import('src/pages/payment-methods/paymentMethodsPage'));
// const EditCountryPage = lazy(() => import('src/pages/manage-tariffs/EditTariff'));

export const paymentMethodsRouters = [
  {
    path: 'payment-methods',
    element: (
      <AuthGuard>
        <DashboardLayout>
          <Suspense fallback={<LoadingScreen />}>
            <Outlet />
          </Suspense>
        </DashboardLayout>
      </AuthGuard>
    ),
    children: [
      {
        element: (
          <PermissionsGuard roles={['customer']}>
            <PaymentMethodsPage />
          </PermissionsGuard>
        ),
        index: true,
      },
      {
        path: ':action',
        element: (
          <PermissionsGuard roles={['customer']}>
            <PaymentMethodsPage />
          </PermissionsGuard>
        ),
      },
    ],
  },
];
