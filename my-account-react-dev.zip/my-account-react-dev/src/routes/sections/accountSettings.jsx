import { lazy, Suspense } from 'react';
import { Outlet } from 'react-router-dom';

import { AuthGuard } from 'src/auth/guard';
import DashboardLayout from 'src/layouts/dashboard';

import { LoadingScreen } from 'src/components/loading-screen';

const GeneralAccountSettingPage = lazy(() => import('src/pages/account-settings/General'));
const SecurtySettingsPage = lazy(() => import('src/pages/account-settings/Security'));
const BusinessDetailsPage = lazy(() => import('src/pages/account-settings/BusinessDetails'));
const BusinessDocumentsPage = lazy(() => import('src/pages/account-settings/BusinessDocuments'));

// const EditCountryPage = lazy(() => import('src/pages/manage-tariffs/EditTariff'));

export const accountSettingsRouters = [
  {
    path: 'account-settings',
    element: (
      <AuthGuard>
        <DashboardLayout>
          <Suspense fallback={<LoadingScreen />}>
            <Outlet />
          </Suspense>
        </DashboardLayout>
      </AuthGuard>
    ),
    children: [
      {
        element: <GeneralAccountSettingPage />,
        index: true,
      },
      {
        path: 'security',
        element: <SecurtySettingsPage />,
      },
      {
        path: 'business-details',
        element: <BusinessDetailsPage />,
      },
      {
        path: 'business-documents',
        element: <BusinessDocumentsPage />,
      },
    ],
  },
];
