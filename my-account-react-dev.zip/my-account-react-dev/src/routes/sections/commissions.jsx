import { lazy, Suspense } from 'react';
import { Outlet } from 'react-router-dom';

import { AuthGuard } from 'src/auth/guard';
import DashboardLayout from 'src/layouts/dashboard';
import PermissionsGuard from 'src/auth/guard/permissions-guard';

import { LoadingScreen } from 'src/components/loading-screen';

const CommissionsListPage = lazy(() => import('src/pages/commissions/CommissionsList'));

export const commissionsRouters = [
  {
    path: 'commissions',
    element: (
      <AuthGuard>
        <DashboardLayout>
          <Suspense fallback={<LoadingScreen />}>
            <Outlet />
          </Suspense>
        </DashboardLayout>
      </AuthGuard>
    ),
    children: [
      {
        element: (
          <PermissionsGuard
            permission="manage_commissions_view"
            roles={['vendor', 'vendor_staff', 'payment_partner']}
          >
            <CommissionsListPage />
          </PermissionsGuard>
        ),
        index: true,
      },
    ],
  },
];
