import { Suspense } from 'react';
import PropTypes from 'prop-types';
import { Crisp } from 'crisp-sdk-web';
import { Outlet } from 'react-router-dom';

import { Box, Stack, Container } from '@mui/system';
import {
  Card,
  Step,
  Alert,
  Button,
  Stepper,
  StepLabel,
  Typography,
  CardContent,
} from '@mui/material';

import { GuestGuard } from 'src/auth/guard';
import { BusinessDetailsForm } from 'src/pages/account-settings/BusinessDetails';
import { BusinessDocumentsForm } from 'src/pages/account-settings/BusinessDocuments';

import { SplashScreen } from 'src/components/loading-screen';
// ----------------------------------------------------------------------

// JWT
// const JwtLoginPage = lazy(() => import('src/pages/auth/jwt/login'));

// ----------------------------------------------------------------------

const steps = ['Business Details', 'Business Documents'];

export default function HorizontalLinearAlternativeLabelStepper({ activeStep }) {
  return (
    <Box sx={{ width: '100%' }}>
      <Stepper activeStep={activeStep} alternativeLabel>
        {steps.map((label) => (
          <Step key={label}>
            <StepLabel>{label}</StepLabel>
          </Step>
        ))}
      </Stepper>
    </Box>
  );
}

HorizontalLinearAlternativeLabelStepper.defaultProps = {
  activeStep: 0,
};
HorizontalLinearAlternativeLabelStepper.propTypes = {
  activeStep: PropTypes.number,
};

export const wizardRouters = [
  {
    path: 'wizard',
    element: (
      <GuestGuard ignoreTwoFa>
        <Suspense fallback={<SplashScreen />}>
          <Outlet />
        </Suspense>
      </GuestGuard>
    ),
    children: [
      {
        path: 'business-details',
        element: (
          <Box
            sx={{
              display: 'flex',
              justifyContent: 'center',
              alignItems: 'center',
              height: '100%',
              backgroundImage: `url("/assets/background/2fa-bg-1.jpg")`,
              backgroundSize: 'cover',
              backgroundPosition: 'center',
            }}
          >
            <Box
              sx={{
                position: 'absolute',
                top: 0,
                bottom: 0,
                right: 0,
                left: 0,
                // zIndex: '200',
                backgroundColor: 'rgba(000,000,000, 0.6)',
              }}
            />
            <Stack spacing={3} sx={{ zIndex: 200 }}>
              {/* <Logo justifyContent="center" /> */}
              <Container maxWidth="md">
                <Card>
                  <CardContent>
                    <Box sx={{ mb: 3 }}>
                      <HorizontalLinearAlternativeLabelStepper activeStep={0} />
                    </Box>

                    <Alert severity="secondary" sx={{ my: 2 }}>
                      Thank you for registering with us. To continue, we need a little bit more
                      information about your buisness.
                    </Alert>
                    {/* <Typography variant="body2" sx={{ py: 2, pt: 0 }}>
                      Thank you for registering with us. To continue, we need a little bit more
                      information about your buisness.
                    </Typography> */}

                    <BusinessDetailsForm wizardActive />
                  </CardContent>
                </Card>
              </Container>
              <Box justifyContent="center" textAlign="center" width="100%">
                <Typography variant="body2" fontWeight="600" sx={{ color: '#FFF' }}>
                  Do you have any questions?{' '}
                  <Button sx={{ ml: 1 }} variant="outlined">
                    Chat Now
                  </Button>
                </Typography>
              </Box>
            </Stack>
          </Box>
        ),
      },
      {
        path: 'documents',
        element: (
          <Box
            sx={{
              display: 'flex',
              justifyContent: 'center',
              alignItems: 'center',
              height: '100%',
              backgroundImage: `url("/assets/background/2fa-bg-1.jpg")`,
              backgroundSize: 'cover',
              backgroundPosition: 'center',
            }}
          >
            <Box
              sx={{
                position: 'absolute',
                top: 0,
                bottom: 0,
                right: 0,
                left: 0,
                // zIndex: '200',
                backgroundColor: 'rgba(000,000,000, 0.6)',
              }}
            />
            <Stack spacing={3} sx={{ zIndex: 200 }}>
              {/* <Logo justifyContent="center" /> */}

              <Container maxWidth="md">
                <Card>
                  <CardContent>
                    <Box sx={{ mb: 3 }}>
                      <HorizontalLinearAlternativeLabelStepper activeStep={1} />
                    </Box>
                    {/* <Typography variant="h4" sx={{ mb: 1, mt: 3 }}>
                      Account Setup <small style={{ fontWeight: '500' }}> Business Details</small>
                    </Typography> */}
                    {/* <Typography variant="body1" sx={{ py: 2 }}>
                      Thank you for registering with us. To continue, we need a little bit more
                      information about your buisness.
                    </Typography> */}
                    <BusinessDocumentsForm wizardActive />
                  </CardContent>
                </Card>
              </Container>
              <Box justifyContent="center" textAlign="center" width="100%">
                <Typography variant="body2" fontWeight="600" sx={{ color: '#FFF' }}>
                  Do you have any questions?{' '}
                  <Button onClick={() => Crisp.chat.open()} sx={{ ml: 1 }} variant="outlined">
                    Chat Now
                  </Button>
                </Typography>
              </Box>
            </Stack>
          </Box>
        ),
      },
    ],
  },
];
