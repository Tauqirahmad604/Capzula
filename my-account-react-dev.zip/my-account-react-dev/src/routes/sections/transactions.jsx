import { lazy, Suspense } from 'react';
import { Outlet } from 'react-router-dom';

import { AuthGuard } from 'src/auth/guard';
import DashboardLayout from 'src/layouts/dashboard';
import PermissionsGuard from 'src/auth/guard/permissions-guard';

import { LoadingScreen } from 'src/components/loading-screen';

const TransactionsPage = lazy(() => import('src/pages/transactions/TransactionsPage'));

export const transactionRouters = [
  {
    path: 'transactions',
    element: (
      <AuthGuard>
        <DashboardLayout>
          <Suspense fallback={<LoadingScreen />}>
            <Outlet />
          </Suspense>
        </DashboardLayout>
      </AuthGuard>
    ),
    children: [
      {
        element: (
          <PermissionsGuard
            roles={['vendor', 'vendor_staff', 'payment_partner']}
          >
            <TransactionsPage />
          </PermissionsGuard>
        ),
        index: true,
      },
    ],
  },
];
