import { useState, useEffect } from 'react';
import { Navigate, useRoutes } from 'react-router-dom';

import { localStorageGetItem } from 'src/utils/storage-available';

import { PATH_AFTER_LOGIN } from 'src/config-global';

import { mainRoutes } from './main';
import { authRoutes } from './auth';
import { feedRoutes } from './feed';
import { chatsRoutes } from './chats';
import { orderRoutes } from './order';
import { staffRouters } from './staff';
import { usersRouters } from './users';
import { ordersRoutes } from './orders';
import { wizardRouters } from './wizard';
import { accountRoutes } from './account';
import { productsRoutes } from './products';
import { checkoutRoutes } from './checkout';
import { dashboardRoutes } from './dashboard';
import { accessLogsRouters } from './accessLogs';
import { commissionsRouters } from './commissions';
import { transactionRouters } from './transactions';
import { manageTariffsRouters } from './manageTariffs';
import { paymentMethodsRouters } from './paymentMethods';
import { accountSettingsRouters } from './accountSettings';
import { DeliveryAddressRouters } from './deliveryMethods';
import { logisticPartnersRoutes } from './logistic-partners';
import { reviewRouters } from './reviews';
// ----------------------------------------------------------------------

export default function Router() {
  const [lang, setLang] = useState('en');
  console.log('mounted!!!!');
  const langStorage = localStorageGetItem('i18nextLng');
  useEffect(() => {
    const languageCookie =
      (langStorage?.includes('_') ? langStorage.split('_')[0] : langStorage) || 'en';
    setLang(languageCookie);
  }, [langStorage]);
  return useRoutes([
    {
      path: '/',
      element: <Navigate to={PATH_AFTER_LOGIN} replace />,
    },

    // Auth routes
    ...mainRoutes,
    ...authRoutes,
    ...dashboardRoutes,
    ...accountRoutes(lang),
    ...ordersRoutes,
    ...orderRoutes,
    ...feedRoutes,
    ...chatsRoutes,
    ...productsRoutes,
    ...commissionsRouters,
    ...staffRouters,
    ...manageTariffsRouters,
    ...accessLogsRouters,
    ...usersRouters,
    ...transactionRouters,
    ...accountSettingsRouters,
    ...paymentMethodsRouters,
    ...DeliveryAddressRouters,
    ...wizardRouters,
    ...logisticPartnersRoutes,
    ...checkoutRoutes,
    ...reviewRouters,

    // No match 404
    { path: '*', element: <Navigate to="/404" replace /> },
  ]);
}
