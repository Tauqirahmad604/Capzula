import { lazy, Suspense } from 'react';
import { Outlet } from 'react-router-dom';

import { AuthGuard } from 'src/auth/guard';
import DashboardLayout from 'src/layouts/dashboard';
import PermissionsGuard from 'src/auth/guard/permissions-guard';

import { LoadingScreen } from 'src/components/loading-screen';

const LogisticPartnersCountries = lazy(
  () => import('src/pages/logistic-partners/LogisticPartnersCountries')
);

export const logisticPartnersRoutes = [
  {
    path: 'logistic-partners',
    element: (
      <AuthGuard>
        <DashboardLayout>
          <Suspense fallback={<LoadingScreen />}>
            <Outlet />
          </Suspense>
        </DashboardLayout>
      </AuthGuard>
    ),
    children: [
      {
        element: (
          <PermissionsGuard roles={['customer']}>
            <LogisticPartnersCountries />
          </PermissionsGuard>
        ),
        index: true,
      },
      {
        path: ':countryId/:stateId',
        element: (
          <PermissionsGuard roles={['customer']}>
            <LogisticPartnersCountries />
          </PermissionsGuard>
        ),
      },
      {
        path: ':countryId/:stateId/add-lp',
        element: (
          <PermissionsGuard roles={['customer']}>
            <LogisticPartnersCountries addLp />
          </PermissionsGuard>
        ),
      },
    ],
  },
];
