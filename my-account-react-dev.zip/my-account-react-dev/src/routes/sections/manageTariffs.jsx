import { lazy, Suspense } from 'react';
import { Outlet } from 'react-router-dom';

import { AuthGuard } from 'src/auth/guard';
import DashboardLayout from 'src/layouts/dashboard';
import PermissionsGuard from 'src/auth/guard/permissions-guard';

import { LoadingScreen } from 'src/components/loading-screen';

const CountryListPage = lazy(() => import('src/pages/manage-tariffs/CountryList'));
const EditCountryPage = lazy(() => import('src/pages/manage-tariffs/EditTariff'));

export const manageTariffsRouters = [
  {
    path: 'manage-tariffs',
    element: (
      <AuthGuard>
        <DashboardLayout>
          <Suspense fallback={<LoadingScreen />}>
            <Outlet />
          </Suspense>
        </DashboardLayout>
      </AuthGuard>
    ),
    children: [
      {
        element: (
          <PermissionsGuard roles={['logistics_partner']}>
            <CountryListPage />
          </PermissionsGuard>
        ),
        index: true,
      },
      {
        path: ':countryCode/:stateCode',
        element: (
          <PermissionsGuard roles={['logistics_partner']}>
            <EditCountryPage />
          </PermissionsGuard>
        ),
      },
    ],
  },
];
