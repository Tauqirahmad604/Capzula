import { lazy, Suspense } from 'react';
import { Outlet } from 'react-router-dom';

import { AuthGuard } from 'src/auth/guard';
import DashboardLayout from 'src/layouts/dashboard';
import PermissionsGuard from 'src/auth/guard/permissions-guard';
import PromotionTagsPage from 'src/pages/promotions/promotionTagsPage';
import { CreateProductDepsProvider } from 'src/context/create-product-deps';

import { LoadingScreen } from 'src/components/loading-screen';

import { ProductEditView, ProductListView } from 'src/sections/product-single/view';

const CreateBulkPage = lazy(() => import('src/pages/products/CreateBulk'));
const CreateBulkUpsertPage = lazy(() => import('src/pages/products/CreateBulkUpsert'));
const CreateSinglePage = lazy(() => import('src/pages/products/CreateSingle'));

export const productsRoutes = [
  {
    path: 'products',
    element: (
      <AuthGuard>
        <DashboardLayout sx={{ pb: 0, pl: 0, pr: 0 }}>
          <Suspense fallback={<LoadingScreen />}>
            <Outlet />
          </Suspense>
        </DashboardLayout>
      </AuthGuard>
    ),
    children: [
      {
        element: (
          <PermissionsGuard permission="manage_products_view" roles={['vendor', 'vendor_staff']}>
            <CreateProductDepsProvider>
              <ProductListView />
            </CreateProductDepsProvider>
          </PermissionsGuard>
        ),
        index: true,
      },

      {
        path: 'create-single',
        element: (
          <PermissionsGuard permission="manage_products_edit" roles={['vendor', 'vendor_staff']}>
            <CreateProductDepsProvider>
              <CreateSinglePage />
            </CreateProductDepsProvider>
          </PermissionsGuard>
        ),
      },
      {
        path: 'create-bulk',
        element: (
          <PermissionsGuard permission="manage_products_edit">
            <CreateBulkPage />
          </PermissionsGuard>
        ),
      },
      {
        path: 'create-bulk/new',
        element: (
          <PermissionsGuard permission="manage_products_edit">
            <CreateProductDepsProvider>
              <CreateBulkUpsertPage />
            </CreateProductDepsProvider>
          </PermissionsGuard>
        ),
      },
      {
        path: 'create-bulk/edit/:draftId',
        element: (
          <PermissionsGuard permission="manage_products_edit">
            <CreateProductDepsProvider>
              <CreateBulkUpsertPage />
            </CreateProductDepsProvider>
          </PermissionsGuard>
        ),
      },
      {
        path: 'edit-product/:productId',
        element: (
          <PermissionsGuard permission="manage_products_edit">
            <CreateProductDepsProvider>
              <ProductEditView />
            </CreateProductDepsProvider>
          </PermissionsGuard>
        ),
      },
      {
        path: 'promotion-tags',
        element: (
          <PermissionsGuard permission="manage_products_edit">
            <PromotionTagsPage />
          </PermissionsGuard>
        )
      }
    ],
  },
];
