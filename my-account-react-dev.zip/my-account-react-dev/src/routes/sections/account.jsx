import { lazy, Suspense } from 'react';
import { Outlet } from 'react-router-dom';

import { AuthGuard } from 'src/auth/guard';
import DashboardLayout from 'src/layouts/dashboard';
import AccountPage from 'src/pages/dashboard/account';
import CrispTicketIFrame from 'src/pages/ticket-iframe';
import { WP_SC_ACCOUNT_BASE_URL } from 'src/config-global';
import PermissionsGuard from 'src/auth/guard/permissions-guard';
import PromotionsPage from 'src/pages/promotions/promotionsPage';
import DeliveryAddressPage from 'src/pages/dashboard/deliveryAddresses';

import { LoadingScreen } from 'src/components/loading-screen';

import AccountStripeConnect from 'src/sections/account/account-stripe-connect';

const IFramePage = lazy(() => import('src/pages/iframe-page'));

export const accountRoutes = (currentLang) => [
  {
    path: 'account',
    element: (
      <AuthGuard>
        <DashboardLayout sx={{ pb: 0, pl: 0, pr: 0 }}>
          <Suspense fallback={<LoadingScreen />}>
            <Outlet />
          </Suspense>
        </DashboardLayout>
      </AuthGuard>
    ),
    children: [
      {
        path: 'tickets',
        element: (
          <PermissionsGuard roles={['vendor', 'customer', 'logistics_partner', 'payment_partner']}>
            <CrispTicketIFrame />
          </PermissionsGuard>
        ),
      },
      {
        path: 'tickets/new',
        element: (
          <PermissionsGuard roles={['vendor', 'customer', 'logistics_partner', 'payment_partner']}>
            <CrispTicketIFrame newTicket />
          </PermissionsGuard>
        ),
      },
      {
        // :template can only be refund or message
        path: 'tickets/new/:template',
        element: (
          <PermissionsGuard roles={['vendor', 'customer', 'logistics_partner', 'payment_partner']}>
            <CrispTicketIFrame newTicket />
          </PermissionsGuard>
        ),
      },

      {
        path: 'resync-products',
        element: (
          <PermissionsGuard roles={['admin']}>
            <IFramePage lang={currentLang} src={`${WP_SC_ACCOUNT_BASE_URL}/resync-products/`} />
          </PermissionsGuard>
        ),
      },
      {
        path: 'manage-store',
        element: (
          <PermissionsGuard permission="manage_store_edit" roles={['vendor', 'vendor_staff']}>
            <IFramePage
              requires2fa
              lang={currentLang}
              src={`${WP_SC_ACCOUNT_BASE_URL}/manage-store/`}
            />
          </PermissionsGuard>
        ),
      },
      {
        path: 'promotions',
        element: (
          <PermissionsGuard permission="manage_store_edit" roles={['vendor', 'vendor_staff']}>
            <PromotionsPage />
          </PermissionsGuard>
        ),
      },
      {
        path: 'manage-delivery-methods',
        element: (
          <PermissionsGuard permission="manage_store_edit" roles={['vendor', 'vendor_staff']}>
            <IFramePage
              lang={currentLang}
              src={`${WP_SC_ACCOUNT_BASE_URL}/manage-delivery-methods/`}
            />
          </PermissionsGuard>
        ),
      },
      {
        path: 'manage-pickup-options',
        element: (
          <PermissionsGuard permission="manage_store_edit" roles={['logistics_partner']}>
            <IFramePage
              lang={currentLang}
              src={`${WP_SC_ACCOUNT_BASE_URL}/manage-pickup-options/`}
            />
          </PermissionsGuard>
        ),
      },

      // {
      //   path: 'payment-methods',
      //   element: (
      //     <PermissionsGuard roles={['customer']}>
      //       <AccountPage />
      //     </PermissionsGuard>
      //   ),
      // },
      // {
      //   path: 'payment-methods/:action',
      //   element: (
      //     <PermissionsGuard roles={['customer']}>
      //       <AccountPage />
      //     </PermissionsGuard>
      //   ),
      // },
      // {
      //   path: 'payout-methods',
      //   element: (
      //     <PermissionsGuard roles={['vendor']}>
      //       <IFramePage lang={currentLang} src={`${WP_SC_ACCOUNT_BASE_URL}/payout-methods/`} />
      //     </PermissionsGuard>
      //   ),
      // },

      // {
      //   path: 'personal-details',
      //   element: (
      //     <PermissionsGuard roles={['vendor']}>
      //       <IFramePage lang={currentLang} src={`${WP_SC_ACCOUNT_BASE_URL}/personal-details/`} />
      //     </PermissionsGuard>
      //   ),
      // },

      // {
      //   path: 'account-details',
      //   element: (
      //     <PermissionsGuard roles={['vendor', 'customer', 'logistics_partner']}>
      //       <IFramePage lang={currentLang} src={`${WP_MY_ACCOUNT_BASE_URL}/edit-account/`} />
      //     </PermissionsGuard>
      //   ),
      // },
      {
        path: 'logistical-partners',
        element: (
          <PermissionsGuard roles={['customer']}>
            <IFramePage lang={currentLang} src={`${WP_SC_ACCOUNT_BASE_URL}/logistical-partners/`} />
          </PermissionsGuard>
        ),
      },
      // {
      //   path: 'billing-addresses',
      //   element: (
      //     <PermissionsGuard roles={['customer']}>
      //       <IFramePage lang={currentLang} src={`${WP_SC_ACCOUNT_BASE_URL}/billing-addresses/`} />
      //     </PermissionsGuard>
      //   ),
      // },
      {
        path: 'delivery-addresses',
        element: (
          <PermissionsGuard roles={['customer']}>
            <DeliveryAddressPage />
          </PermissionsGuard>
        ),
      },
      {
        path: 'stripe-connect',
        element: (
          <PermissionsGuard roles={['vendor']}>
            {/* <IFramePage
              baseUrl={WP_SC_ACCOUNT_BASE_URL}
              src={`${WP_MY_ACCOUNT_BASE_URL}/stripe-connect/`}
            /> */}
            <AccountStripeConnect />
          </PermissionsGuard>
        ),
      },
      {
        path: 'size-guides',
        element: (
          <PermissionsGuard roles={['vendor']}>
            <IFramePage lang={currentLang} src={`${WP_SC_ACCOUNT_BASE_URL}/size-guides/`} />
          </PermissionsGuard>
        ),
      },
      {
        path: 'manage',
        element: (
          <PermissionsGuard roles={['customer']}>
            <AccountPage />
          </PermissionsGuard>
        ),
      },
    ],
  },
];
