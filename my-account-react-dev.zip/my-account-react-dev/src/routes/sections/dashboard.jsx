import { lazy, Suspense } from 'react';
import { Outlet } from 'react-router-dom';

import { AuthGuard } from 'src/auth/guard';
import DashboardLayout from 'src/layouts/dashboard';
import PermissionsGuard from 'src/auth/guard/permissions-guard';

import { LoadingScreen } from 'src/components/loading-screen';

// ----------------------------------------------------------------------
const DashboardHome = lazy(() => import('src/pages/dashboard/Home'));

// ----------------------------------------------------------------------

export const dashboardRoutes = [
  {
    path: 'dashboard',
    element: (
      <AuthGuard>
        <PermissionsGuard>
          <DashboardLayout>
            <Suspense fallback={<LoadingScreen />}>
              <Outlet />
            </Suspense>
          </DashboardLayout>
        </PermissionsGuard>
      </AuthGuard>
    ),
    children: [{ element: <DashboardHome />, index: true }],
  },
];
