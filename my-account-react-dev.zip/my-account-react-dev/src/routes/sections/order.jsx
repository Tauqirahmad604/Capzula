import { lazy, Suspense } from 'react';
import { Outlet } from 'react-router-dom';

import { AuthGuard } from 'src/auth/guard';
import DashboardLayout from 'src/layouts/dashboard';
import PermissionsGuard from 'src/auth/guard/permissions-guard';

import { LoadingScreen } from 'src/components/loading-screen';

const OrderDetailsPage = lazy(() => import('src/pages/orders/OrderDetails'));

export const orderRoutes = [
  {
    path: 'order',
    element: (
      <AuthGuard>
        <DashboardLayout>
          <Suspense fallback={<LoadingScreen />}>
            <Outlet />
          </Suspense>
        </DashboardLayout>
      </AuthGuard>
    ),
    children: [
      {
        path: ':id',
        element: (
          <PermissionsGuard
            permission="manage_orders_edit"
            roles={['vendor', 'customer', 'vendor_staff', 'logistics_partner']}
          >
            <OrderDetailsPage />
          </PermissionsGuard>
        ),
      },
    ],
  },
];
