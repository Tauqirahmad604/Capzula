import { lazy, Suspense } from 'react';
import { Outlet } from 'react-router-dom';

import { AuthGuard } from 'src/auth/guard';
import { CheckoutProvider } from 'src/pages/checkout/context';
import PermissionsGuard from 'src/auth/guard/permissions-guard';

import { LoadingScreen } from 'src/components/loading-screen';

const CheckoutPage = lazy(() => import('src/pages/checkout/Checkout'));

export const checkoutRoutes = [
  {
    path: 'checkout',
    element: (
      <AuthGuard>
        {/* <DashboardLayout> */}
        <Suspense fallback={<LoadingScreen />}>
          <CheckoutProvider>
            <Outlet />
          </CheckoutProvider>
        </Suspense>
        {/* </DashboardLayout> */}
      </AuthGuard>
    ),
    children: [
      {
        element: (
          <PermissionsGuard roles={['customer']}>
            <CheckoutPage step="delivery_address" />
          </PermissionsGuard>
        ),
        index: true,
      },
      {
        path: 'international-shipping',
        element: (
          <PermissionsGuard roles={['customer']}>
            <CheckoutPage step="international_shipping" />
          </PermissionsGuard>
        ),
      },
      {
        path: 'national-delivery',
        element: (
          <PermissionsGuard roles={['customer']}>
            <CheckoutPage step="national_delivery" />
          </PermissionsGuard>
        ),
      },
      {
        path: 'payment-method',
        element: (
          <PermissionsGuard roles={['customer']}>
            <CheckoutPage step="payment_method" />
          </PermissionsGuard>
        ),
      },
    ],
  },
];
