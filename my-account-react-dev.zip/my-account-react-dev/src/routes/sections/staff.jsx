import { lazy, Suspense } from 'react';
import { Outlet } from 'react-router-dom';

import { AuthGuard } from 'src/auth/guard';
import DashboardLayout from 'src/layouts/dashboard';
import PermissionsGuard from 'src/auth/guard/permissions-guard';

import { LoadingScreen } from 'src/components/loading-screen';

const StaffListPage = lazy(() => import('src/pages/staff/StaffList'));

export const staffRouters = [
  {
    path: 'staff',
    element: (
      <AuthGuard>
        <DashboardLayout>
          <Suspense fallback={<LoadingScreen />}>
            <Outlet />
          </Suspense>
        </DashboardLayout>
      </AuthGuard>
    ),
    children: [
      {
        element: (
          <PermissionsGuard roles={['vendor']}>
            <StaffListPage />
          </PermissionsGuard>
        ),
        index: true,
      },
      {
        path: ':id',
        element: (
          <PermissionsGuard roles={['vendor']}>
            <StaffListPage />
          </PermissionsGuard>
        ),
      },
    ],
  },
];
