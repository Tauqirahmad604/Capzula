import { Suspense } from 'react';
import { Outlet } from 'react-router-dom';

import { AuthGuard } from 'src/auth/guard';
import AccountLockedPage from 'src/pages/423';
import Login2Fa from 'src/pages/auth/Login2Fa';
import PreLaunchPage from 'src/pages/pre-launch';
import VerifyEmail2Fa from 'src/pages/auth/VerifyEmail2Fa';

import { SplashScreen } from 'src/components/loading-screen';
// ----------------------------------------------------------------------

// JWT
// const JwtLoginPage = lazy(() => import('src/pages/auth/jwt/login'));

// ----------------------------------------------------------------------

const authJwt = [
  {
    path: 'auth',
    element: (
      <AuthGuard>
        <Suspense fallback={<SplashScreen />}>
          <Outlet />
        </Suspense>
      </AuthGuard>
    ),
    children: [
      {
        path: '2fa',
        element: <Login2Fa />,
      },
      {
        path: 'verify-email',
        element: <VerifyEmail2Fa />,
      },
      {
        path: 'locked',
        element: <AccountLockedPage />,
      },
      {
        path: 'pre-launch',
        element: <PreLaunchPage />,
      },
    ],
  },
];

export const authRoutes = authJwt;
