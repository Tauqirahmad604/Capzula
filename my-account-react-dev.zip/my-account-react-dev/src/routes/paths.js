
const ROOTS = {
  INDEX: '/',
  AUTH: '/auth',
  DASHBOARD: '/dashboard',
  CHATS: '/chats',
  ORDERS: '/orders',
  ORDER: '/order',
  FEED: '/feed',
  STORE: '/store',
  WISHLIST: '/wishlist',
  ACCOUNT: '/account',
  PRODUCTS: '/products',
  COMMISSIONS: '/commissions',
  MANAGE_TARIFFS: '/manage-tariffs',
  STAFF: '/staff',
  ACCESS_LOGS: '/access-logs',
  USERS: '/users',
  TRANSACTIONS: '/transactions',
  ACCOUNT_SETTINGS: '/account-settings',
  LOGISTIC_PARTNERS: '/logistic-partners',
  PAYMENT_METHODS: '/payment-methods',
  DELIVERY_ADDRESSES: '/delivery-addresses',
  REVIEWS: '/reviews',
};

export const paths = {
  error: {
    '404': '/404',
    '401': '/401',
  }, 
  
  dashboard: {
    root: ROOTS.DASHBOARD,
  },

  accessLogs: {
    root: ROOTS.ACCESS_LOGS,
  },
  users: {
    root: ROOTS.USERS,
  },
  auth: {
    jwt: {
      login: `${ROOTS.AUTH}/jwt/login`,
      register: `${ROOTS.AUTH}/jwt/register`,
    },
    twoFa: `${ROOTS.AUTH}/2fa`,
  },
  chats: {
    root: ROOTS.CHATS,
  },
  products: {
    root: ROOTS.PRODUCTS,
    createSingle: `${ROOTS.PRODUCTS}/create-single`,
    createBulk: `${ROOTS.PRODUCTS}/create-bulk`,
    createBulkEdit: (id) => `${ROOTS.PRODUCTS}/create-bulk/edit/${id}`,
    createBulkNew: `${ROOTS.PRODUCTS}/create-bulk/new`,
    edit: (id) => `${ROOTS.PRODUCTS}/edit-product/${id}`,
    promotionTags: `${ROOTS.PRODUCTS}/promotion-tags`,
  },
  feed: {
    root: ROOTS.FEED,
  },
  commissions: {
    root: ROOTS.COMMISSIONS,
  },
  staff: {
    root: ROOTS.STAFF,
  },
  manageTariffs: {
    root: ROOTS.MANAGE_TARIFFS,
  },
  wishlist: {
    root: ROOTS.WISHLIST,
  },
  orders: {
    root: `${ROOTS.ORDERS}`,
    edit: `${ROOTS.ORDER}`,
  },
  reviews:{
    root: `${ROOTS.REVIEWS}`,
  },
  accountSettings: {
    root: `${ROOTS.ACCOUNT_SETTINGS}`,
  },
  paymentMethods: {
    root: `${ROOTS.PAYMENT_METHODS}`,
  },
  logisticPartners: {
    root: `${ROOTS.LOGISTIC_PARTNERS}`,
  },

  

  account: {
    manageStore: `${ROOTS.ACCOUNT}/manage-store`,
    manageDeliveryMethods: `${ROOTS.ACCOUNT}/manage-delivery-methods`,
    productResync: `${ROOTS.ACCOUNT}/resync-products`,
    managePickUpOptions: `${ROOTS.ACCOUNT}/manage-pickup-options`,
    documents: `${ROOTS.ACCOUNT}/documents`,
    paymentMethods: `${ROOTS.ACCOUNT}/payment-methods`,
    payoutMethods: `${ROOTS.ACCOUNT}/payout-methods`,
    billingAddresses: `${ROOTS.ACCOUNT}/billing-addresses`,
    stripeConnect: `${ROOTS.ACCOUNT}/stripe-connect`,
    businessDetails: `${ROOTS.ACCOUNT}/business-details`,
    wishlist: `${ROOTS.ACCOUNT}/wishlist`,
    accountDetails: `${ROOTS.ACCOUNT}/account-details`,
    sizeGuides: `${ROOTS.ACCOUNT}/size-guides`,
    logisticalPartners: `${ROOTS.ACCOUNT}/logistical-partners`,
    support: {
      root: `${ROOTS.ACCOUNT}/tickets`,
      new: `${ROOTS.ACCOUNT}/tickets/new`,
    }
  },
  promotions: {
    root: `${ROOTS.ACCOUNT}/promotions`,
  },
  transactions:{
    root: `${ROOTS.TRANSACTIONS}`
  },
  deliveryAddresses:{
    root: `${ROOTS.DELIVERY_ADDRESSES}`
  }
};
