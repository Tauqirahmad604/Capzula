import { m } from 'framer-motion';
import PropTypes from 'prop-types';
import { Crisp } from 'crisp-sdk-web';

import Box from '@mui/material/Box';
import Stack from '@mui/material/Stack';
import Paper from '@mui/material/Paper';
import Avatar from '@mui/material/Avatar';
import Divider from '@mui/material/Divider';
import { alpha } from '@mui/material/styles';
import MenuItem from '@mui/material/MenuItem';
import IconButton from '@mui/material/IconButton';
import Typography from '@mui/material/Typography';
import ListItemIcon from '@mui/material/ListItemIcon';

import { paths } from 'src/routes/paths';
import { useRouter } from 'src/routes/hooks';

import { trl } from 'src/locales/i18n';
import { useAuthContext } from 'src/auth/hooks';
import { PARENT_HOST_URL } from 'src/config-global';

// import { useMockedUser } from 'src/hooks/use-mocked-user';
import Iconify from 'src/components/iconify';
import { varHover } from 'src/components/animate';
import CustomPopover, { usePopover } from 'src/components/custom-popover';

// ----------------------------------------------------------------------

// ----------------------------------------------------------------------

export default function AccountPopover({ stopEmulatingUser, isEmulating }) {
  const router = useRouter();

  const { user, logout } = useAuthContext();

  const popover = usePopover();

  const handleLogout = async () => {
    try {
      Crisp.setTokenId();
      Crisp.session.reset();

      if (isEmulating && stopEmulatingUser) {
        return stopEmulatingUser();
      }

      return logout();
    } catch (error) {
      console.error(error);
    }
    return null;
  };

  const handleClickItem = (path, blank = false) => {
    popover.onClose();

    if (blank) {
      return window.open(path);
    }
    return router.push(path);
  };

  return (
    <>
      <Paper
        xs={{
          p: 1,
          // ':hover': {
          //   boxShadow: 0, // theme.shadows[20]
          // },
        }}
        style={{ cursor: 'pointer' }}
        // elevation={1}
        onClick={popover.onOpen}
      >
        <Box sx={{ display: 'flex', alignItems: 'center', padding: 1 }}>
          <IconButton
            component={m.button}
            whileTap="tap"
            whileHover="hover"
            variants={varHover(1.05)}
            sx={{
              width: 40,
              height: 40,
              background: (theme) => alpha(theme.palette.grey[500], 0.08),
              ...(popover.open && {
                background: (theme) =>
                  `linear-gradient(135deg, ${theme.palette.primary.light} 0%, ${theme.palette.primary.main} 100%)`,
              }),
            }}
          >
            <Avatar
              src={user?.profile_photo}
              alt={user?.display_name}
              sx={{
                width: 36,
                height: 36,
                border: (theme) => `solid 2px ${theme.palette.background.default}`,
              }}
            >
              {user?.first_name?.toUpperCase()}
            </Avatar>
          </IconButton>

          <Box sx={{ lineHeight: 0.2, ml: 0.5 }}>
            {/* <Typography variant="subtitle2" sx={{ lineHeight: 0.8 }}>
              {user?.role === 'vendor' || (user?.role === 'vendor_staff' && user?.vendor_name)}
              {user?.role === 'customer' && user?.display_name}
              {user?.role === 'logistics_partner' && user?.display_name}
            </Typography> */}
            {/* {user?.role !== 'customer' && ( */}
            <Typography variant="subtitle2" sx={{ fontWeight: '600', lineHeight: 1.25 }}>
              {user?.business_details?.business_name}
            </Typography>
            {/* )} */}
            <Typography sx={{ fontSize: 10 }}>Customer No: {user?.cpz_id}</Typography>
          </Box>
        </Box>
      </Paper>

      <CustomPopover open={popover.open} onClose={popover.onClose} sx={{ width: 200, p: 0 }}>
        <Box sx={{ p: 0.5, pb: 1.5 }}>
          {/* <LanguagePopover /> */}

          <Stack sx={{ p: 1 }}>
            {user?.role !== 'customer' && user?.role !== 'logistics_partner' ? (
              <>
                <MenuItem onClick={() => handleClickItem(user.store_url, 'blank')}>
                  {trl('Navbar.view_store')}
                  <ListItemIcon sx={{ pl: 1 }}>
                    <Iconify width={16} icon="radix-icons:open-in-new-window" />
                  </ListItemIcon>
                </MenuItem>
                <MenuItem onClick={() => handleClickItem(paths.account.manageStore)}>
                  {trl('Global.manage_store')}
                </MenuItem>
              </>
            ) : (
              user?.role === 'customer' && (
                <MenuItem onClick={() => window.open(PARENT_HOST_URL)}>
                  {trl('Navbar.shop_now')}
                  <ListItemIcon sx={{ pl: 1 }}>
                    <Iconify width={16} icon="radix-icons:open-in-new-window" />
                  </ListItemIcon>
                </MenuItem>
              )
            )}
            <MenuItem onClick={() => handleClickItem(paths.accountSettings.root)}>
              {trl('Navbar.account_setting')}
            </MenuItem>
          </Stack>

          <Divider sx={{ borderStyle: 'dashed' }} />

          <MenuItem
            onClick={handleLogout}
            sx={{ m: 1, fontWeight: 'fontWeightBold', color: 'error.main' }}
          >
            {trl('Navbar.logout')}
          </MenuItem>
        </Box>
      </CustomPopover>
    </>
  );
}

AccountPopover.propTypes = {
  stopEmulatingUser: PropTypes.func,
  isEmulating: PropTypes.bool,
};
