import { useMemo } from 'react';

import { paths } from 'src/routes/paths';

import { trl } from 'src/locales/i18n';
import { useAuthContext } from 'src/auth/hooks';

export function useNavData() {
  const { user } = useAuthContext();

  // eslint-disable-next-line react-hooks/exhaustive-deps
  const filterItemsBasedOnPermissions = (items) => {
    if (!user) {
      return [];
    }

    const { permissions: fetchedUserPermissions } = user;

    if (!fetchedUserPermissions) {
      return items;
    }
    const userPermissions = Object.keys(fetchedUserPermissions)?.filter(
      (key) => fetchedUserPermissions[key]
    );

    const filteredItems = items
      .map((item) => {
        const { items: subItems, permissions, children, ...rest } = item;

        if (permissions && !userPermissions?.includes(permissions)) {
          return null;
        }

        if (subItems) {
          const filteredSubItems = filterItemsBasedOnPermissions(subItems, userPermissions);
          if (filteredSubItems.length === 0) {
            return null;
          }

          return { items: filteredSubItems, ...rest };
        }

        if (children) {
          const filteredChildren = children
            .map((child) => {
              const { permissions: childPermissions, ...childRest } = child;

              if (childPermissions && !userPermissions?.includes(childPermissions)) {
                return null;
              }

              return { ...childRest };
            })
            .filter(Boolean);

          if (filteredChildren.length === 0) {
            return null;
          }

          return { children: filteredChildren, ...rest };
        }

        return { ...rest };
      })
      .filter(Boolean);

    return filteredItems;
  };

  const data = useMemo(() => {
    if (!user) {
      return [];
    }

    const adminNav = [
      {
        items: [
          {
            title: 'Product Resync',
            path: paths.account.productResync,
            icon: 'solar:refresh-square-bold-duotone',
          },
        ],
      },
    ];
    const vendorNav = [
      {
        items: [
          {
            title: trl('Global.dashboard'),
            path: paths.dashboard.root,
            icon: 'solar:spedometer-max-bold-duotone',
          },
          {
            title: trl('Global.messages'),
            path: paths.chats.root,
            icon: 'solar:chat-line-bold-duotone',
            permissions: 'manage_chats_edit',
          },
        ],
      },
      {
        subheader: trl('Sidebar.your_store'),
        items: [
          {
            title: trl('Global.orders'),
            chip: user?.notifications?.order_count,
            path: paths.orders.root,
            icon: 'solar:checklist-minimalistic-bold-duotone',
            permissions: 'manage_orders_view',
          },
          {
            title: trl('Global.reviews'),
            path: paths.reviews.root,
            icon: 'solar:checklist-minimalistic-bold-duotone',
          },
          {
            title: trl('Global.products'),
            path: [
              paths.products.root,
              paths.products.createSingle,
              paths.products.createBulk,
              paths.account.sizeGuides,
            ],
            icon: 'solar:widget-bold-duotone',
            permission: 'manage_products_view',
            children: [
              {
                title: trl('Sidebar.view_products'),
                path: paths.products.root,
                permissions: 'manage_products_view',
              },
              {
                title: trl('Sidebar.create_a_product'),
                path: paths.products.createSingle,
                permissions: 'manage_products_edit',
              },
              {
                title: trl('Sidebar.createProductsBulk'),
                path: paths.products.createBulk,
                permissions: 'manage_products_edit',
              },
              {
                title: trl('Sidebar.size_guides'),
                path: paths.account.sizeGuides,
                permissions: 'manage_products_edit',
              },
              {
                title: "Promotion Tags",
                path: paths.products.promotionTags,
                permissions: 'manage_products_edit',
              },
            ],
          },

          {
            title: 'Promotions',
            path: [paths.promotions.root, paths.products.createSingle],
            icon: 'solar:widget-bold-duotone',
            permissions: 'manage_promos_view',
            children: [
              {
                title: 'View Promotions',
                path: paths.promotions.root,
                permissions: 'manage_promos_view',
              },
              {
                title: 'Create A Promotion',
                path: paths.products.createSingle,
                permissions: 'manage_promos_edit',
              },
            ],
          },
          {
            title: trl('Sidebar.my_store'),
            chip: '1',
            path: [paths.account.manageStore, paths.account.manageDeliveryMethods],
            icon: 'solar:shop-bold-duotone',
            permissions: 'manage_store_edit',
            children: [
              {
                title: trl('Global.manage_store'),
                path: paths.account.manageStore,
                permissions: 'manage_store_edit',
              },
              {
                title: trl('Sidebar.delivery_methods'),
                path: paths.account.manageDeliveryMethods,
                permissions: 'manage_products_edit',
              },
            ],
          },
        ],
      },

      // MANAGEMENT
      // ----------------------------------------------------------------------
      {
        subheader: trl('Sidebar.my_account'),
        items: [
          {
            title: trl('Global.staff_accounts'),
            path: paths.staff.root,
            icon: 'solar:users-group-rounded-bold-duotone',
            permissions: 'manage_staff_edit',
          },
          {
            title: 'Support Tickets',
            path: paths.account.support.root,
            icon: 'solar:users-group-rounded-bold-duotone',
          },
        ],
      },

      {
        subheader: trl('Global.payments'),
        items: [
          {
            title: trl('Global.payouts'),
            path: paths.commissions.root,
            icon: 'solar:document-add-bold-duotone',
            permissions: 'manage_commissions_view',
          },
          {
            title: trl('Sidebar.bank_details'),
            path: paths.account.payoutMethods,
            icon: 'solar:document-add-bold-duotone',
            permissions: 'manage_payout_edit',
          },
          {
            title: trl('Sidebar.stripe_connect'),
            path: paths.account.stripeConnect,
            icon: 'solar:card-2-bold-duotone',
            permissions: 'manage_stripe_connect_edit',
          },
          {
            title: 'Transactions',
            path: paths.transactions.root,
            icon: 'solar:document-add-bold-duotone',
          },
        ],
      },

      {
        subheader: 'Other',
        items: [
          {
            title: 'Access Logs',
            path: paths.accessLogs.root,
            icon: 'solar:delivery-bold-duotone',
            permissions: 'can_view_access_logs',
          },
        ],
      },
    ];

    const buyerNav = [
      {
        items: [
          {
            title: 'Dashboard',
            path: paths.dashboard.root,
            icon: 'solar:spedometer-max-bold-duotone',
          },
          {
            title: trl('Global.messages'),
            path: paths.chats.root,
            icon: 'solar:chat-line-bold-duotone',
          },
          {
            title: trl('Global.orders'),
            path: paths.orders.root,
            icon: 'solar:checklist-minimalistic-bold-duotone',
          },
          {
            title: trl('Global.reviews'),
            path: paths.reviews.root,
            icon: 'solar:checklist-minimalistic-bold-duotone',
          },
          {
            chip: user?.account_status?.document_upload_outstanding ? '1' : null,
            title: trl('Sidebar.logistic_partners'),
            path: paths.account.logisticalPartners,
            icon: 'solar:delivery-bold-duotone',
          },

          {
            // chip: user?.account_status?.document_upload_outstanding ? '1' : null,
            title: trl('Sidebar.logistic_partners'),
            path: paths.logisticPartners.root,
            icon: 'solar:delivery-bold-duotone',
          },

          {
            // chip: user?.account_status?.business_details_outstanding ? '1' : null,
            title: trl('Global.delivery_addresses'),
            path: paths.deliveryAddresses.root,
            icon: 'solar:map-point-wave-bold-duotone',
          },

          {
            chip:
              user?.account_status?.cards_outstanding || user?.account_status?.card_declines
                ? '1'
                : null,
            title: trl('Global.payment_methods'),
            path: paths.paymentMethods.root,
            icon: 'solar:card-2-bold-duotone',
          },

          // {
          //   chip: user?.account_status?.billing_address_outstanding ? '1' : null,
          //   title: trl('Global.billing_addresses'),
          //   path: paths.account.billingAddresses,
          //   icon: 'fa6-solid:address-book',
          // },
        ],
      },
    ];

    const logisticsParnerNav = [
      {
        items: [
          {
            title: 'Dashboard',
            path: paths.dashboard.root,
            icon: 'solar:spedometer-max-bold-duotone',
          },
          {
            title: trl('Global.messages'),
            path: paths.chats.root,
            icon: 'solar:chat-line-bold-duotone',
          },
          {
            title: trl('Global.orders'),
            path: paths.orders.root,
            icon: 'solar:checklist-minimalistic-bold-duotone',
          },

          {
            // chip: user?.account_status?.business_details_outstanding ? '1' : null,
            title: trl('Global.pick_up_options'),
            path: paths.account.managePickUpOptions,
            icon: 'solar:inbox-in-bold-duotone',
          },
          {
            title: 'Manage Tariffs',
            path: paths.manageTariffs.root,
            icon: 'solar:delivery-bold-duotone',
          },
        ],
      },
      {
        subheader: 'Other',
        items: [
          {
            title: 'Access Logs',
            path: paths.accessLogs.root,
            icon: 'solar:delivery-bold-duotone',
            permissions: 'can_view_access_logs',
          },
        ],
      },
    ];

    const superUserNav = [
      {
        items: [
          {
            title: 'Users',
            path: paths.users.root,
            icon: 'solar:delivery-bold-duotone',
          },
        ],
      },
    ];

    const paymentProviderNav = [
      {
        items: [
          {
            title: trl('Global.payouts'),
            path: paths.commissions.root,
            icon: 'solar:document-add-bold-duotone',
            permissions: 'manage_commissions_view',
          },
          {
            title: 'Transactions',
            path: paths.transactions.root,
            icon: 'solar:document-add-bold-duotone',
          },
        ],
      },
    ];

    const navs = {
      logistics_partner: logisticsParnerNav,
      customer: buyerNav,
      vendor: vendorNav,
      vendor_staff: vendorNav,
      capzula_staff: superUserNav,
      payment_partner: paymentProviderNav,
    };
    // eslint-disable-next-line no-nested-ternary
    return user.role === 'admin'
      ? [
          {
            subheader: 'ADMIN === ',
            items: [],
          },
          ...adminNav,
          {
            subheader: 'VENDOR === ',
            items: [],
          },
          ...vendorNav,
          {
            subheader: 'BUYER === ',
            items: [],
          },
          ...buyerNav,
          {
            subheader: 'LOGISTICS PARTNER === ',
            items: [],
          },
          ...logisticsParnerNav,
          {
            subheader: 'SUPER USER === ',
            items: [],
          },
          ...superUserNav,
          {
            subheader: 'PAYMENT PROVIDER === ',
            items: [],
          },
          ...paymentProviderNav,
        ]
      : filterItemsBasedOnPermissions(navs[user.role]);
  }, [filterItemsBasedOnPermissions, user]);

  return data;
}
