import { createContext } from 'react';

// ----------------------------------------------------------------------

export const CreateProductDepsContext = createContext({});
