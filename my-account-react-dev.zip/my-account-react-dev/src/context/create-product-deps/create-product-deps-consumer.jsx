import PropTypes from 'prop-types';

import { SplashScreen } from 'src/components/loading-screen';

import { CreateProductDepsContext } from './create-product-deps-context';

// ----------------------------------------------------------------------

export function CreateProductDepsConsumer({ children }) {
  return (
    <CreateProductDepsContext.Consumer>
      {(auth) => (auth.loading ? <SplashScreen /> : children)}
    </CreateProductDepsContext.Consumer>
  );
}

CreateProductDepsConsumer.propTypes = {
  children: PropTypes.node,
};
