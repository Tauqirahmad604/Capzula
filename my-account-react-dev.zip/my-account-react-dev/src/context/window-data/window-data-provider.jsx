import { useMemo } from 'react';
import PropTypes from 'prop-types';

import { useGetWindowDataQuery } from 'src/redux/api/myAccount';

import { WindowDataContext } from './window-data-context';

export function WindowDataProvider({ children }) {
  const { data, isLoading } = useGetWindowDataQuery();
  const memoizedValue = useMemo(() => ({ ...data?.data, loading: isLoading }), [data, isLoading]);
  return <WindowDataContext.Provider value={memoizedValue}>{children}</WindowDataContext.Provider>;
}

WindowDataProvider.propTypes = {
  children: PropTypes.node,
};
