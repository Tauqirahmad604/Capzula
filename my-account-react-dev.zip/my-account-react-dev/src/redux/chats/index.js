import { createSlice } from '@reduxjs/toolkit';

export const defaultState = {
  chats: [],
  participants: {},
  activeConversation: null,
};

export const conversationsSlice = createSlice({
  name: 'conversations',
  initialState: defaultState,
  reducers: {
    setConversations: (state, action) => {
      const { conversations } = action.payload;

      state.chats = conversations;
    },
    addHistoricalMessages: (state, action) => {
      const { messages, conversationId } = action.payload;

      state.chats = state.chats.map((chat) => {
        if (chat.id === conversationId) {
          return {
            ...chat,
            messages: [...messages, ...chat.messages],
          };
        }

        return chat;
      });
    },
    addNewMessage: (state, action) => {
      const { message, conversationId, isOwnMessage } = action.payload;
      const isNewConversation = !state.chats.find((chat) => chat.id === conversationId);

      if (isNewConversation) {
        state.chats = [
          ...state.chats,
          {
            id: conversationId,
            messages: [message],
            totalMessages: 1,
            unreadCount: isOwnMessage ? 0 : 1,
            participants: [message.senderId, message.receiverId],
            type: 'ONE_TO_ONE',
          },
        ];
        return;
      }

      state.chats = state.chats.map((chat) => {
        if (chat.id === conversationId) {
          const alreadyExists = chat.messages.find((msg) => msg.id === message.id);

          if (alreadyExists) return chat;

          return {
            ...chat,
            unreadCount: isOwnMessage ? 0 : 1,
            messages: [...chat.messages, message],
            totalMessages: chat.totalMessages + 1,
          };
        }

        return chat;
      });
    },
    setMessageTranslation: (state, action) => {
      const { conversationId, messageId, translation } = action.payload;

      state.chats = state.chats.map((chat) => {
        if (chat.id === conversationId) {
          return {
            ...chat,
            messages: chat.messages.map((msg) => {
              if (msg.id === messageId) {
                return {
                  ...msg,
                  translatedBody: translation,
                };
              }

              return msg;
            }),
          };
        }

        return chat;
      });
    },
    setUnreadCount: (state, action) => {
      const { conversationId, unreadCount } = action.payload;

      state.chats = state.chats.map((chat) => {
        if (chat.id === conversationId) {
          return {
            ...chat,
            unreadCount,
          };
        }

        return chat;
      });
    },
    incrementUnreadCount: (state, action) => {
      const { conversationId } = action.payload;

      state.chats = state.chats.map((chat) => {
        if (chat.id === conversationId) {
          return {
            ...chat,
            unreadCount: chat.unreadCount + 1,
          };
        }

        return chat;
      });
    },
    resetUnreadCount: (state, action) => {
      const { conversationId } = action.payload;

      state.chats = state.chats.map((chat) => {
        if (chat.id === conversationId) {
          return {
            ...chat,
            unreadCount: 0,
          };
        }

        return chat;
      });
    },
    setParticipants: (state, action) => {
      const { participants } = action.payload;

      state.participants = {
        ...state.participants,
        ...participants,
      };
    },
  },
});

// Action creators are generated for each case reducer function
export const {
  setConversations,
  setParticipants,
  addNewMessage,
  setMessageTranslation,
  setUnreadCount,
  incrementUnreadCount,
  resetUnreadCount,
  addHistoricalMessages,
} = conversationsSlice.actions;

export const selectConversations = (state) => state.conversations.chats;
export const selectParticipants = (state) => state.conversations.participants;

export default conversationsSlice.reducer;
