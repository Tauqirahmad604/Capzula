import axios from 'axios';
import Cookies from 'js-cookie';
import { of, take, filter, switchMap, combineLatest } from 'rxjs';

import { endpoints } from 'src/utils/axios';

import { HOST_API } from 'src/config-global';
import { isValidToken } from 'src/auth/context/jwt/utils';
import {
  pauseRequests$,
  enableTwoFactor,
  refreshingToken$,
  twoFactorSubject,
  stopTokenRefresh,
  reRequestSubject,
  updateAccessToken,
  startTokenRefresh,
  setTwoFactorOnLoad,
  twoFactorCancelSubject,
} from 'src/lib/observables';

const instance = axios.create({
  baseURL: HOST_API,
  withCredentials: true,
});

export const refreshTokenCall = async () => {
  const tokenIsRefreshing = refreshingToken$.value;
  if (tokenIsRefreshing) {
    return null;
  }

  startTokenRefresh();
  // document.cookie = 'cpz_session_token=; expires=Thu, 01 Jan 1970 00:00:00 UTC';
  const refreshToken = Cookies.get('cpz_refresh_token');
  const response = await axios.get(`${HOST_API}v1${endpoints.auth.refresh}`, {
    headers: {
      Authorization: `Bearer ${refreshToken}`,
    },
    withCredentials: true,
  });
  const accessToken = response.data.data.token;

  Cookies.set('cpz_session_token', accessToken);

  updateAccessToken(accessToken);

  stopTokenRefresh();

  return accessToken;
};

instance.interceptors.request.use(async (config) => {
  const token = Cookies.get('cpz_session_token');

  if (token && isValidToken(token)) {
    config.headers.Authorization = `Bearer ${token}`;
  } else {
    await refreshTokenCall();
  }

  return config;
});

instance.interceptors.response.use(
  (response) =>  response,
  async (error) => {
    const {config, response: { status, data } } = error;
    const originalRequest = config;
    const unAuthorized = status === 401;
    const isForbidden = status === 403;
    const isLocked = status === 423;
    const tokenExpired = status === 498;
    const isPreLaunch = status === 405;
    
    const twoFaActive = data?.data?.active;
    const twoFaBlocked = data?.data?.blocked_for_secs;
    const twoFaRequired = data?.data?.requires_renewal;

    const blacklistedUrls = [
      '/auth/2fa',
    ];

    const whiteListedUrls = [
      '/auth/2fa/summary',
      '/auth/2fa/verify_email',
    ];


    if (tokenExpired) {
      // Handle refresh token
      return new Promise((resolve, reject) => {
        refreshingToken$
          .pipe(
            filter((refreshingToken) => !refreshingToken),
            take(1)
          )
          .subscribe((refreshingToken) => {
            if (!refreshingToken) {
              refreshTokenCall().then((token) => {
                originalRequest.headers.Authorization = `Bearer ${token}`;
                resolve(instance(originalRequest));
              });
            }
          });
      });
    }

    if (
      blacklistedUrls.some(url => originalRequest.url.includes(url)) &&
      !whiteListedUrls.some(url => originalRequest.url.includes(url))
    ) {
      return Promise.reject(error);
    };

    if (isLocked) {
      return window.location.replace('/auth/locked');
    }

    if (isPreLaunch) {
      return window.location.replace('/auth/pre-launch');
    }

    if (unAuthorized) {
      // Handle 2FA
      if(!twoFaActive && twoFaRequired) {
        const isTwoFactorActive = twoFactorSubject.value;

        if (!isTwoFactorActive) {
          enableTwoFactor();
        }
        setTwoFactorOnLoad({
          ...data.data,
          request_method: originalRequest.method,
        });

        return new Promise((resolve, reject) => {
          combineLatest([twoFactorSubject, twoFactorCancelSubject]).pipe(
            switchMap(([active, canceled]) => {
              if (canceled) {
                return of({ action: 'cancel' , active: false })
              }
              return of({ action: 'continue', active });
            }),
            filter(({active}) => !active),
            take(1)
          ).subscribe(({action}) => {
            if(action === 'cancel') {
              return reject(error);
            }
            return resolve(instance(originalRequest));
          });
        });
        // if(data?.data?.['2fa-blocked']) {
        // }
      }


    }

    if (isForbidden && twoFaBlocked) {
      // if (data?.data?.['tfa_type'] == 'session') {
      //   return
      // }

      const isTwoFactorActive = twoFactorSubject.value;

      if (!isTwoFactorActive) {
        enableTwoFactor();
      }

      setTwoFactorOnLoad({
        ...data.data,
        request_method: originalRequest.method,
      });

      return new Promise((resolve, reject) => {
        reRequestSubject
          .pipe(take(1))
          .subscribe(() => resolve(instance(originalRequest)));
      });
    }

    return Promise.reject(error);
  }
);

export const makeAxiosCallFrom = (request) => new Promise((resolve, reject) => {
    pauseRequests$
      .pipe(
        filter((paused) => !paused),
        take(1)
      )
      .subscribe(() => resolve(instance(request)));
  })

export const makeAxiosCall = async ({ url, method, data, params, headers, baseUrl, formData = false }) =>
  new Promise((resolve, reject) => { // @TODO: handle error here, if unauthorized redirect to login
    pauseRequests$
      .pipe(
        filter((paused) => !paused),
        take(1)
      )
    .subscribe(() => {
      const token = Cookies.get('cpz_session_token');
        resolve(
          instance({
            url: baseUrl + url,
            method,
            data,
            params,
            headers: {
              ...headers,
              Authorization: `Bearer ${token}`,
            },
            formData
          })
        );
    });
  });

export const axiosBaseQuery =
  ({ baseUrl }) =>
  async ({ url, method, data, params, headers, formData = false}) => {
    try {
      const cpz_session_token = Cookies.get('cpz_session_token');

      if (!isValidToken(cpz_session_token)) {
        await refreshTokenCall();
      }

      const result = await makeAxiosCall({
        url,
        method,
        data,
        params,
        headers,
        baseUrl,
        formData,
      });
      return { data: result.data };
    } catch (err) {
      return {
        error: {
          status: err.response?.status,
          data: err.response?.data || err.message,
        },
      };
    }
  };
