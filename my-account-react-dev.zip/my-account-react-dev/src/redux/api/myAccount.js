// src/api/accountApi.js
import { createApi } from '@reduxjs/toolkit/query/react';

import { HOST_API } from 'src/config-global';

import { axiosBaseQuery } from './baseQuery';

export const accountApi = createApi({
  reducerPath: 'accountApi',
  tagTypes: [
    'GetOrders',
    'GetProducts',
    'GetStaff',
    'GetOrder',
    'GetUsers',
    'GetPaymentMethod',
    'GetPaymentMethods',
    'Getcommissions',
    'GetStripeConnect',
    'GetPromotions',
    'GetPromotionTags',
    'GetReviews',
    'ServiceRates',
    'TariffCountryList',
    'AccountSettings',
    'GetTransactions',
    'GetCalculatedCommissionAmount',
    'LogisticPartnersSummary',
    'PrepInternationalShipping',
    'GetDeliveryAddresses',
    'PrepCheckout',
  ],
  baseQuery: axiosBaseQuery({
    baseUrl: `${HOST_API}v1/`,
  }),
  endpoints: (builder) => ({
    getWindowData: builder.query({
      query: () => ({ url: `window-data` }),
    }),

    getProductDeps: builder.query({
      query: () => ({ url: `product-deps` }),
    }),

    getChatUsers: builder.mutation({
      query: (params) => ({ url: `chats/users`, params }),
    }),

    getFavVendors: builder.query({
      query: ({ pageNum, status }) => {
        const query = new URLSearchParams();
        query.set('page', pageNum);
        query.set('status', status);
        return { url: `fav-vendors/?${query.toString()}` };
      },
    }),

    getProducts: builder.query({
      query: ({ pageNum, limit }) => {
        const query = new URLSearchParams();
        query.set('page', pageNum);
        query.set('limit', limit);
        return { url: `products/?${query.toString()}` };
      },
      providesTags: ['GetProducts'],
    }),

    getProductDetail: builder.query({
      query: ({ idProduct }) => ({ url: `product/${idProduct}` }),
      providesTags: ['GetProductDetail'],
    }),

    getNotifications: builder.query({
      query: () => ({ url: `user/notifications` }),
    }),

    getImportantNotifications: builder.query({
      query: () => ({ url: `user/important-notifications` }),
    }),

    updateProduct: builder.mutation({
      query: ({ id, body }) => {
        const url = `product/${id}`;
        return {
          method: 'PUT',
          data: body,
          url,
        };
      },
      invalidatesTags: ['GetProductDetail', 'GetProducts'],
    }),

    createProduct: builder.mutation({
      query: ({ body }) => {
        const url = `product`;
        return {
          method: 'POST',
          data: body,
          url,
        };
      },
      invalidatesTags: ['GetProducts'],
    }),

    deleteProduct: builder.mutation({
      query: ({ id }) => {
        const url = `product/${id}`;
        return {
          method: 'DELETE',
          url,
        };
      },
      invalidatesTags: ['GetProducts'],
    }),
    deleteProducts: builder.mutation({
      query: ({ productIds }) => {
        const url = `products`;
        return {
          method: 'DELETE',
          data: { productIds },
          url,
        };
      },
      invalidatesTags: ['GetProducts'],
    }),
    getOrders: builder.query({
      query: ({ pageNum, status }) => ({ url: `orders/?page=${pageNum}&status=${status}` }),
      providesTags: ['GetOrders'],
    }),

    getOrdersByToken: builder.query({
      query: ({ id, status }) => {
        const query = new URLSearchParams();
        query.set('status', status);

        return { url: `orders/token/${id}?${query.toString()}` };
      },
      providesTags: ['GetOrders'],
    }),

    getOrderM: builder.mutation({
      query: (id) => ({ url: `order/${id}` }),
    }),

    getcommissions: builder.query({
      query: ({ pageNum, status, priority, search, orderby, order }) => {
        const query = new URLSearchParams();
        query.set('page', pageNum);
        query.set('status', status);
        query.set('priority', priority);
        query.set('search', search);
        query.set('orderby', orderby);
        query.set('order', order);
        return { url: `commissions/?${query.toString()}` };
      },
      providesTags: ['Getcommissions'],
    }),

    getStaff: builder.query({
      query: ({ pageNum, status }) => ({ url: `staff/` }),
      providesTags: ['GetStaff'],
    }),

    getOrder: builder.query({
      query: (id) => ({ url: `order/${id}` }),
      providesTags: ['GetOrder'],
    }),

    getPaymentMethod: builder.query({
      query: (id) => ({ url: `user/payment-method/${id}` }),
      providesTags: ['GetPaymentMethod'],
    }),
    getPaymentMethods: builder.query({
      query: () => ({ url: `user/payment-methods` }),
      providesTags: ['GetPaymentMethods'],
    }),
    getWooCountriesAndStates: builder.query({
      query: () => ({ url: `wc-countries-and-states` }),
    }),
    generateStripeAccountLink: builder.query({
      query: () => ({ url: `stripe/create-account-link` }),
      providesTags: ['GetStripeConnect'],
    }),
    getPromotions: builder.query({
      query: () => ({ url: `promotions` }),
      providesTags: ['GetPromotions'],
    }),
    getPromotionTags: builder.query({
      query: () => ({ url: `promotion-tags` }),
      providesTags: ['GetPromotionTags'],
    }),
    getCalculatedCommissionAmount: builder.query({
      query: ({ ids, status }) => ({ url: `commissions/calculate-amount?ids=${ids}&status=${status}` }),
      providesTags: ['GetCalculatedCommissionAmount'],
    }),
    getTransactions: builder.query({
      query: ({ pageNum, transactionType }) => ({ url: `transactions/?page=${pageNum}&transaction_type=${transactionType}` }),
      providesTags: ['GetTransactions'],
    }),
    getReviews: builder.query({
      query: ({ type, pageNum }) => ({ url: `reviews?type=${type}` }),
      providesTags: ['GetReviews'],
    }),
    updateOrder: builder.mutation({
      query: ({ id, body }) => {
        const url = `order/${id}/update`;
        // console.log(url);
        return {
          method: 'PUT',
          data: body,
          url,
        };
      },
      invalidatesTags: ['GetOrder'],
    }),
    removeItems: builder.mutation({
      query: ({ id, body }) => {
        const url = `order/${id}/delete-items`;
        // console.log(url);
        return {
          method: 'DELETE',
          data: body,
          url,
        };
      },
      invalidatesTags: ['GetOrder', 'GetOrders'],
    }),

    updateStaff: builder.mutation({
      query: ({ id, body }) => {
        const url = `staff/${id}`;
        return {
          method: 'PUT',
          data: body,
          url,
        };
      },
      invalidatesTags: ['GetStaff'],
    }),

    createStaff: builder.mutation({
      query: ({ body }) => {
        const url = `staff`;
        return {
          method: 'POST',
          data: body,
          url,
        };
      },
      invalidatesTags: ['GetStaff'],
    }),

    deleteStaff: builder.mutation({
      query: ({ id }) => {
        const url = `staff/${id}`;
        return {
          method: 'DELETE',
          url,
        };
      },
      invalidatesTags: ['GetStaff'],
    }),
    resetStaffPassword: builder.mutation({
      query: ({ id }) => {
        const url = `staff/${id}/reset-password`;
        return {
          method: 'PUT',
          url,
        };
      },
      invalidatesTags: ['GetStaff'],
    }),
    acceptOrder: builder.mutation({
      query: ({ id, targetDate }) => {
        const url = `order/${id}/accept`;
        return {
          method: 'PUT',
          data: {
            targetDate
          },
          url,
        };
      },
      invalidatesTags: ['GetOrder'],
    }),
    chargeOrder: builder.mutation({
      query: ({ id }) => {
        const url = `order/${id}/charge`;
        return {
          method: 'PUT',
          url,
        };
      },
      invalidatesTags: ['GetOrder', 'GetOrders', 'Getcommissions'],
    }),
    chargeOrderDelivery: builder.mutation({
      query: ({ id }) => {
        const url = `order/${id}/charge-delivery`;
        return {
          method: 'PUT',
          url,
        };
      },
      invalidatesTags: ['GetOrder', 'GetOrders', 'Getcommissions'],
    }),
    splitOrder: builder.mutation({
      query: ({ id, body }) => {
        const url = `order/${id}/split`;
        return {
          method: 'PUT',
          data: body,
          url,
        };
      },
      invalidatesTags: ['GetOrder', 'GetOrders'],
    }),
    changeOrderStatus: builder.mutation({
      query: ({ id, body }) => {
        const url = `order/${id}/status`;
        return {
          method: 'PUT',
          data: body,
          url,
        };
      },
      invalidatesTags: ['GetOrder', 'GetOrders'],
    }),
    addOrderNote: builder.mutation({
      query: ({ id, body }) => {
        const url = `order/${id}/note`;
        return {
          method: 'PUT',
          data: body,
          url,
        };
      },
      invalidatesTags: ['GetOrder'],
    }),
    addDelivery: builder.mutation({
      query: ({ id, body }) => {
        const url = `order/${id}/delivery`;
        return {
          method: 'PUT',
          data: body,
          url,
        };
      },
      invalidatesTags: ['GetOrder', 'GetOrders'],
    }),
    cancelOrder: builder.mutation({
      query: ({ id, body }) => {
        const url = `order/${id}/cancel`;
        return {
          method: 'PUT',
          data: body,
          url,
        };
      },
      invalidatesTags: ['GetOrder', 'GetOrders'],
    }),
    changeCard: builder.mutation({
      query: ({ id, body }) => {
        const url = `order/${id}/card/change`;
        return {
          method: 'PUT',
          data: body,
          url,
        };
      },
      invalidatesTags: ['GetOrder'],
    }),
    changeCardMultiple: builder.mutation({
      query: ({ body }) => {
        const url = `orders/card/change`;
        return {
          method: 'PUT',
          data: body,
          url,
        };
      },
      invalidatesTags: ['GetOrder', 'GetOrders'],
    }),
    resolveCard: builder.mutation({
      query: (id) => {
        const url = `order/${id}/card/resolve`;
        return {
          method: 'PUT',
          url,
        };
      },
      invalidatesTags: ['GetOrder', 'GetOrders'],
    }),
    addPaymentMethod: builder.mutation({
      query: ({ body }) => {
        const url = `user/payment-method/add`;
        return {
          method: 'POST',
          data: body,
          url,
        };
      },
      invalidatesTags: ['GetPaymentMethods'],
    }),
    createStripeIntent: builder.mutation({
      query: () => {
        const url = `user/payment-method/create-intent`;
        return {
          method: 'POST',
          url,
        };
      },
    }),
    enablePaymentMethod: builder.mutation({
      query: (id) => {
        const url = `user/payment-method/${id}/enable`;
        return {
          method: 'PUT',
          url,
        };
      },
      invalidatesTags: ['GetPaymentMethods'],
    }),
    setDefaultPaymentMethod: builder.mutation({
      query: (id) => {
        const url = `user/payment-method/${id}/default`;
        return {
          method: 'PUT',
          url,
        };
      },
      invalidatesTags: ['GetPaymentMethods'],
    }),
    updatePaymentMethod: builder.mutation({
      query: ({ id, body }) => {
        const url = `user/payment-method/${id}/update`;
        return {
          method: 'PUT',
          data: body,
          url,
        };
      },
      invalidatesTags: ['GetPaymentMethod', 'GetPaymentMethods'],
    }),
    getDeliveryServices: builder.query({
      query: (id) => ({ url: `delivery-services` }),
    }),
    addDeliveryAddress: builder.mutation({
      query: ({ body }) => {
        const url = `user/add-delivery-address`;
        return {
          method: 'PUT',
          data: body,
          url,
        };
      },
      invalidatesTags: ['GetDeliveryAddresses']
    }),
    updateDeliveryAddress: builder.mutation({
      query: ({ body }) => {
        const url = `user/update-delivery-address`;
        return {
          method: 'PUT',
          data: body,
          url,
        };
      },
    }),
    deleteDeliveryAddress: builder.mutation({
      query: ({ body }) => {
        const url = `user/delete-delivery-address`;
        return {
          method: 'DELETE',
          data: body,
          url,
        };
      },
    }),
    getDeliveryAddresses: builder.query({
      query: () => {
        const url = `user/delivery-addresses`;
        return {
          method: 'GET',
          url,
        };
      },
      providesTags: ['GetDeliveryAddresses'],
    }),
    deletePaymentMethod: builder.mutation({
      query: (id) => {
        const url = `user/payment-method/${id}`;
        return {
          method: 'DELETE',
          url,
        };
      },
      invalidatesTags: ['GetPaymentMethods'],
    }),
    addCommissionNote: builder.mutation({
      query: ({ id, body }) => {
        const url = `commissions/${id}/add-note`;
        return {
          method: 'POST',
          data: body,
          url,
        };
      },
      invalidatesTags: ['Getcommissions'],
    }),
    processCommission: builder.mutation({
      query: ({ id }) => {
        const url = `commissions/${id}/transfer`;
        return {
          method: 'POST',
          url,
        };
      },
      invalidatesTags: ['Getcommissions'],
    }),
    refundCommission: builder.mutation({
      query: ({ id }) => {
        const url = `commissions/${id}/refund`;
        return {
          method: 'POST',
          url,
        };
      },
      invalidatesTags: ['Getcommissions'],
    }),
    changeCommissionStatus: builder.mutation({
      query: ({ body }) => {
        const url = `commissions/bulk-change`;
        return {
          method: 'PUT',
          data: body,
          url,
        };
      },
      invalidatesTags: ['Getcommissions', 'GetTransactions', 'GetCalculatedCommissionAmount'],
    }),
    disconnectStripe: builder.mutation({
      query: () => {
        const url = `stripe/disconnect`;
        return {
          method: 'PUT',
          url,
        };
      },
      invalidatesTags: ['GetStripeConnect'],
    }),
    addPromo: builder.mutation({
      query: ({ body }) => {
        const url = `promotions/add`;
        return {
          method: 'POST',
          data: body,
          url,
        };
      },
      invalidatesTags: ['GetPromotions'],
    }),
    activatePromo: builder.mutation({
      query: ({ id }) => {
        const url = `promotions/${id}/activate`;
        return {
          method: 'PUT',
          url,
        };
      },
      invalidatesTags: ['GetPromotions'],
    }),
    deletePromo: builder.mutation({
      query: ({ id }) => {
        const url = `promotions/${id}`;
        return {
          method: 'DELETE',
          url,
        };
      },
      invalidatesTags: ['GetPromotions'],
    }),
    refundOrder: builder.mutation({
      query: ({ id, body }) => {
        const url = `order/${id}/refund`;
        return {
          method: 'PUT',
          data: body,
          url,
        };
      },
      invalidatesTags: ['GetOrder', 'GetOrders'],
    }),
    getTariffCountries: builder.query({
      query: (id) => ({ url: `tariffs/countries` }),
      providesTags: ['TariffCountryList'],
    }),
    getTariffStateServices: builder.query({
      query: (body) => {
        const url = `tariffs/services`;
        return {
          method: 'POST',
          data: body,
          url,
        };
      },
      providesTags: ['ServiceRates'],
    }),
    postTariffService: builder.mutation({
      query: (body) => {
        const url = `tariffs/service`;
        return {
          method: 'POST',
          data: body,
          url,
        };
      },
      invalidatesTags: ['ServiceRates', 'TariffCountryList'],
    }),

    updateTariffService: builder.mutation({
      query: (body) => {
        const url = `tariffs/service`;
        return {
          method: 'PUT',
          data: body,
          url,
        };
      },
      invalidatesTags: ['ServiceRates'],
    }),
    postTariffServiceRate: builder.mutation({
      query: (body) => {
        const url = `tariffs/rates`;
        return {
          method: 'POST',
          data: body,
          url,
        };
      },
      invalidatesTags: ['ServiceRates'],
    }),
    updateTariffServiceRate: builder.mutation({
      query: (body) => {
        const url = `tariffs/rates`;
        return {
          method: 'PUT',
          data: body,
          url,
        };
      },
      invalidatesTags: ['ServiceRates'],
    }),
    deleteTariffServiceRate: builder.mutation({
      query: (body) => {
        const url = `tariffs/rates`;
        return {
          method: 'DELETE',
          data: body,
          url,
        };
      },
      invalidatesTags: ['ServiceRates'],
    }),
    deleteTariffService: builder.mutation({
      query: (body) => {
        const url = `tariffs/service`;
        return {
          method: 'DELETE',
          data: body,
          url,
        };
      },
      invalidatesTags: ['ServiceRates', 'TariffCountryList'],
    }),

    stopEmulatingUser: builder.mutation({
      query: (body) => {
        const url = `auth/su/stop`;
        return {
          method: 'GET',
          url,
        };
      },
    }),
    startEmulatingUser: builder.mutation({
      query: (body) => {
        const url = `auth/su/start`;
        return {
          method: 'POST',
          data: body,
          url,
        };
      },
    }),
    getAccessLogs: builder.query({
      query: ({ pageNum }) => ({
        url: `access-logs/${pageNum || ''}`,
      }),
    }),
    getUsers: builder.query({
      query: (body) => ({
        url: `users`,
        method: 'POST',
        data: body,
      }),
      providesTags: ['GetUsers'],
    }),

    deleteUser: builder.mutation({
      query: (body) => ({
        url: `users`,
        method: 'DELETE',
        data: body,
      }),
      invalidatesTags: ['GetUsers'],
    }),


    resetPassword: builder.mutation({
      query: (body) => ({
        url: `users/reset-password`,
        method: 'PUT',
        data: body,
      }),
      invalidatesTags: ['GetUsers'],
    }),

    toggleLockAccount: builder.mutation({
      query: (body) => ({
        url: `users/toggle-lock`,
        method: 'PUT',
        data: body,
      }),
      invalidatesTags: ['GetUsers'],
    }),

    verifyDocs: builder.mutation({
      query: (body) => ({
        url: `users/verify-docs`,
        method: 'PUT',
        data: body,
      }),
      invalidatesTags: ['GetUsers'],
    }),

    getUserRoles: builder.query({
      query: () => ({
        url: `users/roles`,
        method: 'GET',
      }),
    }),

    get2FaSummary: builder.mutation({
      query: (data) => ({
        url: `auth/2fa/summary/${data.type}`,
        method: 'GET',
      }),
    }),

    post2FaCode: builder.mutation({
      query: (body) => ({
        url: `auth/2fa`,
        method: 'POST',
        data: body,
      }),
    }),

    renew2faCode: builder.mutation({
      query: (body) => {
        const url = `auth/2fa-renew`;
        return {
          method: 'POST',
          url,
          data: body
        };
      }
    }),

    putAccountSettings: builder.mutation({
      query: (body) => ({
        url: `account/settings`,
        method: 'PUT',
        data: body,
      }),
      invalidatesTags: ['AccountSettings'],
    }),

    putAccountBusinessDetails: builder.mutation({
      query: (body) => ({
        url: `account/business-details`,
        method: 'PUT',
        data: body,
      }),
      // invalidatesTags: ['AccountSettings'],
    }),

    putChangeEmail: builder.mutation({
      query: (body) => ({
        url: `account/change-email`,
        method: 'PUT',
        data: body,
      }),
      // invalidatesTags: ['AccountSettings'],
    }),

    resendVerificationEmail: builder.mutation({
      query: (body) => ({
        url: `account/resend-verification-email`,
        method: 'GET',
      }),
    }),

    getAccountSettings: builder.query({
      query: () => ({
        url: `account/settings`,
        method: 'GET',
      }),
      providesTags: ['AccountSettings'],
    }),

    toggleAccount2Fa: builder.mutation({
      query: () => ({
        url: `account/toggle-2fa`,
        method: 'PUT',
      }),
      invalidatesTags: ['AccountSettings'],
    }),

    uploadProfilePhoto: builder.mutation({
      query: (body) => ({
        url: `account/profile-photo`,
        method: 'PUT',
        data: body,
      }),
      invalidatesTags: ['AccountSettings'],
    }),

    uploadDocument: builder.mutation({
      query: (body) => ({
        url: `account/business-document`,
        method: 'PUT',
        data: body,
      }),
      invalidatesTags: ['AccountSettings'],
    }),

    getLogisticPartnersSummary: builder.query({
      query: () => ({
        url: `logistic-partners/summary`,
        method: 'GET',
      }),
      providesTags: ['LogisticPartnersSummary'],
    }),

    removeLogisticCompany: builder.mutation({
      query: (body) => ({
        url: `logistic-partners/remove`,
        method: 'DELETE',
        data: body,
      }),
      invalidatesTags: ['LogisticPartnersSummary', 'PrepInternationalShipping'],
    }),

    addLogisticCompany: builder.mutation({
      query: (body) => ({
        url: `logistic-partners/add`,
        method: 'POST',
        data: body,
      }),
      invalidatesTags: ['LogisticPartnersSummary', 'PrepInternationalShipping'],
    }),


    postPrepInternationalShipping: builder.query({
      query: (body) => ({
        url: `checkout/prep-international-shipping`,
        method: 'POST',
        data: body,
      }),
      invalidatesTags: ['LogisticPartnersSummary'],
      providesTags: ['PrepInternationalShipping'],
    }),



    postPrepNationalDelivery: builder.query({
      query: (body) => ({
        url: `checkout/prep-national-delivery`,
        method: 'POST',
        data: body,
      }),
      // invalidatesTags: ['LogisticPartnersSummary'],
      // providesTags: ['PrepInternationalShipping'],
    }),



    postPrepInternationalShippingM: builder.mutation({
      query: (body) => ({
        url: `checkout/prep-international-shipping`,
        method: 'POST',
        data: body,
      }),
      invalidatesTags: ['LogisticPartnersSummary'],
      providesTags: ['PrepInternationalShipping'],
    }),


    postFinalCheckout: builder.mutation({
      query: (body) => ({
        url: `checkout/final`,
        method: 'POST',
        data: body,
      }),
      // invalidatesTags: ['PrepCheckout'],
    }),


    prepCheckout: builder.mutation({
      query: (body) => ({
        url: `checkout/prep`,
        method: 'GET',
      }),
      provideTags: ['PrepCheckout'],
    }),

    setPlatformFee: builder.mutation({
      query: (body) => ({
        url: `user/set-platform-fees`,
        method: 'PUT',
        data: body,
      }),
    }),

    addPromoTag: builder.mutation({
      query: (body) => ({
        url: `promotion-tags/add`,
        method: 'POST',
        data: body,
      }),
      invalidatesTags: ['GetPromotionTags'],
    }),

    addReview: builder.mutation({
      query: (body) => ({
        url: `reviews/add`,
        method: 'POST',
        data: body,
      }),
      invalidatesTags: ['GetReviews'], 
    }),


    // uploadProfilePhoto: builder.mutation({
    //   async queryFn(file, { rejectWithValue }) {
    //     const formData = new FormData();
    //     formData.append('profilePhoto', file);

    //     try {
    //       const response = await fetch('account/profile-photo', {
    //         method: 'PUT',
    //         body: formData,
    //       });

    //       if (!response.ok) {
    //         return rejectWithValue(await response.json());
    //       }

    //       return response.json(); // handle successful upload response
    //     } catch (error) {
    //       return rejectWithValue(error);
    //     }
    //   },
    // }),

  }),
});

export const {
  useGetOrdersQuery,
  useGetOrderQuery,
  useGetOrdersByTokenQuery,
  useGetPaymentMethodQuery,
  useGetPaymentMethodsQuery,
  useGetFavVendorsQuery,
  useGetProductsQuery,
  useGetWooCountriesAndStatesQuery,
  useGetImportantNotificationsQuery,
  useGetNotificationsQuery,
  useUpdateOrderMutation,
  useAcceptOrderMutation,
  useGetWindowDataQuery,
  useChargeOrderMutation,
  useChargeOrderDeliveryMutation,
  useGetProductDepsQuery,
  useSplitOrderMutation,
  useGetcommissionsQuery,
  useGetPromotionsQuery,
  useGetPromotionTagsQuery,
  useGetReviewsQuery,
  useGetCalculatedCommissionAmountQuery,
  useGetTransactionsQuery,
  useUpdateStaffMutation,
  useGetStaffQuery,
  useGetProductDetailQuery,
  useUpdateProductMutation,
  useCreateProductMutation,
  useDeleteProductMutation,
  useDeleteProductsMutation,
  useCreateStaffMutation,
  useDeleteStaffMutation,
  useResetStaffPasswordMutation,
  useGetChatUsersMutation,
  useRemoveItemsMutation,
  useAddDeliveryMutation,
  useCancelOrderMutation,
  useChangeCardMutation,
  useChangeCardMultipleMutation,
  useResolveCardMutation,
  useGetOrderMMutation,
  useAddPaymentMethodMutation,
  useCreateStripeIntentMutation,
  useEnablePaymentMethodMutation,
  useSetDefaultPaymentMethodMutation,
  useUpdatePaymentMethodMutation,
  useGetDeliveryServicesQuery,
  useAddDeliveryAddressMutation,
  useGetDeliveryAddressesQuery,
  useUpdateDeliveryAddressMutation,
  useDeleteDeliveryAddressMutation,
  useDeletePaymentMethodMutation,
  useChangeOrderStatusMutation,
  useAddOrderNoteMutation,
  useGenerateStripeAccountLinkQuery,
  useAddCommissionNoteMutation,
  useProcessCommissionMutation,
  useRefundCommissionMutation,
  useChangeCommissionStatusMutation,
  useDisconnectStripeMutation,
  useAddPromoMutation,
  useActivatePromoMutation,
  useDeletePromoMutation,
  useRefundOrderMutation,
  useGetTariffCountriesQuery,
  useGetTariffStateServicesQuery,
  usePostTariffServiceRateMutation,
  usePostTariffServiceMutation,
  useDeleteTariffServiceRateMutation,
  useDeleteTariffServiceMutation,
  useUpdateTariffServiceRateMutation,
  useUpdateTariffServiceMutation,
  useStopEmulatingUserMutation,
  useStartEmulatingUserMutation,
  useGetAccessLogsQuery,
  useGetUsersQuery,
  useGetUserRolesQuery,
  useDeleteUserMutation,
  usePost2FaCodeMutation,
  useRenew2faCodeMutation,
  usePutAccountSettingsMutation,
  usePutAccountBusinessDetailsMutation,
  usePutChangeEmailMutation,
  useGetAccountSettingsQuery,
  useResendVerificationEmailMutation,
  useVerifyDocsMutation,
  useGet2FaSummaryMutation,
  useResetPasswordMutation,
  useToggleLockAccountMutation,
  useToggleAccount2FaMutation,
  useUploadProfilePhotoMutation,
  useUploadDocumentMutation,
  useGetLogisticPartnersSummaryQuery,
  useRemoveLogisticCompanyMutation,
  useAddLogisticCompanyMutation,
  usePostPrepInternationalShippingQuery,
  usePostPrepInternationalShippingMMutation,
  usePostFinalCheckoutMutation,
  usePrepCheckoutMutation,
  usePostPrepNationalDeliveryQuery,
  useSetPlatformFeeMutation,
  useAddPromoTagMutation,
  useAddReviewMutation,
} = accountApi;
