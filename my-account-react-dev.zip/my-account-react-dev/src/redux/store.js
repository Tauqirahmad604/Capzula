// src/redux/store.js
import { configureStore } from '@reduxjs/toolkit';

import chatsReducer from './chats';
import { accountApi } from './api/myAccount';

const store = configureStore({
  reducer: {
    [accountApi.reducerPath]: accountApi.reducer,
    conversations: chatsReducer,
  },
  middleware: (getDefaultMiddleware) => getDefaultMiddleware().concat(accountApi.middleware),
});

export default store;
