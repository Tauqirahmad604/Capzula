import PropTypes from 'prop-types';

import { useAuthContext } from 'src/auth/hooks';

import { NotFoundView } from 'src/sections/error';

export default function PermissionsGuard({ permission, children, roles }) {
  const { user } = useAuthContext();

  if (user.role !== 'admin') {
    if (user.permissions && permission && user.role === 'vendor_staff') {
      if (!user.permissions[permission]) {
        return <NotFoundView />;
      }
    }

    if (user.role && roles) {
      if (!roles.includes(user.role)) {
        return <NotFoundView />;
      }
    }
  }
  return children;
}

PermissionsGuard.propTypes = {
  children: PropTypes.node,
  permission: PropTypes.string,
  roles: PropTypes.array,
};
