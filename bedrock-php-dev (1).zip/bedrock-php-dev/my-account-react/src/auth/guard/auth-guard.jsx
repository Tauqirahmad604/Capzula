import PropTypes from 'prop-types';
import { Navigate } from 'react-router-dom';
import { useState, useEffect, useCallback } from 'react';

import { paths } from 'src/routes/paths';
import { useRouter } from 'src/routes/hooks';

import { SplashScreen } from 'src/components/loading-screen';

import { useAuthContext } from '../hooks';

// ----------------------------------------------------------------------

const loginPaths = {
  jwt: paths.auth.jwt.login,
};

// ----------------------------------------------------------------------

export default function AuthGuard({ children }) {
  const { loading } = useAuthContext();

  return <>{loading ? <SplashScreen /> : <Container> {children}</Container>}</>;
}

AuthGuard.propTypes = {
  children: PropTypes.node,
};

// ----------------------------------------------------------------------

function Container({ children }) {
  const router = useRouter();

  const { user, authenticated, method } = useAuthContext();
  const [checkedAuthenticated, setCheckedAuthenticated] = useState(false);
  const check = useCallback(() => {
    if (!authenticated) {
      const searchParams = new URLSearchParams({
        returnTo: window.location.pathname,
      }).toString();

      const loginPath = loginPaths[method];

      const href = `${loginPath}?${searchParams}`;

      router.replace(href);
    } else {
      setCheckedAuthenticated(true);
    }
  }, [authenticated, method, router]);

  useEffect(() => {
    check();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  if (!checkedAuthenticated) {
    return null;
  }

  if (
    !user?.setup_progress.business_details_complete &&
    user?.role !== 'admin' &&
    !user?.is_emulating
  ) {
    return <Navigate to="/wizard/business-details" />;
  }

  if (!user?.docs?.prev_approved && user?.role !== 'admin' && !user?.is_emulating) {
    return <Navigate to="/wizard/documents" />;
  }

  return <>{children}</>;
}

Container.propTypes = {
  children: PropTypes.node,
};
