import PropTypes from 'prop-types';

import { SplashScreen } from 'src/components/loading-screen';

import { WindowDataContext } from './window-data-context';

// ----------------------------------------------------------------------

export function WindowData({ children }) {
  return (
    <WindowDataContext.Consumer>
      {(auth) => (auth.loading ? <SplashScreen /> : children)}
    </WindowDataContext.Consumer>
  );
}

WindowData.propTypes = {
  children: PropTypes.node,
};
