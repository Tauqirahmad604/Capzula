import { useContext } from 'react';

import { CreateProductDepsContext } from './create-product-deps-context';

// ----------------------------------------------------------------------

export const useCreateProductDepsContext = () => {
  const context = useContext(CreateProductDepsContext);

  if (!context)
    throw new Error(
      'CreateProductDepsContext context must be use inside CreateProductDepsProvider'
    );

  return context;
};
