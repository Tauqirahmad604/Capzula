import PropTypes from 'prop-types';
import { useMemo, useEffect } from 'react';

import { useGetProductDepsQuery } from 'src/redux/api/myAccount';

import { CreateProductDepsContext } from './create-product-deps-context';

export function CreateProductDepsProvider({ children }) {
  const { data, isLoading, isError, error } = useGetProductDepsQuery();
  useEffect(() => {
    if (isError) {
      console.error(error);
    }
  }, [isError, error]);

  const memoizedValue = useMemo(
    () => ({ ...(data?.data || {}), loading: isLoading }),
    [data, isLoading]
  );
  return (
    <CreateProductDepsContext.Provider value={memoizedValue}>
      {children}
    </CreateProductDepsContext.Provider>
  );
}

CreateProductDepsProvider.propTypes = {
  children: PropTypes.node,
};
