/* eslint-disable perfectionist/sort-imports */
import { ErrorBoundary } from 'react-error-boundary';
import 'src/global.css';

// ----------------------------------------------------------------------

import Router from 'src/routes/sections';

import ThemeProvider from 'src/theme';

import { useScrollToTop } from 'src/hooks/use-scroll-to-top';

import ProgressBar from 'src/components/progress-bar';
import { MotionLazy } from 'src/components/animate/motion-lazy';
import { SettingsDrawer, SettingsProvider } from 'src/components/settings';

import { AuthProvider } from 'src/auth/context/jwt';

import { LocalizationProvider } from 'src/locales';
import { SupabaseProvider } from 'src/supabase/context';
import { SnackbarProvider } from 'src/components/snackbar';

import { useEffect } from 'react';
import { Crisp } from 'crisp-sdk-web';
import { CRISP_WEBSITE_ID } from 'src/config-global';
import { ChatProvider } from './sections/chat/context/chat-provider';
import { View500 } from './sections/error';

import TwoFaModule from './sections/TwoFaModule/TwoFaModule';
import { useAuthContext } from './auth/hooks';

// ----------------------------------------------------------------------

const CrispChat = () => {
  const { user } = useAuthContext();
  useEffect(() => {
    if (user) {
      // if (user.is_emulating || user.role === 'admin') {
      //   Crisp.setTokenId();
      //   Crisp.session.reset();
      // } else {
      Crisp.configure(CRISP_WEBSITE_ID, {
        autoload: true,
      });
      Crisp.user.setEmail(user?.email, user?.crisp_chat_token);
      Crisp.user.setNickname(user?.full_name);
      Crisp.setTokenId(user?.id);
      Crisp.chat.close();
      // }
    }
  }, [user]);

  return '';
};

export default function App() {
  useScrollToTop();

  return (
    <ErrorBoundary
      FallbackComponent={View500}
      onError={(error, componentStack) => {
        console.error(error, componentStack);
      }}
    >
      <AuthProvider>
        <CrispChat />
        <SupabaseProvider>
          <ChatProvider>
            <LocalizationProvider>
              <SettingsProvider
                defaultSettings={{
                  themeMode: 'light', // 'light' | 'dark'
                  themeDirection: 'ltr', //  'rtl' | 'ltr'
                  themeContrast: 'default', // 'default' | 'bold'
                  themeLayout: 'vertical', // 'vertical' | 'horizontal' | 'mini'
                  themeColorPresets: 'default', // 'default' | 'cyan' | 'purple' | 'blue' | 'orange' | 'red'
                  themeStretch: false,
                }}
              >
                <ThemeProvider>
                  <SnackbarProvider>
                    <MotionLazy>
                      <SettingsDrawer />
                      <ProgressBar />
                      <Router />
                      <TwoFaModule />
                    </MotionLazy>
                  </SnackbarProvider>
                </ThemeProvider>
              </SettingsProvider>
            </LocalizationProvider>
          </ChatProvider>
        </SupabaseProvider>
      </AuthProvider>
    </ErrorBoundary>
  );
}
