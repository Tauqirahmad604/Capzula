import PropTypes from 'prop-types';

import { Box, Stack } from '@mui/system';
import { Paper, Checkbox, Typography } from '@mui/material';

export default function AddressCard({
  address,
  selectedAddressId,
  onClick = false,
  hideCheckbox = false,
}) {
  // const { data, isLoading: getDeliveryAddressIsLoading, refetch } = useGetDeliveryAddressesQuery();

  // const selectedAddressFn = useCallback(() => {
  //   if (addressId && data?.data) {
  //     return data.data.find((address) => address.id === addressId);
  //   }
  // }, [addressId, data]);

  // const selectedAddress = selectedAddressFn();
  const selectedAddress = address;
  const selected = selectedAddressId === address?.id;
  return (
    <Stack
      key={selectedAddress?.id}
      onClick={() => {
        if (onClick) {
          onClick();
        }
      }}
      spacing={1}
      component={Paper}
      variant="outlined"
      sx={{
        cursor: 'pointer',
        p: 2.5,
        mb: 2,
        width: 1,
        position: 'relative',
        border: selected ? '1px solid #8cb952' : '',
        backgroundColor: selected ? '#fbfff6' : '',
      }}
    >
      <Stack direction="row" justifyContent="space-between" sx={{ marginTop: 'auto' }}>
        <Box>
          <Typography variant="subtitle2">{address?.company}</Typography>
          <Typography variant="body2">{`${address?.address_1} ${address?.city}`}</Typography>
        </Box>
        {!hideCheckbox && (
          <Typography variant="subtitle2">
            <Checkbox edge="end" checked={selected} />
          </Typography>
        )}
      </Stack>
    </Stack>
  );
}

AddressCard.propTypes = {
  address: PropTypes.object,
  selectedAddressId: PropTypes.number,
  onClick: PropTypes.func,
  hideCheckbox: PropTypes.bool,
};
