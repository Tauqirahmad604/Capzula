/* eslint-disable react/prop-types */
import React, { useState } from 'react';
import { Navigate } from 'react-router';

import { Box } from '@mui/system';
import { Card, Grid, Alert, Button, Tooltip, Typography, CardContent } from '@mui/material';
import {
  Timeline,
  TimelineDot,
  TimelineItem,
  TimelineContent,
  TimelineSeparator,
  TimelineConnector,
  TimelineOppositeContent,
  timelineOppositeContentClasses,
} from '@mui/lab';

import { useRouter } from 'src/routes/hooks';

import LogisticPartnerRow from 'src/pages/logistic-partners/LogisticPartnerRow';
import { usePostPrepInternationalShippingQuery } from 'src/redux/api/myAccount';
import EditLogisticPartnersDialog from 'src/pages/logistic-partners/EditLogisticPartnersDialog';

import Iconify from 'src/components/iconify';
import { LoadingScreen } from 'src/components/loading-screen';

import { useCheckoutContext } from '../../context/use-checkout-context';

export function InternationalShippingContent({
  intShippingData,
  setChangeLogisticsPartner,
  showingInSummary = false,
}) {
  const sellersToString = (sellers) => {
    const sellerList = Object.keys(sellers).map((seller) => sellers[seller].name);
    return sellerList.join(', ');
  };
  return (
    <>
      {intShippingData &&
        Object.keys(intShippingData?.recommended_partners).map((country_code) => (
          <>
            {Object.keys(intShippingData?.recommended_partners[country_code]).map((state_code) => (
              <Card key={country_code} sx={{ mb: 3 }}>
                <CardContent>
                  <Grid container spacing={2}>
                    <Grid xs={12} sm={6} lg={6}>
                      <Timeline
                        sx={{
                          [`
                          min-width: 450px;
                          & .${timelineOppositeContentClasses.root}`]: {
                            flex: 0.2,
                          },
                        }}
                      >
                        <TimelineItem sx={{ opacity: 0.5 }}>
                          <TimelineOppositeContent color="textSecondary">
                            <Typography variant="body2" fontSize={12}>
                              Delivery From
                            </Typography>
                          </TimelineOppositeContent>
                          <TimelineSeparator>
                            <TimelineDot color="grey" />
                            <TimelineConnector
                            // sx={{
                            //   bgcolor: 'primary.main',
                            // }}
                            />
                          </TimelineSeparator>

                          <TimelineContent>
                            <Box sx={{ display: 'flex', alignItems: 'center' }} gap={3}>
                              <Box
                                gap={3}
                                sx={{
                                  display: 'flex',
                                  alignItems: 'center',
                                  // opacity: vendorList[countryCodeKey][vendorSlug]
                                  //   .delivering_to_logistic_company
                                  //   ? 0.4
                                  //   : 1,
                                }}
                              >
                                <Box sx={{ display: 'flex', alignItems: 'center' }}>
                                  {/* <Avatar
                                    src={deliveryAddressDetails.profile_photo}
                                    sx={{ width: 40, height: 40, mr: 2 }}
                                  /> */}
                                  <Box>
                                    <Typography fontWeight={500} variant="body2">
                                      {console.log(intShippingData, '<< intShippingData')}
                                      {
                                        Object.keys(
                                          intShippingData?.sellers[`${country_code}_${state_code}`]
                                        )?.length
                                      }{' '}
                                      Seller
                                      {Object.keys(
                                        intShippingData?.sellers[`${country_code}_${state_code}`]
                                      )?.length > 1
                                        ? 's'
                                        : ''}
                                      <Tooltip
                                        title={sellersToString(
                                          intShippingData?.sellers[`${country_code}_${state_code}`]
                                        )}
                                      >
                                        <Iconify
                                          sx={{ ml: 0.5 }}
                                          height={15}
                                          width={15}
                                          icon="ic:round-info"
                                        />
                                      </Tooltip>
                                    </Typography>
                                    <Typography variant="body2" fontSize={12}>
                                      {
                                        intShippingData?.recommended_partners[country_code][
                                          state_code
                                        ].state_name
                                      }
                                      ,{' '}
                                      {
                                        intShippingData?.recommended_partners[country_code][
                                          state_code
                                        ].country_name
                                      }{' '}
                                    </Typography>
                                  </Box>
                                </Box>
                              </Box>
                            </Box>
                          </TimelineContent>
                        </TimelineItem>

                        <TimelineItem>
                          <TimelineOppositeContent color="textSecondary">
                            <Typography variant="body2" fontSize={12}>
                              Logistics Partner
                            </Typography>
                          </TimelineOppositeContent>
                          <TimelineSeparator>
                            <TimelineDot color="primary" />
                            <TimelineConnector
                              sx={{
                                bgcolor: 'primary.main',
                              }}
                            />
                          </TimelineSeparator>

                          <TimelineContent>
                            <Box sx={{ display: 'flex', alignItems: 'center' }} gap={3}>
                              <Box
                                gap={3}
                                sx={{
                                  display: 'flex',
                                  alignItems: 'center',
                                  // opacity: vendorList[countryCodeKey][vendorSlug]
                                  //   .delivering_to_logistic_company
                                  //   ? 0.4
                                  //   : 1,
                                }}
                              >
                                <Box sx={{ display: 'flex', alignItems: 'center' }}>
                                  {/* <Avatar
                                    src={deliveryAddressDetails.profile_photo}
                                    sx={{ width: 40, height: 40, mr: 2 }}
                                  /> */}
                                  <Box>
                                    <Typography fontWeight={500} variant="body2">
                                      {
                                        intShippingData?.recommended_partners[country_code][
                                          state_code
                                        ].selected_logistic_business_data.business_details
                                          .business_name
                                      }
                                    </Typography>
                                    <Typography fontWeight={500} variant="body2">
                                      {
                                        intShippingData?.recommended_partners[country_code][
                                          state_code
                                        ].selected_logistic_business_data.business_details
                                          .company_name
                                      }
                                    </Typography>
                                    <Typography variant="body2" fontSize={12}>
                                      {
                                        intShippingData?.recommended_partners[country_code][
                                          state_code
                                        ].selected_logistic_business_data.business_details.address
                                          .state_name
                                      }
                                      ,{' '}
                                      {
                                        intShippingData?.recommended_partners[country_code][
                                          state_code
                                        ].selected_logistic_business_data.business_details.address
                                          .country_name
                                      }
                                    </Typography>
                                  </Box>
                                </Box>
                              </Box>
                            </Box>
                          </TimelineContent>
                        </TimelineItem>

                        <TimelineItem>
                          <TimelineOppositeContent color="textSecondary">
                            <Typography variant="body2" fontSize={12}>
                              Shipping To
                            </Typography>
                          </TimelineOppositeContent>
                          <TimelineSeparator>
                            <TimelineDot color="primary" />
                            {/* <TimelineConnector /> */}
                          </TimelineSeparator>

                          <TimelineContent>
                            <Box sx={{ display: 'flex', alignItems: 'center' }} gap={3}>
                              <Box
                                gap={3}
                                sx={{
                                  display: 'flex',
                                  alignItems: 'center',
                                  // opacity: vendorList[countryCodeKey][vendorSlug]
                                  //   .delivering_to_logistic_company
                                  //   ? 0.4
                                  //   : 1,
                                }}
                              >
                                <Box sx={{ display: 'flex', alignItems: 'center' }}>
                                  {/* <Avatar
                                    src={deliveryAddressDetails.profile_photo}
                                    sx={{ width: 40, height: 40, mr: 2 }}
                                  /> */}
                                  <Box>
                                    <Typography fontWeight={500} variant="body2">
                                      {
                                        intShippingData.delivery_address_details.full_address
                                          .company
                                      }
                                    </Typography>
                                    <Typography variant="body2" fontSize={12}>
                                      {
                                        intShippingData.delivery_address_details.full_address
                                          .address_1
                                      }
                                      ,{' '}
                                      {intShippingData.delivery_address_details.full_address
                                        .address_2
                                        ? `${
                                            intShippingData.delivery_address_details.full_address
                                              .address_2
                                          }, `
                                        : ''}
                                      {intShippingData.delivery_address_details.full_address.city},{' '}
                                      {
                                        intShippingData.delivery_address_details.full_address
                                          .postcode
                                      }
                                    </Typography>
                                  </Box>
                                </Box>
                              </Box>
                            </Box>
                          </TimelineContent>
                        </TimelineItem>
                      </Timeline>
                    </Grid>

                    <Grid xs={12} sm={6} lg={6}>
                      {!showingInSummary && (
                        <>
                          {intShippingData?.recommended_partners[country_code][state_code]
                            .has_selected ? (
                            <Alert sx={{ my: 2 }} severity="success" variant="standard">
                              You have selected your logistic partner for {state_code}
                              <Button
                                sx={{ ml: 2 }}
                                onClick={() => {
                                  if (setChangeLogisticsPartner) {
                                    setChangeLogisticsPartner({
                                      countryCode: country_code,
                                      stateCode: state_code,
                                    });
                                  }
                                }}
                                variant="outlined"
                                size="small"
                              >
                                Change
                              </Button>
                            </Alert>
                          ) : (
                            <Alert sx={{ my: 2 }} severity="warning" variant="outlined">
                              You have not yet selected a logistics partner for {state_code}. You
                              can select from our list of recommended partners below or add your
                              own.
                            </Alert>
                          )}
                        </>
                      )}
                      {intShippingData?.recommended_partners[country_code][state_code]
                        .selected_logistic_business_data ? (
                        <Card>
                          <CardContent>
                            <LogisticPartnerRow
                              showingInSummary={showingInSummary}
                              businessData={
                                intShippingData?.recommended_partners[country_code][state_code]
                                  .selected_logistic_business_data
                              }
                            />
                          </CardContent>
                        </Card>
                      ) : (
                        <EditLogisticPartnersDialog
                          embeded
                          countryId={country_code}
                          stateId={state_code}
                        />
                      )}
                    </Grid>
                  </Grid>
                </CardContent>
              </Card>
            ))}
          </>
        ))}
    </>
  );
}
function InternationalShippingComponent({ checkoutData }) {
  const [changeLogisticsPartner, setChangeLogisticsPartner] = useState(false);
  // const { checkoutData, actions } = useCheckoutContext();
  // console.log(checkoutData.delivery_address_id, '<< checkoutData.delivery_address_id');
  const { data: prepIntShippingData, isLoading: prepIntShippingIsLoading } =
    usePostPrepInternationalShippingQuery({
      address_id: checkoutData.delivery_address_id,
    });
  const router = useRouter();

  if (prepIntShippingIsLoading) {
    return <LoadingScreen />;
  }

  const intShippingData = prepIntShippingData?.data;
  const isReady = () => intShippingData?.can_progress;

  if (intShippingData.skip) {
    return router.push('/checkout/national-delivery');
  }

  const progressToNextStep = () => {
    if (isReady()) {
      // actions.updateDeliveryAddress(addressId);
      router.push('/checkout/national-delivery');
    }
  };
  return (
    <>
      <InternationalShippingContent
        setChangeLogisticsPartner={setChangeLogisticsPartner}
        intShippingData={intShippingData}
      />
      <Button
        disabled={!isReady()}
        size="large"
        color="primary"
        variant="contained"
        fullWidth
        sx={{ mt: 1 }}
        onClick={progressToNextStep}
      >
        Continue
      </Button>

      <EditLogisticPartnersDialog
        // embeded
        isOpen={changeLogisticsPartner !== false}
        checkout
        countryId={changeLogisticsPartner?.countryCode}
        stateId={changeLogisticsPartner?.stateCode}
        onClose={() => setChangeLogisticsPartner(false)}
      />

      {/*    
      <Card>
        <CardContent>
          <Typography variant="h5" gutterBottom>
            {' '}
            Colmobia <Iconify
              icon="fa6-solid:chevron-right"
              sx={{ color: 'primary' }}
              width={16}
            />{' '}
            Test{' '}
          </Typography>
          <EditLogisticPartnersDialog embeded countryId="US" stateId="GA" />
        </CardContent>
      </Card> */}
    </>
  );
}

export default function InternationalShipping() {
  const { checkoutData } = useCheckoutContext();

  const router = useRouter();

  if (checkoutData.delivery_address_id === null) {
    return <Navigate to="/checkout" />;
  }

  if (checkoutData?.delivery_address_id === null) {
    return (
      <Alert severity="warning">
        <Typography variant="body2">
          You need to select a delivery address before proceeding to international shipping
        </Typography>
        <Button variant="outlined" sx={{ mt: 1 }} onClick={() => router.push('/checkout')}>
          Add delivery address
        </Button>
      </Alert>
    );
  }
  return <InternationalShippingComponent checkoutData={checkoutData} />;
}
