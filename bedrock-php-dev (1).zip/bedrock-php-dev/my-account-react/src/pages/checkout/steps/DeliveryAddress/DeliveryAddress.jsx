/* eslint-disable react/prop-types */
import React, { useState, useEffect } from 'react';

import { Box } from '@mui/system';
import { LoadingButton } from '@mui/lab';
import { Card, Button, Dialog, CardContent } from '@mui/material';

import { useRouter } from 'src/routes/hooks';

import {
  useGetDeliveryAddressesQuery,
  usePostPrepInternationalShippingMMutation,
} from 'src/redux/api/myAccount';

import { LoadingScreen } from 'src/components/loading-screen';

import { AddressNewForm } from 'src/sections/address';
import AccountDeliveryAddress from 'src/sections/account/account-delivery-address';

import AddressCard from '../../components/AddressCard';
import { useCheckoutContext } from '../../context/use-checkout-context';

function DeliveryAddressList({ addresses, selectedAddressId, progressToNextStep, setIsLoading }) {
  const { checkoutData, actions } = useCheckoutContext();

  // const [selectedDeliveryAddressId, setSelectedDeliveryAddressId] = useState(checkoutData.delivery_address_id);

  const [firstAddressAdded, setFirstAddressAdded] = useState(false);

  const [prepInternationalShipping, prepInternationalShippingResults] =
    usePostPrepInternationalShippingMMutation();

  useEffect(() => {
    if (checkoutData.delivery_address_id) {
      prepInternationalShipping({ address_id: checkoutData.delivery_address_id });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [checkoutData?.delivery_address_id]);

  useEffect(() => {
    // setHasChanged(false);
    if (prepInternationalShippingResults?.data?.data) {
      actions.setSkipStepTwoData(prepInternationalShippingResults.data.data.skip);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [prepInternationalShippingResults.isSuccess]);

  useEffect(() => {
    // console.log('is loading!!', prepInternationalShippingResults.isLoading);
    setIsLoading(prepInternationalShippingResults.isLoading);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [prepInternationalShippingResults.isLoading]);

  useEffect(() => {
    // if (addresses?.length === 0) {
    //   actions.setDeliveryAddressId(null);
    // }
    if (!checkoutData.delivery_address_id) {
      console.log('running');
      if (addresses && addresses.length > 0) {
        actions.setDeliveryAddressId(addresses[0].id);
      }

      // addresses?.forEach((address) => {
      //   if (address.is_default) { // default not set?
      //     // setAddressId(address.id);
      //     actions.setDeliveryAddressId(address.id);
      //   }
      // });
    } else {
      const addressExists = addresses?.find(
        (address) => address.id === checkoutData.delivery_address_id
      );
      if (!addressExists) {
        actions.setDeliveryAddressId(null);
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [addresses]);

  useEffect(() => {
    if (firstAddressAdded && addresses?.length > 0) {
      actions.setDeliveryAddressId(addresses[0].id);
      progressToNextStep();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [firstAddressAdded, addresses, progressToNextStep]);

  return (
    <>
      {addresses?.length > 0 ? (
        <>
          {addresses.map((address) => (
            // const labelId = `checkbox-list-secondary-label-${address?.id}`;
            <>
              {/* {selectedDeliveryAddressId} == {selectedAddressId} */}
              <AddressCard
                selectedAddressId={checkoutData.delivery_address_id}
                address={address}
                onClick={() => {
                  prepInternationalShipping({ address_id: address?.id });
                  actions.setDeliveryAddressId(address?.id);

                  console.log('clicked');
                  // setSelectedDeliveryAddressId(address?.id);
                  // actions.setIsLoading(true);
                  // setAddressId(address?.id);
                }}
              />
            </>
          ))}
        </>
      ) : (
        <AddressNewForm
          embeded
          checkout
          onClose={() => {
            setFirstAddressAdded(true);
          }}
        />
      )}
    </>
  );
}

export default function CheckoutDeliveryAddress() {
  const { data, isLoading: getDeliveryAddressIsLoading, refetch } = useGetDeliveryAddressesQuery();
  // const [addressId, setAddressId] = useState(null);
  const [manageDeliveryAddresses, setManageDeliveryAddresses] = useState(false);
  const router = useRouter();
  const { checkoutStatus, checkoutData } = useCheckoutContext();
  const [isLoading, setIsLoading] = useState(false);
  const isReady = () => checkoutData.delivery_address_id;
  const isLoadingOverall = () => getDeliveryAddressIsLoading || isLoading;

  if (getDeliveryAddressIsLoading) {
    return <LoadingScreen />;
  }

  const progressToNextStep = () => {
    if (checkoutStatus.skip) {
      return router.push(`/checkout/national-delivery`);
    }
    return router.push(`/checkout/international-shipping`);
  };
  return (
    <>
      <Card>
        <CardContent>
          <DeliveryAddressList
            refetch={refetch}
            setIsLoading={setIsLoading}
            // selectedAddressId={checkoutData.delivery_address_id}
            // setAddressId={setAddressId}
            addresses={data?.data}
            progressToNextStep={progressToNextStep}
          />
          {data?.data.length > 0 && (
            <Box textAlign="right">
              <Button variant="outlined" onClick={() => setManageDeliveryAddresses(true)}>
                Manage Delivery Addresses
              </Button>
            </Box>
          )}
        </CardContent>
      </Card>
      {data?.data.length > 0 && (
        <LoadingButton
          disabled={!isReady()}
          loading={isLoadingOverall()}
          size="large"
          color="primary"
          variant="contained"
          fullWidth
          sx={{ mt: 3 }}
          onClick={progressToNextStep}
        >
          Continue
        </LoadingButton>
      )}
      <Dialog
        open={manageDeliveryAddresses}
        fullWidth
        maxWidth="md"
        // onClose={refetch}
        onClose={() => {
          setManageDeliveryAddresses(false);
          refetch();
        }}
      >
        <AccountDeliveryAddress embeded />
      </Dialog>
    </>
  );
}
