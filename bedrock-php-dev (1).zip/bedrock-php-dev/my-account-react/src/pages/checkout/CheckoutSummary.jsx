import PropTypes from 'prop-types';
import { useCallback } from 'react';

import { Box, Stack } from '@mui/system';
import { Paper, Avatar, Divider, Typography } from '@mui/material';

import { useRouter } from 'src/routes/hooks';

import { fCurrency } from 'src/utils/format-number';

import { useGetPaymentMethodsQuery, useGetDeliveryAddressesQuery } from 'src/redux/api/myAccount';

import Scrollbar from 'src/components/scrollbar';

import ProductInfoHorizontal from 'src/sections/order/product-info-horizontal';
import PaymentCardItemCompact from 'src/sections/payment/payment-card-item-compact';

import AddressCard from './components/AddressCard';
import { useCheckoutContext } from './context/use-checkout-context';

export default function CheckoutSummary({ step }) {
  const {
    checkoutData,
    checkoutSummary,
    checkoutStatus,
    // actions: { setVendorDeliveryServicesAndNotes, setPaymentMethodId },
  } = useCheckoutContext();
  const {
    data: deliveryAddresses,
    // isLoading,
    // refetch,
  } = useGetDeliveryAddressesQuery();

  // const { data: prepIntShippingData, isLoading } = usePostPrepInternationalShippingQuery({
  //   address_id: checkoutData.delivery_address_id,
  // });
  // const intShippingData = prepIntShippingData?.data;

  // checkoutData

  const selectedAddress = useCallback(() => {
    if (checkoutData.delivery_address_id && deliveryAddresses?.data) {
      return deliveryAddresses?.data.find(
        (address) => address.id === checkoutData.delivery_address_id
      );
    }
    return false;
  }, [checkoutData.delivery_address_id, deliveryAddresses]);

  const router = useRouter();

  const {
    data: cards,
    // isLoading: getPaymentMethodsIsLoading
  } = useGetPaymentMethodsQuery();

  const getSelectedCard = () =>
    cards?.data.find((cardLooped) => cardLooped.payment_id === checkoutData.payment_method_id);

  // useEffect(() => {
  //   if (cards?.data && !checkoutData.payment_method_id) {
  //     const defaultCard = cards?.data.find((card) => card.default);
  //     actions.setPaymentMethodId(defaultCard?.payment_id);
  //   }
  //   // eslint-disable-next-line react-hooks/exhaustive-deps
  // }, [cards]);

  const calcProductsScrollHeight = useCallback(() => {
    const screenHeight = window.innerHeight / 2;

    let height = 0;
    Object.keys(checkoutSummary?.items)?.forEach((vendorSlug) => {
      height += 50;
      // eslint-disable-next-line no-unsafe-optional-chaining
      height += checkoutSummary?.items[vendorSlug]?.details.length * 50;
    });

    if (height > screenHeight) {
      return '40vh';
    }

    return 'auto';
  }, [checkoutSummary?.items]);

  if (checkoutStatus.isLoading) {
    return null;
  }

  return (
    <div>
      {/* <Typography variant="h3">Checkout</Typography> */}

      {checkoutSummary?.items && (
        <Stack
          // spacing={1}
          component={Paper}
          variant="outlined"
          sx={{
            // cursor: 'pointer',
            p: 2.5,
            mt: 2,
            width: 1,
            position: 'relative',
            // border: selected ? '1px solid #8cb952' : '',
            // backgroundColor: selected ? '#fbfff6' : '',
          }}
        >
          <Box sx={{ height: calcProductsScrollHeight() }}>
            <Scrollbar>
              {Object.keys(checkoutSummary?.items)?.map((vendorSlug) => (
                <Box sx={{ mb: 2 }}>
                  <Box
                    sx={{
                      display: 'flex',
                      alignContent: 'center',
                      alignItems: 'center',
                      gap: 1,
                      mb: 1,
                    }}
                  >
                    <Avatar
                      sx={{ width: 30, height: 30 }}
                      src={checkoutSummary?.items[vendorSlug].avatar}
                    />
                    <Typography variant="body2" fontSize={16} fontWeight={600}>
                      {checkoutSummary?.items[vendorSlug]?.vendor_name}
                    </Typography>
                  </Box>
                  {checkoutSummary?.items[vendorSlug]?.details.map((product) => (
                    <Box sx={{ mb: 1 }}>
                      <Box sx={{ display: 'flex', alignItems: 'center' }}>
                        <Divider orientation="vertical" sx={{ mx: 1.5, height: 40 }} />
                        
                        <ProductInfoHorizontal hideSizeTable hideVendorTitle item={product} />
                      </Box>
                    </Box>
                  ))}
                </Box>
              ))}
            </Scrollbar>
          </Box>
        </Stack>
      )}

      {selectedAddress() && (
        <>
          <Typography variant="h6" sx={{ mt: 4, mb: 1 }}>
            Delivery Address
          </Typography>
          <AddressCard
            hideCheckbox
            address={selectedAddress()}
            selectedAddressId="_"
            onClick={() => {
              router.push('/checkout');
              // actions.setIsLoading(true);
              // setAddressId(address?.id);
              // actions.setDeliveryAddressId(address?.id);
              // prepInternationalShipping({ address_id: address?.id });
            }}
            // selected={checkoutData.delivery_address_id === address?.id}
          />
        </>
      )}
      {/* {!checkoutStatus.skip && (
        <>
          <Typography variant="h6" sx={{ mt: 4, mb: 1 }}>
            International Shipping{' '}
            <Button
              sx={{ ml: 1 }}
              variant="outlined"
              size="small"
              onClick={() => {
                router.push('/checkout/international-shipping');
              }}
            >
              Change
            </Button>
          </Typography>
          <InternationalShippingContent
            showingInSummary
            // setChangeLogisticsPartner={setChangeLogisticsPartner}
            intShippingData={intShippingData}
          />
        </>
      )} */}
      {getSelectedCard() && (
        <>
          <Typography variant="h6" sx={{ mt: 4, mb: 1 }}>
            Payment Details
          </Typography>
          <PaymentCardItemCompact
            card={getSelectedCard()}
            selected={false}
            // editCard={console.log}
            // deleteCard={handleConfirmDeleteCard}
            // enableCard={handleEnableCard}
            // setDefault={handleSetDefaultPaymentMethod}
          />
        </>
      )}

      <Stack direction="row">
        <Typography variant="h6" sx={{ mt: 4, mb: 1 }}>
          Total
        </Typography>

        <Typography variant="h6" sx={{ mt: 4, mb: 1, ml: 'auto' }}>
          {fCurrency(checkoutSummary?.cart_total)}
        </Typography>
      </Stack>
    </div>
  );
}

CheckoutSummary.propTypes = {
  step: PropTypes.string,
};
