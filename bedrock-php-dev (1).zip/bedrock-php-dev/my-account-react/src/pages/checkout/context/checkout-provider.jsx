import PropTypes from 'prop-types';
import { useMemo, useState, useEffect, useReducer } from 'react';

// import { useMeMutation } from 'src/redux/api/myAccount';

import { PARENT_HOST_URL } from 'src/config-global';
import { usePrepCheckoutMutation } from 'src/redux/api/myAccount';

import { LoadingScreen } from 'src/components/loading-screen';

// import { isValidToken } from './utils';
import { CheckoutContext } from './checkout-context';

// ----------------------------------------------------------------------
const initialState = {
  isLoading: false,
  skip: false,
  summary: false,
  payload: {
    payment_method_id: null,
    delivery_address_id: null,
    vendor_delivery_services_and_notes: [],
  },
};

const reducer = (state, action) => {
  switch (action.type) {
    case 'RESET':
      return initialState;

    case 'SET_CHECKOUT_SUMMARY':
      return {
        ...state,
        summary: action.payload,
      };

    case 'SET_DELIVERY_ADDRESS_ID':
      return {
        ...state,
        payload: {
          ...state.payload,
          delivery_address_id: action.payload,
        },
      };

    case 'SET_PAYMENT_METHOD_ID':
      return {
        ...state,
        payload: {
          ...state.payload,
          payment_method_id: action.payload,
        },
      };

    case 'SET_SKIP_VALUE':
      return {
        ...state,
        skip: action.payload,
      };

    case 'SET_IS_LOADING':
      return {
        ...state,
        isLoading: action.payload,
      };

    case 'VENDOR_DELIVERY_SERVICES_AND_NOTES':
      return {
        ...state,
        payload: {
          ...state.payload,

          vendor_delivery_services_and_notes: {
            ...state.payload.vendor_delivery_services_and_notes,

            [action.payload.vendorSlug]: {
              delivery_method_company: action.payload.selectedDeliveryCompany,
              delivery_method_service: action.payload.selectedDeliveryService,
              delivery_notes: action.payload.notesForSeller,
            },
          },
        },
      };

    case 'SET_SAVED_STATE': {
      return action.payload;
    }

    default:
      return state;
  }
};

// ----------------------------------------------------------------------

export function CheckoutProvider({ children }) {
  const [state, dispatch] = useReducer(reducer, initialState);
  const [isLoadingLocal, setIsLoadingLocal] = useState(true);
  const [prepCheckout, prepCheckoutResult] = usePrepCheckoutMutation();

  useEffect(() => {
    getLocalState();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (prepCheckoutResult.isSuccess) {
      if (!prepCheckoutResult?.data?.data.is_valid || prepCheckoutResult?.data?.data.is_empty) {
        window.location.replace(`${PARENT_HOST_URL}/cart`);
      } else {
        dispatch({ type: 'SET_CHECKOUT_SUMMARY', payload: prepCheckoutResult?.data?.data });
        setIsLoadingLocal(false);
      }
    }
  }, [prepCheckoutResult.isSuccess, prepCheckoutResult?.data?.data]);

  const getLocalState = () => {
    const savedState = localStorage.getItem('checkoutState');
    if (savedState) {
      dispatch({ type: 'SET_SAVED_STATE', payload: JSON.parse(savedState) });
    }

    prepCheckout();
  };

  useEffect(() => {
    const data = state;
    delete data.isLoading;
    localStorage.setItem('checkoutState', JSON.stringify(state));
  }, [state]);

  const setDeliveryAddressId = (deliveryAddressId) => {
    dispatch({
      type: 'SET_DELIVERY_ADDRESS_ID',
      payload: deliveryAddressId,
    });
  };

  const setPaymentMethodId = (paymentMethodId) => {
    dispatch({
      type: 'SET_PAYMENT_METHOD_ID',
      payload: paymentMethodId,
    });
  };

  const setSkipStepTwoData = (value) => {
    dispatch({
      type: 'SET_SKIP_VALUE',
      payload: value,
    });
  };

  const setIsLoading = (value) => {
    dispatch({
      type: 'SET_IS_LOADING',
      payload: value,
    });
  };

  const setVendorDeliveryServicesAndNotes = (payload) => {
    dispatch({
      type: 'VENDOR_DELIVERY_SERVICES_AND_NOTES',
      payload,
    });
  };

  const reset = () => {
    dispatch({ type: 'RESET' });
  };

  const memoizedValue = useMemo(
    () => ({
      checkoutData: state.payload,
      checkoutStatus: {
        isLoading: state.isLoading,
        skip: state.skip,
      },
      checkoutSummary: state.summary,
      actions: {
        setDeliveryAddressId,
        setPaymentMethodId,
        setSkipStepTwoData,
        setIsLoading,
        setVendorDeliveryServicesAndNotes,
        reset,
      },
    }),
    [state]
  );

  if (isLoadingLocal) {
    return <LoadingScreen />;
  }
  return <CheckoutContext.Provider value={memoizedValue}>{children}</CheckoutContext.Provider>;
}

CheckoutProvider.propTypes = {
  children: PropTypes.node,
};
