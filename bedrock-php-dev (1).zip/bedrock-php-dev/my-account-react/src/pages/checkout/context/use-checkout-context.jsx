import { useContext } from 'react';

import { CheckoutContext } from './checkout-context';

// ----------------------------------------------------------------------

export const useCheckoutContext = () => {
  const context = useContext(CheckoutContext);

  if (!context) throw new Error('useCheckoutContext context must be use inside AuthProvider');

  return context;
};
