import PropTypes from 'prop-types';
import { Helmet } from 'react-helmet-async';
import { enqueueSnackbar } from 'notistack';
import { FileUploader } from 'react-drag-drop-files';
import { useState, useEffect, useCallback } from 'react';

import { LoadingButton } from '@mui/lab';
import { Box, Container } from '@mui/system';
import { Card, Alert, Button, Typography, CardContent, CircularProgress } from '@mui/material';

import { useRouter } from 'src/routes/hooks';

import uuidv4 from 'src/utils/uuidv4';

import { useAuthContext } from 'src/auth/hooks';
import { useSupabaseContext } from 'src/supabase/hooks';
import { useUploadDocumentMutation, useGetAccountSettingsQuery } from 'src/redux/api/myAccount';

import Iconify from 'src/components/iconify';

import AccountSettingsTabs from './AccountSettingsTabs';

function getExtensionFromMimeType(mimeType) {
  const mimeTypes = {
    'image/jpeg': 'jpg',
    'image/png': 'png',
    'application/pdf': 'pdf',
    // Add more MIME types and their corresponding extensions as needed
  };

  return mimeTypes[mimeType] || false;
}

const fileTypes = ['PDF', 'JPEG', 'JPG', 'PNG'];
//
const DocumentModule = ({
  title,
  description,
  fileType,
  onFileUpload,
  docFileStatus,
  isFetchingAccountData,
}) => {
  const [changeFile, setChangeFile] = useState(false);

  const [putUploadDocument, putUploadDocumentResults] = useUploadDocumentMutation();
  const [isUploading, setIsUploading] = useState(false);
  const { user, refresh } = useAuthContext();

  const { makeAPICall } = useSupabaseContext();

  const uploadDocument = useCallback(
    async (uploadedFile, docType) => {
      setIsUploading(true);
      const ext = getExtensionFromMimeType(uploadedFile.type);
      if (!ext) {
        throw new Error('Unsupported file type');
      }
      // console.log(uploadedBlob);

      const fileName = `${uuidv4()}.${ext}`;
      const fullPath = `${user.id}/${fileName}`;
      const { error } = await makeAPICall((dbClient) =>
        dbClient.storage.from('documents').upload(fullPath, uploadedFile, {
          cacheControl: '3600',
          upsert: false,
        })
      );

      if (error) {
        throw new Error(error);
      }

      putUploadDocument({
        doc_type: docType,
        file_url: fullPath,
      });
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [makeAPICall]
  );

  const handleFileUpload = async (fileUploaded, docType) => {
    try {
      setIsUploading(true);
      await uploadDocument(fileUploaded, docType);
      // setIsUploading(false);
    } catch (err) {
      console.error(err);
      enqueueSnackbar('Error uploading document', 'error');
      setIsUploading(false);
    }

    // const reader = new FileReader();
    // reader.onload = (e) => {
    //   // setFile(e.target.result);
    //   console.log(e.target.result);
    // };
    // reader.readAsDataURL(fileUploaded);
  };

  // useEffect(() => {

  useEffect(() => {
    if (putUploadDocumentResults.isSuccess) {
      setIsUploading(false);
      enqueueSnackbar('Document uploaded successfully', 'success');
      refresh();
    }
    if (putUploadDocumentResults.isError) {
      enqueueSnackbar('Error uploading document', 'error');
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [putUploadDocumentResults.isSuccess, putUploadDocumentResults.isError]);

  return (
    <Card sx={{ mb: 2 }}>
      <CardContent>
        <Typography variant="h6">{title}</Typography>

        <Typography variant="body2" sx={{ mb: 1 }}>
          {description}
        </Typography>
        {isUploading || isFetchingAccountData ? (
          <Box sx={{ display: 'flex', justifyContent: 'center', width: '100%' }}>
            <CircularProgress />
          </Box>
        ) : (
          <>
            {(changeFile || !docFileStatus?.file_name) && (
              <FileUploader
                handleChange={(uploadedFile) => {
                  handleFileUpload(uploadedFile, fileType);
                  setChangeFile(false);
                }}
                name="file"
                types={fileTypes}
              />
            )}

            {docFileStatus?.status === 'approved' && !changeFile && (
              <Alert severity="success" sx={{ mb: 2 }}>
                Your document has been approved
                <Button onClick={() => setChangeFile(true)} variant="outlined" sx={{ ml: 2 }}>
                  Change file
                </Button>
              </Alert>
            )}

            {docFileStatus?.status === 'rejected' && !changeFile && (
              <Alert severity="error" sx={{ mb: 2, mt: 2 }}>
                {docFileStatus.rejected_reason}
              </Alert>
            )}

            {!docFileStatus?.status && docFileStatus?.file_name && !changeFile && (
              <Alert severity="warning" sx={{ mb: 2 }}>
                Your document is pending approval
                <Button onClick={() => setChangeFile(true)} variant="outlined" sx={{ ml: 2 }}>
                  Change file
                </Button>
              </Alert>
            )}
          </>
        )}
      </CardContent>
    </Card>
  );
};

DocumentModule.propTypes = {
  title: PropTypes.string,
  description: PropTypes.string,
  fileType: PropTypes.string,
  onFileUpload: PropTypes.func,
  docFileStatus: PropTypes.object,
  isFetchingAccountData: PropTypes.bool,
};

export const BusinessDocumentsForm = ({ wizardActive }) => {
  const [checkStatusClicked, setCheckStatusClicked] = useState(false);
  const router = useRouter();
  const { refresh } = useAuthContext();

  const {
    data: accountSettingsPayload,
    isFetching,
    isLoading,
    refetch,
  } = useGetAccountSettingsQuery();
  const { user } = useAuthContext();
  useEffect(() => {
    if (accountSettingsPayload?.data.docs.approved) {
      enqueueSnackbar('Documents have been approved', { variant: 'success' });
      refresh();
    }
    if (checkStatusClicked && !isFetching) {
      if (!accountSettingsPayload?.data.docs.approved) {
        enqueueSnackbar('Documents are still pending approval', { variant: 'info' });
        setCheckStatusClicked(false);
      }
    }
  }, [accountSettingsPayload, checkStatusClicked, isFetching, refresh, router]);
  return (
    <Box sx={{ mb: 1 }}>
      {!wizardActive && (
        <Typography variant="h4" sx={{ mb: 2 }}>
          Business Documents {isFetching && <CircularProgress size={20} />}
        </Typography>
      )}

      {accountSettingsPayload?.data.docs.uploaded && !accountSettingsPayload?.data.docs.approved ? (
        <Box alignContent="center" justifyContent="center" textAlign="center" sx={{ mt: 3 }}>
          <Typography variant="h4" sx={{ mb: 2, mt: 2 }}>
            <Iconify
              style={{ position: 'relative', top: '2px' }}
              sx={{ mr: 1 }}
              height={20}
              width={20}
              icon="bx:bx-check-circle"
              color="#4CAF50"
            />
            We have received your documents
          </Typography>
          <Typography variant="body1" sx={{ mb: 2, maxWidth: 600 }}>
            You have uploaded all required documents, our team is reviewing them and will get back
            to you within 24 hours.
          </Typography>

          <LoadingButton
            sx={{ mt: 2 }}
            size="large"
            variant="outlined"
            loading={isFetching || isLoading}
            color="primary"
            onClick={() => {
              setCheckStatusClicked(true);
              refetch();
            }}
          >
            Check status
          </LoadingButton>
        </Box>
      ) : (
        <>
          {user?.role === 'vendor' && (
            <DocumentModule
              title="Article of Incorporation"
              description="We use this to verify that you are the owner of your business. We accept any government recognized ID such as a passport or driver's license."
              fileType="article_of_incorporation"
              isFetchingAccountData={isLoading}
              docFileStatus={
                accountSettingsPayload?.data.docs.file_statuses.article_of_incorporation
              }
            />
          )}

          <DocumentModule
            title="Identification Document"
            description="We use this to verify that you are the owner of your business. We accept any government recognized ID such as a passport or driver's license."
            fileType="identification_document"
            isFetchingAccountData={isLoading}
            docFileStatus={accountSettingsPayload?.data.docs.file_statuses.identification_document}
          />

          <DocumentModule
            title="Sales Permit"
            description="We use this to verify your business. We accept a seller’s permit, or business license,
            is a document issued by a government agency that authorizes a business to collect sales
            tax on taxable goods and services."
            fileType="sales_permit"
            isFetchingAccountData={isLoading}
            docFileStatus={accountSettingsPayload?.data.docs.file_statuses.sales_permit}
          />
        </>
      )}
    </Box>
  );
};

BusinessDocumentsForm.propTypes = {
  wizardActive: PropTypes.bool,
};

export default function BusinessDetailsPage() {
  return (
    <>
      <Helmet>
        <title>Account Settings</title>
      </Helmet>
      <Container maxWidth="md">
        <AccountSettingsTabs activeTab="business-documents" />
        <Card>
          <CardContent>
            <BusinessDocumentsForm />
          </CardContent>
        </Card>
      </Container>
    </>
  );
}

BusinessDetailsPage.prototypes = {
  hideTabs: PropTypes.bool,
  wizardActive: PropTypes.bool,
};
