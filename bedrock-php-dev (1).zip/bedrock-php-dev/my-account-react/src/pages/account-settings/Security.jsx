// import 'react-phone-number-input/style.css';
// import PhoneInput from 'react-phone-number-input';
import { useEffect } from 'react';
import { Helmet } from 'react-helmet-async';
import { enqueueSnackbar } from 'notistack';

import { Box, Stack, Container } from '@mui/system';
import {
  Card,
  Alert,
  Switch,
  FormGroup,
  Typography,
  CardContent,
  FormControlLabel,
  CircularProgress,
} from '@mui/material';

import { useGetAccountSettingsQuery, useToggleAccount2FaMutation } from 'src/redux/api/myAccount';

import AccountSettingsTabs from './AccountSettingsTabs';

export default function Page() {
  const { data: accountSettingsPayload, isFetching } = useGetAccountSettingsQuery();
  const [toggleAccount2Fa, toggleAccount2FaResults] = useToggleAccount2FaMutation();

  useEffect(() => {
    if (toggleAccount2FaResults.isSuccess) {
      const enabled = toggleAccount2FaResults?.data?.data?.enabled;
      if (enabled) {
        enqueueSnackbar('Two Factor Authentication Enabled', { variant: 'success' });
      } else {
        enqueueSnackbar('Two Factor Authentication Disabled', { variant: 'warning' });
      }
    }
    if (toggleAccount2FaResults.isError) {
      enqueueSnackbar('Unable to change Two Factor Authentication', { variant: 'error' });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [toggleAccount2FaResults.isSuccess, toggleAccount2FaResults.isError]);

  return (
    <>
      <Helmet>
        <title>Account Settings</title>
      </Helmet>

      <Container maxWidth="md">
        <AccountSettingsTabs activeTab="security" />

        <Card>
          <CardContent>
            <Box sx={{ mb: 2 }}>
              <Typography variant="h4">Login Two Factor Authentication</Typography>
            </Box>
            <Typography variant="body2" sx={{ mb: 2 }}>
              Two Factor Authentication adds an extra layer of security to your account. Once
              enabled, you will be required to enter a code sent to your email when logging in.
            </Typography>

            {!accountSettingsPayload?.data?.two_fa_enabled && (
              <Alert severity="warning" sx={{ mb: 2 }}>
                You do not have Two Factor Authentication activated. We recommend activating this to
                further secure your account.
              </Alert>
            )}

            <FormGroup>
              <Stack spacing={1} direction="row" alignItems="center">
                <FormControlLabel
                  disabled={toggleAccount2FaResults.isLoading || isFetching}
                  checked={accountSettingsPayload?.data?.two_fa_enabled}
                  onChange={() => toggleAccount2Fa()}
                  control={<Switch defaultChecked />}
                  label="Two Factor Authentication"
                />
                {(toggleAccount2FaResults.isLoading || isFetching) && (
                  <CircularProgress size={20} sx={{ color: '#222' }} />
                )}
              </Stack>
            </FormGroup>
          </CardContent>
        </Card>

        <Card sx={{ mt: 3 }}>
          <CardContent>
            {/* title */}
            <Box sx={{ mb: 2 }}>
              <Typography variant="h4">Change Password</Typography>
            </Box>
            {/* <FormProvider 
            methods={methods} onSubmit={onSubmit}
            >
              <Stack spacing={2} sx={{ pt: 1 }}>
                <Box>
                  <RHFTextField type="password" name="current_password" label="Current Password" />
                </Box>

                <Box>
                  <RHFTextField type="password" name="new_password" label="New Password" />
                </Box>
                <Box>
                  <RHFTextField
                    type="password"
                    name="confirm_new_password"
                    label="Repeat Password"
                  />
                </Box>
              </Stack>

              <DialogActions sx={{ px: 0, pb: 0 }}>
                <LoadingButton
                  type="submit"
                  size="large"
                  variant="contained"
                  // loading={
                  //   addDeliveryAddressResult.isLoading ||
                  //   updateDeliveryAddressResult.isLoading ||
                  //   isSubmitting
                  // }
                >
                  Save
                </LoadingButton>
              </DialogActions>
            </FormProvider> */}
          </CardContent>
        </Card>
      </Container>
    </>
  );
}
