import * as Yup from 'yup';
import PropTypes from 'prop-types';
import { useForm } from 'react-hook-form';
import { Helmet } from 'react-helmet-async';
import { enqueueSnackbar } from 'notistack';
import { yupResolver } from '@hookform/resolvers/yup';
import { useState, useEffect, useCallback } from 'react';

import { LoadingButton } from '@mui/lab';
import { Box, Stack, Container } from '@mui/system';
import { Card, Typography, CardContent, CircularProgress } from '@mui/material';

import { useRouter } from 'src/routes/hooks';

import { useAuthContext } from 'src/auth/hooks';
import {
  useGetAccountSettingsQuery,
  usePutAccountBusinessDetailsMutation,
} from 'src/redux/api/myAccount';

import AddressFields from 'src/components/forms/Address';
import FormProvider from 'src/components/hook-form/form-provider';
import { RHFTelField, RHFTextField } from 'src/components/hook-form';

import AccountSettingsTabs from './AccountSettingsTabs';

const isNotEmpty = (value) => {
  if (!value || value === '') {
    return false;
  }
  return value;
};
export const BusinessDetailsForm = ({ wizardActive }) => {
  const { data: accountSettingsPayload, isFetching } = useGetAccountSettingsQuery();

  // const [putAccountSettings, putAccountSettingsResults] = usePutAccountSettingsMutation();
  const [putAccountBusinessDetails, putAccountBusinessDetailsResults] =
    usePutAccountBusinessDetailsMutation();
  const [countryStateCodes, setCountryStateCodes] = useState(null);
  const [requiresState, setRequiresState] = useState(false);
  const router = useRouter();
  const { user } = useAuthContext();

  const BusinessDetailsSchema2 = useCallback(() => {
    const schema = Yup.object().shape({
      business_name: Yup.string().required('Business name is required'),
      phone_number: Yup.string().required('Phone number is required'),
      email: Yup.string().required('Phone number is required'),
      address: Yup.object().shape({
        address_1: Yup.string().required('Address is required'),
        address_2: Yup.string().nullable(),
        city: Yup.string().required('City is required'),
        postcode: Yup.string().required('Postal code is required'),
        country: Yup.string().required('Country is required'),
        state: requiresState ? Yup.string().required('State is required') : Yup.string().nullable(),
      }),
    });

    return schema;
  }, [requiresState]);

  const defaultValues = {
    business_name: isNotEmpty(accountSettingsPayload?.data?.business_details?.business_name) || '',
    phone_number: isNotEmpty(accountSettingsPayload?.data?.business_details?.phone_number) || '',
    email: isNotEmpty(accountSettingsPayload?.data?.business_details?.email) || '',
    address: {
      address_1:
        isNotEmpty(accountSettingsPayload?.data?.business_details?.address?.address_1) || '',
      address_2:
        isNotEmpty(accountSettingsPayload?.data?.business_details?.address?.address_2) || '',
      city: isNotEmpty(accountSettingsPayload?.data?.business_details?.address?.city) || '',
      postcode: isNotEmpty(accountSettingsPayload?.data?.business_details?.address?.postcode) || '',
      state: isNotEmpty(accountSettingsPayload?.data?.business_details?.address?.state) || '',
      country: isNotEmpty(accountSettingsPayload?.data?.business_details?.address?.country) || '',
    },
  };

  const methods = useForm({
    resolver: yupResolver(BusinessDetailsSchema2()),
    defaultValues,
  });

  const {
    handleSubmit,
    formState: { isSubmitting },
    getValues,
    setValue,
    reset,
    isDirty,
    setError,
  } = methods;
  const formValues = getValues();

  useEffect(() => {
    if (accountSettingsPayload?.data && !isDirty) {
      reset(defaultValues);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [accountSettingsPayload, reset]);

  const onSubmit = handleSubmit(async (data) => {
    try {
      // console.log('sunmitting!!!');
      // console.log(data, '<<data');
      putAccountBusinessDetails(data);
    } catch (e) {
      console.error(e);
    }
  });

  const isLoading = () => putAccountBusinessDetailsResults.isLoading || isSubmitting || isFetching;

  useEffect(() => {
    if (putAccountBusinessDetailsResults.isSuccess) {
      enqueueSnackbar('Business details have been saved', { variant: 'success' });
      if (wizardActive) {
        router.push('/wizard/documents');
      }
    }
    if (putAccountBusinessDetailsResults.isError) {
      if (putAccountBusinessDetailsResults?.error?.data?.data?.error === 'business_name_exists') {
        setError('business_name', {
          type: 'manual',
          message: 'This business name is take, please try another.',
        });
        enqueueSnackbar('Business name already exists', { variant: 'error' });
      } else {
        enqueueSnackbar('Unable to save, please try again', { variant: 'error' });
      }
    }
  }, [
    putAccountBusinessDetailsResults?.isSuccess,
    putAccountBusinessDetailsResults?.isError,
    putAccountBusinessDetailsResults?.data?.data,
    putAccountBusinessDetailsResults?.data?.error,
    setError,
    putAccountBusinessDetailsResults?.error?.data?.data?.error,
    router,
    wizardActive,
  ]);
  return (
    <>
      {!wizardActive && (
        <Box sx={{ mb: 1 }}>
          <Typography variant="h4">
            Business Details {isLoading() && <CircularProgress size={20} />}
          </Typography>
        </Box>
      )}

      <FormProvider methods={methods} onSubmit={onSubmit}>
        <Stack spacing={2} sx={{ pb: 1, pt: 1 }}>
          <Box sx={{ mb: 2 }}>
            <RHFTextField
              disabled={
                (accountSettingsPayload?.data?.business_details?.business_name !== '' &&
                  !user?.is_emulating) ||
                isLoading()
              }
              name="business_name"
              helperText={
                accountSettingsPayload?.data?.business_details?.business_name !== ''
                  ? 'Please contact support to change your business name'
                  : null
              }
              label="Business Name"
            />
          </Box>
          <Box
            rowGap={2}
            columnGap={2}
            display="grid"
            gridTemplateColumns={{
              xs: 'repeat(1, 1fr)',
              sm: 'repeat(2, 1fr)',
            }}
          >
            <RHFTelField disabled={isLoading()} name="phone_number" label="Business Phone Number" />
            <RHFTextField disabled={isLoading()} name="email" label="Business Email" />
          </Box>
        </Stack>

        <AddressFields
          disabled={isLoading()}
          formValues={formValues.address}
          setValue={setValue}
          onCountryStateCodesReceived={(data) => setCountryStateCodes(data)}
          setRequiresState={setRequiresState}
        />

        <LoadingButton
          type="submit"
          size="large"
          variant="contained"
          disabled={!countryStateCodes}
          loading={isLoading()}
          sx={{ mt: 2 }}
          fullWidth
        >
          {wizardActive ? 'Continue' : 'Save'}
        </LoadingButton>
      </FormProvider>
    </>
  );
};

BusinessDetailsForm.propTypes = {
  wizardActive: PropTypes.bool,
};

export default function BusinessDetailsPage() {
  return (
    <>
      <Helmet>
        <title>Account Settings</title>
      </Helmet>
      <Container maxWidth="md">
        <AccountSettingsTabs activeTab="business-details" />
        <Card>
          <CardContent>
            <BusinessDetailsForm />
          </CardContent>
        </Card>
      </Container>
    </>
  );
}

BusinessDetailsPage.prototypes = {
  hideTabs: PropTypes.bool,
  wizardActive: PropTypes.bool,
};
