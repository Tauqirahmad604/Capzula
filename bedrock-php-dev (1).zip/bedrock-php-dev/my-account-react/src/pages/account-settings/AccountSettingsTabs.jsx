import PropTypes from 'prop-types';

import { Tab, Tabs } from '@mui/material';

import { useRouter } from 'src/routes/hooks';

export default function AccountSettingsTabs({ activeTab }) {
  const router = useRouter();

  return (
    <Tabs
      sx={{ mb: 2 }}
      value={activeTab}
      onChange={(e, value) => router.push(`/account-settings/${value}`)}
      aria-label="basic tabs example"
    >
      <Tab label="General" value="" />
      <Tab label="Security" value="security" />
      <Tab label="Social Media" value="social-media" />
      <Tab label="Business Details" value="business-details" />
      <Tab label="Business Documents" value="business-documents" />
    </Tabs>
  );
}

AccountSettingsTabs.propTypes = {
  activeTab: PropTypes.string.isRequired,
};
