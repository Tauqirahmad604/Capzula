import { useState } from 'react';
import PropTypes from 'prop-types';
import { Navigate } from 'react-router';
import { Helmet } from 'react-helmet-async';

import { useParams } from 'src/routes/hooks';

import { useAuthContext } from 'src/auth/hooks';
import { CRISP_WEBSITE_ID } from 'src/config-global';

import { LoadingScreen } from 'src/components/loading-screen';
// ----------------------------------------------------------------------

export default function CrispTicketIFrame({ src, newTicket }) {
  const [isLoading, setIsLoading] = useState(true);
  const params = useParams();
  const { user } = useAuthContext();
  const { template } = params;
  const orderId = new URLSearchParams(window.location.search).get('order');

  const templateData = {
    refund: {
      category: 'Refund',
      subject: `Refund Request ${orderId ? `Order #${orderId}` : ''}`,
      message: `Order Number: #${
        orderId || '[Enter order number here]'
      }\nReason for Refund: [Enter reason here]\nAmount: [Enter amount here]
      `,
    },
  };

  const buildQueryParams = (templateToUse) => {
    const data = templateData[templateToUse] || {};
    const category = encodeURIComponent(data.category || '');
    const subject = encodeURIComponent(data.subject || '');
    const message = encodeURIComponent(data.message || '');
    return `&category=${category}&subject=${subject}&message=${message}`;
  };

  if (template && !templateData[template]) {
    return <Navigate to="/404" />;
  }

  return (
    <>
      <Helmet>
        <title>Support Tickets</title>
      </Helmet>

      {isLoading && <LoadingScreen />}

      <iframe
        title="Support Tickets"
        src={`https://plugins.crisp.chat/urn:crisp.im:ticket-center:0/tickets/${CRISP_WEBSITE_ID}${
          newTicket ? '/create/' : ''
        }?email=${user?.email}&hmac=${user?.crisp_ticket_token}${
          template ? `${buildQueryParams(template)}` : ''
        }`}
        referrerPolicy="origin"
        sandbox="allow-forms allow-popups allow-modals allow-scripts allow-same-origin"
        width="100%"
        onLoad={() => setIsLoading(false)}
        style={{ display: isLoading ? 'none' : 'block', height: 'calc(100vh - 92px)' }}
        frameBorder="0"
      />
    </>
  );
}

CrispTicketIFrame.propTypes = {
  src: PropTypes.string,
  newTicket: PropTypes.bool,
};
