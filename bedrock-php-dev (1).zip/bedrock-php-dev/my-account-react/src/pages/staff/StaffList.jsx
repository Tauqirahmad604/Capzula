import { m } from 'framer-motion';
import { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet-async';

import Card from '@mui/material/Card';
import Table from '@mui/material/Table';
import { Container } from '@mui/system';
import { LoadingButton } from '@mui/lab';
import TableRow from '@mui/material/TableRow';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableHead from '@mui/material/TableHead';
import TableContainer from '@mui/material/TableContainer';
import {
  Chip,
  Dialog,
  Button,
  MenuItem,
  IconButton,
  DialogTitle,
  DialogContent,
  DialogActions,
  DialogContentText,
} from '@mui/material';

import { useRouter, useParams } from 'src/routes/hooks';

import { fDateTime } from 'src/utils/format-time';

import { trl } from 'src/locales/i18n';
import {
  useGetStaffQuery,
  useDeleteStaffMutation,
  useResetStaffPasswordMutation,
} from 'src/redux/api/myAccount';

import Iconify from 'src/components/iconify';
import { TableNoData } from 'src/components/table';
import { useSnackbar } from 'src/components/snackbar';
import { LoadingScreen } from 'src/components/loading-screen';
import CustomPopover, { usePopover } from 'src/components/custom-popover';
import CustomBreadcrumbs from 'src/components/custom-breadcrumbs/custom-breadcrumbs';

import EditStaff from './EditStaff';

// ----------------------------------------------------------------------

// eslint-disable-next-line react/prop-types
const EditButton = ({ id, onDeleteClick, onResetPasswordClick }) => {
  const popover = usePopover();
  const router = useRouter();

  return (
    <>
      <IconButton
        component={m.button}
        whileTap="tap"
        whileHover="hover"
        onClick={popover.onOpen}
        sx={{
          width: 40,
          height: 40,
        }}
      >
        <Iconify icon="solar:menu-dots-bold" sx={{ borderRadius: 0.65, width: 28 }} />
      </IconButton>
      <CustomPopover open={popover.open} onClose={popover.onClose} sx={{ width: 160 }}>
        <MenuItem selected={false} onClick={() => router.push(`/staff/${id}`)}>
          Edit
        </MenuItem>
        <MenuItem selected={false} onClick={onResetPasswordClick}>
          Reset Password
        </MenuItem>
        <MenuItem selected={false} onClick={onDeleteClick} sx={{ color: 'error.main' }}>
          Delete
        </MenuItem>
      </CustomPopover>
    </>
  );
};

export default function Page() {
  const [pageNum] = useState(0);
  const [editUser, setEditUser] = useState(null);
  const [deleteUser, setDeleteUser] = useState(null);
  const [resetPassword, setResetPassword] = useState(null);

  const [deleteStaffCall, deleteStaffCallResult] = useDeleteStaffMutation();
  const [resetPasswordCall, resetPasswordResult] = useResetStaffPasswordMutation();
  const router = useRouter();
  const { id } = useParams();
  const { enqueueSnackbar } = useSnackbar();

  const { data: response, isLoading } = useGetStaffQuery({
    pageNum,
    status: 0,
  });

  const displayPermissions = (permissions) => {
    const permissionsArray = [
      {
        name: 'manage_orders_view',
        label: 'Orders',
      },
      {
        name: 'manage_commissions_view',
        label: 'Commissions',
      },
      {
        name: 'manage_orders_edit',
        label: 'Orders',
      },
      {
        name: 'manage_products_view',
        label: 'Products',
      },
      {
        name: 'manage_products_edit',
        label: 'Products',
      },
      {
        name: 'manage_promos_edit',
        label: 'Promotions',
      },
      {
        name: 'manage_promos_view',
        label: 'Promotions',
      },
      {
        name: 'manage_store_edit',
        label: 'Store',
      },
      {
        name: 'manage_chats_edit',
        label: 'Chat',
      },
      {
        name: 'manage_reports_view',
        label: 'Reports',
      },
    ];

    const groupedPermissions = Object.keys(permissions).reduce((grouped, key) => {
      const permission = permissionsArray.find((p) => p.name === key);
      if (permission && permissions[key]) {
        const groupName = permission.label;
        grouped[groupName] = grouped[groupName] || { view: false, edit: false };
        grouped[groupName].view =
          grouped[groupName].view || (key.includes('_view') && permissions[key]);
        grouped[groupName].edit =
          grouped[groupName].edit || (key.includes('_edit') && permissions[key]);
      }
      return grouped;
    }, {});

    return Object.entries(groupedPermissions).map(([groupName, { view, edit }]) => (
      <Chip
        key={groupName}
        // eslint-disable-next-line no-nested-ternary
        label={edit ? `View & Manage ${groupName}` : view ? `View ${groupName}` : ''}
        color="secondary"
        sx={{ m: 0.5 }}
        size="small"
      />
    ));
  };

  const permissionsIsEmpty = (permissions) => permissions.filter((p) => p).length <= 0;

  useEffect(() => {
    if (deleteStaffCallResult.isSuccess || deleteStaffCallResult.isSuccess) {
      setDeleteUser(null);
      enqueueSnackbar('Staff account deleted successfully');
    }

    if (deleteStaffCallResult.isError) {
      enqueueSnackbar('Unable to delete staff account', { variant: 'error' });
    }
  }, [deleteStaffCallResult, enqueueSnackbar]);

  useEffect(() => {
    if (resetPasswordResult.isSuccess || resetPasswordResult.isSuccess) {
      setResetPassword(null);
      enqueueSnackbar('Email sent to staff to reset password');
    }

    if (resetPasswordResult.isError) {
      enqueueSnackbar('Sorry, unable to reset password', { variant: 'error' });
    }
  }, [resetPasswordResult, enqueueSnackbar, deleteStaffCallResult.isError]);

  useEffect(() => {
    if (id && response?.data) {
      const findUser = response?.data?.find((staff) => String(staff.id) === String(id));
      if (!findUser && id !== 'create') {
        return router.push('/staff');
      }

      console.log(findUser, '<< findUser');

      setEditUser(findUser);
    }
    return () => {};
  }, [id, response, router]);

  return (
    <>
      <Helmet>
        <title>Staff Accounts</title>
      </Helmet>
      <Container maxWidth="xl">
        <CustomBreadcrumbs
          heading={trl('Staff.staff_accounts')}
          links={[]}
          sx={{
            mb: 2,
            mt: 2,
          }}
        />

        {isLoading ? (
          <LoadingScreen />
        ) : (
          <>
            <Button
              sx={{ mb: 2 }}
              color="success"
              onClick={() => router.push('/staff/create')}
              variant="contained"
            >
              {trl('Staff.add_staff')}
            </Button>
            <Card sx={{ p: 2 }}>
              <TableContainer>
                <Table sx={{ minWidth: 650 }} aria-label="simple table">
                  <TableHead>
                    <TableRow>
                      {/* <TableCell width="5%">ID</TableCell> */}
                      <TableCell width="10%">{trl('Global.first_name')}</TableCell>
                      <TableCell width="10%">{trl('Global.last_name')}</TableCell>
                      <TableCell width="15%">{trl('Global.email')}</TableCell>
                      <TableCell width="35%">{trl('Staff.permissions')}</TableCell>
                      <TableCell width="5%">{trl('Global.created_at')}</TableCell>
                      <TableCell width="5%">{trl('Staff.last_login')}</TableCell>
                      <TableCell width="5%" />
                    </TableRow>
                  </TableHead>
                  <>
                    <TableBody>
                      {response?.data &&
                        response?.data?.map((staff) => (
                          <TableRow
                            key={staff.id}
                            sx={{
                              '&:last-child td, &:last-child th': { border: 0 },
                            }}
                          >
                            <TableCell>{staff.first_name}</TableCell>
                            <TableCell>{staff.last_name}</TableCell>
                            <TableCell>{staff.email}</TableCell>
                            <TableCell>
                              {permissionsIsEmpty(displayPermissions(staff.permissions))
                                ? 'No Permissions'
                                : displayPermissions(staff.permissions)}
                            </TableCell>
                            <TableCell width="20%"> {fDateTime(staff.created_at)}</TableCell>
                            <TableCell width="20%">
                              {staff.last_logged_in ? fDateTime(staff.last_logged_in) : 'Never'}
                            </TableCell>
                            <TableCell width="5%">
                              <EditButton
                                onDeleteClick={() => setDeleteUser(staff)}
                                onResetPasswordClick={() => setResetPassword(staff)}
                                id={staff.id}
                              />
                            </TableCell>
                          </TableRow>
                        ))}
                    </TableBody>
                    <TableNoData notFound={response?.data.staff?.length <= 0} />
                  </>
                </Table>
              </TableContainer>
            </Card>

            <Dialog
              fullWidth
              maxWidth="sm"
              open={!!id && response?.data}
              onClose={() => router.push('/staff')}
            >
              <DialogTitle sx={{ pb: 1 }}>{id === 'create' ? 'Create' : 'Edit'} Staff</DialogTitle>
              <DialogContent sx={{ p: 3 }}>
                <EditStaff create={id === 'create'} staff={id === 'create' ? null : editUser} />
              </DialogContent>
            </Dialog>

            <Dialog open={!!deleteUser} onClose={() => setDeleteUser(null)}>
              <DialogTitle>Delete {deleteUser?.first_name} </DialogTitle>

              <DialogContent>
                <DialogContentText>Are you sure you want to delete this user?</DialogContentText>
              </DialogContent>

              <DialogActions>
                <Button color="inherit" variant="outlined" onClick={() => setDeleteUser(null)}>
                  Cancel
                </Button>

                <LoadingButton
                  onClick={() => deleteStaffCall({ id: deleteUser.id })}
                  color="error"
                  variant="contained"
                  loading={deleteStaffCallResult.isLoading}
                >
                  Delete
                </LoadingButton>
              </DialogActions>
            </Dialog>

            <Dialog open={!!resetPassword} onClose={() => setResetPassword(null)}>
              <DialogTitle>Reset Password </DialogTitle>

              <DialogContent>
                <DialogContentText>
                  Are you sure you want to reset the password for{resetPassword?.first_name}? An
                  email will be sent to <strong>{resetPassword?.email}</strong>
                </DialogContentText>
              </DialogContent>

              <DialogActions>
                <Button color="inherit" variant="outlined" onClick={() => setResetPassword(null)}>
                  Cancel
                </Button>

                <LoadingButton
                  onClick={() => resetPasswordCall({ id: resetPassword.id })}
                  // color="error"
                  variant="contained"
                  loading={resetPasswordResult.isLoading}
                >
                  Reset Password
                </LoadingButton>
              </DialogActions>
            </Dialog>
          </>
        )}
      </Container>
    </>
  );
}
