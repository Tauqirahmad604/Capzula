// import * as Yup from 'yup';
// import { useState } from 'react';
// import { useForm } from 'react-hook-form';
// import { Helmet } from 'react-helmet-async';
// import { MuiColorInput } from 'mui-color-input';
// import { yupResolver } from '@hookform/resolvers/yup';

// import Box from '@mui/material/Box';
// import Card from '@mui/material/Card';
// import Stack from '@mui/material/Stack';
// import Container from '@mui/material/Container';
// import Grid from '@mui/material/Unstable_Grid2';
// import CardHeader from '@mui/material/CardHeader';
// import Typography from '@mui/material/Typography';

// import { useResponsive } from 'src/hooks/use-responsive';

// import { DELIVERY_SERVICES } from 'src/config-global';

// import { RHFUpload, RHFUploadAvatar } from 'src/components/hook-form/rhf-upload';
// import FormProvider, { RHFEditor, RHFTextField, RHFAutocomplete } from 'src/components/hook-form'; // Import Form from '@rjsf/core'

// // ----------------------------------------------------------------------

// export default function EditDeliveryMethod() {
//   const mdUp = useResponsive('up', 'md');
//   const [value, setValue] = useState('#ffffff');

//   const LoginSchema = Yup.object().shape({
//     email: Yup.string().required('Email is required').email('Email must be a valid email address'),
//     password: Yup.string().required('Password is required'),
//   });

//   const defaultValues = {
//     service: DELIVERY_SERVICES[0].name,
//     cost: 0,
//   };

//   const methods = useForm({
//     resolver: yupResolver(LoginSchema),
//     defaultValues,
//   });

//   const {
//     reset,
//     handleSubmit,
//     watch,
//     formState: { isSubmitting },
//   } = methods;

//   const values = watch();

//   const onSubmit = handleSubmit(async (data) => {
//     try {
//       console.log(data, '<< data');
//     } catch (error) {
//       console.error(error);
//       reset();
//       // setErrorMsg(typeof error === 'string' ? error : error.message);
//     }
//   });

//   const getSelectedDeliveryService = (selectedService) => {
//     console.log(selectedService);
//     const data = DELIVERY_SERVICES.find((service) => service.name === selectedService);
//     return data?.options || [];
//   };

//   const handleChange = (newValue) => {
//     setValue(newValue);
//   };

//   return (
//     <Container maxWidth="xl">
//       <Helmet>
//         <title>Edit Store</title>
//       </Helmet>

//       <FormProvider methods={methods} onSubmit={onSubmit}>
//         {/* {renderForm} */}
//         <Grid sx={{ mt: 2 }} container spacing={3}>
//           {mdUp && (
//             <Grid md={4}>
//               <Typography variant="h6" sx={{ mb: 0.5 }}>
//                 Store Branding
//               </Typography>
//               <Typography variant="body2" sx={{ color: 'text.secondary' }}>
//                 Upload all photos of your product
//               </Typography>
//             </Grid>
//           )}

//           <Grid xs={12} md={8}>
//             <Card>
//               {!mdUp && <CardHeader title="Store Branding" />}

//               <Stack spacing={3} sx={{ p: 3 }}>
//                 <Stack spacing={1.5}>
//                   <Typography variant="subtitle2">Logo</Typography>
//                   <RHFUploadAvatar
//                     multiple
//                     thumbnail
//                     name="images"
//                     maxSize={3145728}
//                     // onDrop={handleDrop}
//                     // onRemove={handleRemoveFile}
//                     // onRemoveAll={handleRemoveAllFiles}
//                     onUpload={() => console.info('ON UPLOAD')}
//                   />
//                 </Stack>
//               </Stack>

//               <Stack spacing={3} sx={{ p: 3 }}>
//                 <Stack spacing={1.5}>
//                   <Typography variant="subtitle2">Primary Color</Typography>
//                   <MuiColorInput value={value} onChange={handleChange} />
//                 </Stack>
//               </Stack>
//             </Card>
//           </Grid>
//         </Grid>

//         <Grid sx={{ mt: 2 }} container spacing={3}>
//           {mdUp && (
//             <Grid md={4}>
//               <Typography variant="h6" sx={{ mb: 0.5 }}>
//                 Store Details
//               </Typography>
//               <Typography variant="body2" sx={{ color: 'text.secondary' }}>
//                 Upload all photos of your product
//               </Typography>
//             </Grid>
//           )}

//           <Grid xs={12} md={8}>
//             <Card>
//               {!mdUp && <CardHeader title="Your Branding" />}

//               <Box
//                 padding={3}
//                 rowGap={3}
//                 columnGap={2}
//                 display="grid"
//                 gridTemplateColumns={{
//                   xs: 'repeat(1, 1fr)',
//                   sm: 'repeat(2, 1fr)',
//                 }}
//               >
//                 <RHFTextField name="name" label="Store Name" />
//                 <RHFTextField name="email" label="Email Address" />
//                 <RHFTextField name="phoneNumber" label="Phone Number" />

//                 <RHFAutocomplete
//                   name="country"
//                   label="Country"
//                   // options={countries.map((country) => country.label)}
//                   getOptionLabel={(option) => option}
//                   isOptionEqualToValue={(option, value) => option === value}
//                   // renderOption={(props, option) => {
//                   //   const { code, label, phone } = countries.filter(
//                   //     (country) => country.label === option
//                   //   )[0];

//                   //   if (!label) {
//                   //     return null;
//                   //   }

//                   //   return (
//                   //     <li {...props} key={label}>
//                   //       <Iconify
//                   //         key={label}
//                   //         icon={`circle-flags:${code.toLowerCase()}`}
//                   //         width={28}
//                   //         sx={{ mr: 1 }}
//                   //       />
//                   //       {label} ({code}) +{phone}
//                   //     </li>
//                   //   );
//                   // }}
//                 />

//                 <RHFTextField name="state" label="State/Region" />
//                 <RHFTextField name="city" label="City" />
//                 <RHFTextField name="address" label="Address" />
//                 <RHFTextField name="zipCode" label="Zip/Code" />
//               </Box>
//             </Card>
//           </Grid>
//         </Grid>

//         <Grid sx={{ mt: 2 }} container spacing={3}>
//           {mdUp && (
//             <Grid md={4}>
//               <Typography variant="h6" sx={{ mb: 0.5 }}>
//                 Store Banner
//               </Typography>
//               <Typography variant="body2" sx={{ color: 'text.secondary' }}>
//                 Upload all photos of your product
//               </Typography>
//             </Grid>
//           )}

//           <Grid xs={12} md={8}>
//             <Card>
//               {!mdUp && <CardHeader title="Your Branding" />}

//               <Stack spacing={3} sx={{ p: 3 }}>
//                 <Stack spacing={1.5}>
//                   <Typography variant="subtitle2">Select 3 Photos</Typography>
//                   <RHFUpload
//                     multiple
//                     thumbnail
//                     name="images"
//                     maxSize={3145728}
//                     // onDrop={handleDrop}
//                     // onRemove={handleRemoveFile}
//                     // onRemoveAll={handleRemoveAllFiles}
//                     onUpload={() => console.info('ON UPLOAD')}
//                   />
//                 </Stack>
//               </Stack>
//             </Card>
//           </Grid>
//         </Grid>

//         <Grid sx={{ mt: 2 }} container spacing={3}>
//           {mdUp && (
//             <Grid md={4}>
//               <Typography variant="h6" sx={{ mb: 0.5 }}>
//                 Store Description
//               </Typography>
//               <Typography variant="body2" sx={{ color: 'text.secondary' }}>
//                 Upload all photos of your product
//               </Typography>
//             </Grid>
//           )}

//           <Grid xs={12} md={8}>
//             <Card>
//               {!mdUp && <CardHeader title="Your Branding" />}

//               <Stack spacing={3} sx={{ p: 3 }}>
//                 <Stack spacing={1.5}>
//                   <RHFEditor simple name="description" />
//                 </Stack>
//               </Stack>
//             </Card>
//           </Grid>
//         </Grid>

//         <Grid sx={{ mt: 2 }} container spacing={3}>
//           {mdUp && (
//             <Grid md={4}>
//               <Typography variant="h6" sx={{ mb: 0.5 }}>
//                 Social Media
//               </Typography>
//               <Typography variant="body2" sx={{ color: 'text.secondary' }}>
//                 Upload all photos of your product
//               </Typography>
//             </Grid>
//           )}

//           <Grid xs={12} md={8}>
//             <Card>
//               {!mdUp && <CardHeader title="Your Branding" />}

//               <Stack spacing={3} sx={{ p: 3 }}>
//                 <Stack spacing={1.5}>
//                   <Typography variant="subtitle2">Select 3 Photos</Typography>
//                   <RHFUpload
//                     multiple
//                     thumbnail
//                     name="images"
//                     maxSize={3145728}
//                     // onDrop={handleDrop}
//                     // onRemove={handleRemoveFile}
//                     // onRemoveAll={handleRemoveAllFiles}
//                     onUpload={() => console.info('ON UPLOAD')}
//                   />
//                 </Stack>
//               </Stack>
//             </Card>
//           </Grid>
//         </Grid>
//       </FormProvider>
//     </Container>
//   );
// }
