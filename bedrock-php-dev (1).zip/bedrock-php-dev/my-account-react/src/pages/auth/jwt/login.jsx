import { Helmet } from 'react-helmet-async';

import { WP_MY_ACCOUNT_BASE_URL } from 'src/config-global';

// ----------------------------------------------------------------------

export default function LoginPage() {
  window.parent.location.href = `${WP_MY_ACCOUNT_BASE_URL}/customer-logout`;

  return (
    <Helmet>
      <title>Login</title>
    </Helmet>
  );
}
