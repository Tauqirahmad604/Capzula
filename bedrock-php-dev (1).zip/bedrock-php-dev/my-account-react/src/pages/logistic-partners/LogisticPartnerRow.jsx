import PropTypes from 'prop-types';

import { Box } from '@mui/system';
import { Avatar, Typography } from '@mui/material';

function singleLineAddress(addressData) {
  // return 'test';
  if (!addressData) {
    return '';
  }

  // if (addressData?.business_name) {
  //   delete addressData?.business_name;
  // }
  // if (addressData?.country) {
  //   delete addressData?.country;
  // }

  // if (addressData?.state) {
  //   delete addressData.state;
  // }

  const addressArray = Object.values(addressData).filter((item) => item !== '');
  return addressArray.join(', ');
}

export default function LogisticPartnerRow({ businessData, showingInSummary = false }) {
  if (!businessData) {
    return null;
  }
  return (
    <Box sx={{ display: 'flex', alignItems: 'center' }}>
      {!showingInSummary && (
        <Avatar sx={{ width: 80, height: 80, mr: 2 }} src={businessData?.profile_photo} />
      )}
      <Box>
        <Typography fontWeight={500} variant="body2">
          {businessData?.business_details?.business_name}
        </Typography>
        <Typography variant="body2" fontSize={12}>
          <address>{singleLineAddress(businessData?.business_details?.address)}</address>
        </Typography>
      </Box>
    </Box>
  );
}

LogisticPartnerRow.propTypes = {
  businessData: PropTypes.object,
  showingInSummary: PropTypes.bool,
};
