import { Helmet } from 'react-helmet-async';
import { loadStripe } from '@stripe/stripe-js';
import { Elements } from '@stripe/react-stripe-js';

import { STRIPE_TOKEN } from 'src/config-global';

import AccountDeliveryAddress from 'src/sections/account/account-delivery-address';

// ----------------------------------------------------------------------

export default function DeliveryAddressPage() {
  const stripePromise = loadStripe(STRIPE_TOKEN); // Replace this in env
  const options = {
    mode: 'setup',
    currency: 'usd',
    // Fully customizable with appearance API.
    appearance: {
      /* ... */
    },
  };

  return (
    <>
      <Helmet>
        <title> Dashboard: Delivery Addresses</title>
      </Helmet>
      <Elements stripe={stripePromise} options={options}>
        <AccountDeliveryAddress />
      </Elements>
    </>
  );
}
