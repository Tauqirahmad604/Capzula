import { Helmet } from 'react-helmet-async';

import ChatView from 'src/sections/chat/view/chat-view';

// ----------------------------------------------------------------------

export default function Page() {
  return (
    <>
      <Helmet>
        <title>Chats</title>
      </Helmet>
      <ChatView />
    </>
  );
}
