import { Helmet } from 'react-helmet-async';

import { ProductCreateView } from 'src/sections/product-single/view';

// ----------------------------------------------------------------------

export default function CreateSingleProductPage() {
  return (
    <>
      <Helmet>
        <title>Create single product</title>
      </Helmet>
      <ProductCreateView />
    </>
  );
}
