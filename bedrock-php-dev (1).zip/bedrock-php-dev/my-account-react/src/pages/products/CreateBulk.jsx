import { Helmet } from 'react-helmet-async';

import ProductCreateBulkView from 'src/sections/product-bulk/view';

// ----------------------------------------------------------------------

export default function CreateBulkProductPage() {
  return (
    <>
      <Helmet>
        <title>Create bulk product</title>
      </Helmet>
      <ProductCreateBulkView />
    </>
  );
}
