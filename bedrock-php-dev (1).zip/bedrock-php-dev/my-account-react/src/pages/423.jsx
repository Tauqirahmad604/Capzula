import { Helmet } from 'react-helmet-async';

import { View423 } from 'src/sections/error';

// ----------------------------------------------------------------------

export default function LockedPage() {
  return (
    <>
      <Helmet>
        <title> You do not have access to this page</title>
      </Helmet>

      <View423 />
    </>
  );
}
