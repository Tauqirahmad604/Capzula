export const internalStatuses = {
  AWAITING_PAYMENT_TO_BANK: 'awaiting_payment_to_bank',
  PAYMENT_CONFIRMED_AT_BANK: 'payment_confirmed_at_bank',
  FUNDS_TRANSFERED_TO_PAYMENT_PARTNER: 'funds_transfered_to_payment_partner',
  FUNDS_RECIEVED: 'funds_recieved',
  PAID: 'paid',
};
export const internalStatusTitles = {
  [internalStatuses.AWAITING_PAYMENT_TO_BANK]: {
    admin: {
      current_status: 'Awaiting payment to Capzula Bank',
      next_action: 'Confirm payment has arrived',
    },
    logistics_partner: {
      current_status: 'Awaiting payment to Capzula Bank',
      next_action: null,
    },
  },
  [internalStatuses.PAYMENT_CONFIRMED_AT_BANK]: {
    admin: {
      current_status: 'Awaiting transfer of funds to Payment Partner',
      next_action: 'Confirm funds transfered',
    },
    logistics_partner: {
      current_status: 'Awaiting transfer of funds to Payment Partner',
      next_action: null,
    },
  },
  [internalStatuses.FUNDS_TRANSFERED_TO_PAYMENT_PARTNER]: {
    admin: {
      current_status: 'Awaiting Payment Partner to confirm funds received',
      next_action: null,
    },
    logistics_partner: {
      current_status: 'Awaiting confirmation of funds',
      next_action: 'Confirm funds received',
    },
  },
  [internalStatuses.FUNDS_RECIEVED]: {
    admin: {
      current_status: 'Awaiting Payment Partner to pay Seller',
      next_action: null,
    },
    logistics_partner: {
      current_status: 'Awaiting payment to Seller',
      next_action: 'Confirm payment to Seller',
    },
  },
  [internalStatuses.PAID]: {
    admin: {
      current_status: 'Paid',
      next_action: null,
    },
    logistics_partner: {
      current_status: 'Paid',
      next_action: null,
    },
  },
};

// First value of array is warning and secondary value is danger in days - every status will reset the clock
export const internalStatusDeadlines = {
  [internalStatuses.AWAITING_PAYMENT_TO_BANK]: [2, 3], // Capzula confirms payment arrived in bank
  [internalStatuses.PAYMENT_CONFIRMED_AT_BANK]: [0, 1], // Capzula transfers funds to payment partner
  [internalStatuses.FUNDS_TRANSFERED_TO_PAYMENT_PARTNER]: [2, 3], // Payment partner confirms funds received
  [internalStatuses.FUNDS_RECIEVED]: [0, 1], // payment partner pays the vendor
  [internalStatuses.PAID]: [false, false], // vendor receives payment
};

export function getInternalStatusTitlesByRole(status, role) {
  if (!status) {
    return '';
  }
  return internalStatusTitles[status][role]
    ? internalStatusTitles[status][role]
    : internalStatusTitles[status].admin;
}
