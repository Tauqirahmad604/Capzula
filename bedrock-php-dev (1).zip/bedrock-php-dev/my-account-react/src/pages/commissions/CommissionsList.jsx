import { useSnackbar } from 'notistack';
import { useNavigate } from 'react-router';
import { Helmet } from 'react-helmet-async';
import { useState, useEffect, useCallback } from 'react';

import Box from '@mui/material/Box';
import { Stack } from '@mui/system';
import Link from '@mui/material/Link';
import Card from '@mui/material/Card';
import Table from '@mui/material/Table';
import Avatar from '@mui/material/Avatar';
import Dialog from '@mui/material/Dialog';
import TableRow from '@mui/material/TableRow';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableHead from '@mui/material/TableHead';
import IconButton from '@mui/material/IconButton';
import DialogTitle from '@mui/material/DialogTitle';
import ListItemText from '@mui/material/ListItemText';
import DialogContent from '@mui/material/DialogContent';
import TableContainer from '@mui/material/TableContainer';
import {
  Button,
  Collapse,
  Checkbox,
  TextField,
  Typography,
  CardHeader,
  CardContent,
  TableSortLabel,
} from '@mui/material';
import {
  Timeline,
  TimelineDot,
  TimelineItem,
  LoadingButton,
  TimelineContent,
  TimelineConnector,
  TimelineSeparator,
  TimelineOppositeContent,
  timelineOppositeContentClasses,
} from '@mui/lab';

import { RouterLink } from 'src/routes/components';

import { fCurrency } from 'src/utils/format-number';
import { fDate, fDaysAgo, fDateTime } from 'src/utils/format-time';

import { useAuthContext } from 'src/auth/hooks';
import {
  useGetcommissionsQuery,
  useRefundCommissionMutation,
  useAddCommissionNoteMutation,
  useChangeCommissionStatusMutation,
} from 'src/redux/api/myAccount';

import Label from 'src/components/label';
import Iconify from 'src/components/iconify';
import { LoadingScreen } from 'src/components/loading-screen';
import { TableNoData, TablePaginationCustom } from 'src/components/table';

import TransactionsListView from 'src/sections/transactions/transactions-list';

import CommissionTabs from './commission-tabs';
import CommissionsFilters from './commissions-filters';
import CommissionsListRow from './commissions-list-row';
import CommissionsQuickSummary from './commissions-quick-summary';
import { internalStatuses, internalStatusDeadlines } from './constants';
import CommissionsInternalTimeline from './commissions-internal-timeline';

// ----------------------------------------------------------------------

export default function Page() {
  const navigate = useNavigate();
  const { user } = useAuthContext();

  const { enqueueSnackbar } = useSnackbar();

  const [addingNote, setAddingNote] = useState(false);
  const [newNote, setNewNote] = useState(null);
  const [pageNum, setPageNum] = useState(0);
  const [selectedCommission, setSelectedCommission] = useState(null);
  const [viewCommission, setViewCommission] = useState(false);
  const [openStatusChangeDialog, setOpenStatusChangeDialog] = useState(false);
  // const [newStatus, setNewStatus] = useState(null);
  const [orderby, setOrderby] = useState({
    field: 'created_at',
    order: 'desc',
  });
  // filters
  const [filteredStatus, setFilteredStatus] = useState('all');
  const [filteredPriority, setFilteredPriority] = useState('all');
  const [selectedCommissions, setSelectedCommissions] = useState([]);
  const [search, setSearch] = useState('');

  const [collapseNotes, setCollapseNotes] = useState(user.role !== 'admin');

  const [addCommissionNote, addCommissionNoteResult] = useAddCommissionNoteMutation();
  // const [processCommission, processCommissionResult] = useProcessCommissionMutation();
  const [refundCommissionResult] = useRefundCommissionMutation();
  const [changeCommissionStatus, changeCommissionStatusResult] =
    useChangeCommissionStatusMutation();

  const {
    data: response,
    isLoading,
    isFetching,
  } = useGetcommissionsQuery({
    pageNum,
    status: filteredStatus,
    priority: filteredPriority,
    orderby: orderby.field,
    order: orderby.order,
    search,
  });

  const handlePageChange = useCallback((event, page) => {
    setPageNum(page);
  }, []);

  const getLabel = (status) => {
    switch (status) {
      case 'paid':
        return <Label color="success">Paid</Label>;
      case 'cancelled':
        return <Label color="error">Cancelled</Label>;
      case 'unpaid':
        return <Label color="warning">Unpaid</Label>;
      case 'refunded':
        return <Label color="secondary"> Refunded </Label>;
      default:
        return status;
    }
  };

  const calculateTimeLapsed = (date, status) => {
    const numberOfDays = fDaysAgo(date);
    const warningLimit = internalStatusDeadlines[status][0];
    const dangerLimit = internalStatusDeadlines[status][1];

    if (dangerLimit === false && warningLimit === false) {
      return '';
    }
    if (numberOfDays >= dangerLimit) {
      return <Label color="error"> {numberOfDays} Days </Label>;
    }
    if (numberOfDays >= warningLimit) {
      return <Label color="warning"> {numberOfDays} Days </Label>;
    }

    return <Label> {numberOfDays} Days </Label>;
  };

  const handleClose = () => {
    setViewCommission(false);
    setSelectedCommission(null);
  };
  const handleAddNote = () => {
    if (!newNote) {
      enqueueSnackbar('Please add a note', { variant: 'error' });
      return;
    }

    addCommissionNote({
      id: selectedCommission?.order_id,
      body: {
        note: newNote,
      },
    });
  };

  useEffect(() => {
    if (addCommissionNoteResult.isSuccess) {
      enqueueSnackbar(addCommissionNoteResult?.data?.data, { variant: 'success' });
      setAddingNote(false);
      setNewNote(null);
      handleClose();
    }
    if (addCommissionNoteResult.isError) {
      enqueueSnackbar(addCommissionNoteResult?.error?.data?.data, { variant: 'error' });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [addCommissionNoteResult]);

  useEffect(() => {
    if (refundCommissionResult.isSuccess) {
      enqueueSnackbar(refundCommissionResult?.data?.data, { variant: 'success' });
    }
    if (refundCommissionResult.isError) {
      enqueueSnackbar(refundCommissionResult?.error?.data?.data, { variant: 'error' });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [refundCommissionResult]);

  const handleOpenChangeStatusDialog = (status) => {
    setOpenStatusChangeDialog(true);
  };
  const handleCloseChangeStatusDialog = () => {
    setSelectedCommissions([]);
    setOpenStatusChangeDialog(false);
    // setNewStatus(null);
  };

  const handleChangeCommissionStatus = (commissionIds) => {
    const commissionData = {
      body: {
        ids: commissionIds || selectedCommissions,
        status: filteredStatus,
      },
    };
    changeCommissionStatus(commissionData);
  };

  useEffect(() => {
    if (changeCommissionStatusResult.isSuccess) {
      enqueueSnackbar(changeCommissionStatusResult?.data?.data, { variant: 'success' });
      handleCloseChangeStatusDialog();
    }
    if (changeCommissionStatusResult.isError) {
      enqueueSnackbar(changeCommissionStatusResult?.error?.data?.data, { variant: 'error' });
      handleCloseChangeStatusDialog();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [changeCommissionStatusResult]);

  const allowBulkActions = () => {
    if (user.role === 'admin') {
      switch (filteredStatus) {
        case internalStatuses.AWAITING_PAYMENT_TO_BANK:
          return true;
        case internalStatuses.PAYMENT_CONFIRMED_AT_BANK:
          return true;
        default:
          return false;
      }
    }

    if (user.role === 'payment_partner') {
      switch (filteredStatus) {
        case internalStatuses.FUNDS_TRANSFERED_TO_PAYMENT_PARTNER:
          return true;
        case internalStatuses.FUNDS_RECIEVED:
          return true;
        default:
          return false;
      }
    }
    return false;
  };

  // Filters

  const handleOrderby = (field, order) => {
    setOrderby({
      field,
      order,
    });
  };

  const getCommissionTotal = (commission) => {
    let total = 0;
    const currentCommission = commission || selectedCommission;
    total += parseFloat(currentCommission.amount)
    total -= parseFloat(currentCommission.refunds_recovered)
    return total;
  }

  return (
    <>
      <Helmet>
        <title> Commissions </title>
      </Helmet>

      <Stack
        spacing={3}
        direction={{ xs: 'column', md: 'row' }}
        sx={{
          mb: { xs: 3, md: 5 },
        }}
      >
        <Stack spacing={1} direction="row" alignItems="flex-start">
          <IconButton component={RouterLink} onClick={() => navigate(-1)}>
            <Iconify icon="eva:arrow-ios-back-fill" />
          </IconButton>

          <Stack spacing={0.5}>
            <Stack spacing={1} direction="row" alignItems="center">
              <Typography variant="h4"> Payouts </Typography>
            </Stack>
          </Stack>
        </Stack>
      </Stack>

      <Card>
        {user.role !== 'vendor' && (
          <CommissionTabs
            role={user.role}
            status={filteredStatus}
            setStatus={(value) => setFilteredStatus(value)}
            setSelectedCommissions={(value) => setSelectedCommissions(value)}
            commissionCount={response?.data?.commission_count}
            isLoading={isLoading || isFetching}
          />
        )}
        {user.role !== 'vendor' && (
          <CommissionsFilters
            priority={filteredPriority}
            setPriority={(value) => setFilteredPriority(value)}
            search={search}
            setSearch={(value) => setSearch(value)}
          />
        )}

        {user.role === 'payment_partner' &&
          filteredStatus === internalStatuses.FUNDS_TRANSFERED_TO_PAYMENT_PARTNER ? (
          <TransactionsListView
            showTitle={false}
            showApproval
            handleProceed={(value) => handleChangeCommissionStatus(value)}
            isLoading={changeCommissionStatusResult?.isLoading}
            transactionType="payout"
          />
        ) : (
          <TableContainer>
            <Table sx={{ minWidth: 650 }} aria-label="simple table">
              <TableHead>
                <TableRow>
                  {filteredStatus !== 'all' &&
                    filteredStatus !== 'paid' &&
                    (user.role === 'admin' || user.role === 'payment_partner') &&
                    allowBulkActions() && (
                      <TableCell>
                        <Checkbox
                          onClick={(e) => {
                            if (e.target.checked) {
                              setSelectedCommissions(
                                response?.data?.commissions.map((commission) => commission.id)
                              );
                            } else {
                              setSelectedCommissions([]);
                            }
                          }}
                          checked={
                            selectedCommissions.length === response?.data?.commissions.length
                          }
                        />
                      </TableCell>
                    )}
                  <TableCell>
                    <TableSortLabel
                      active
                      direction={orderby.field === 'created_at' ? orderby.order : 'desc'}
                      onClick={() =>
                        handleOrderby('created_at', orderby.order === 'asc' ? 'desc' : 'asc')
                      }
                    >
                      Date
                    </TableSortLabel>
                  </TableCell>
                  <TableCell>Order</TableCell>
                  <TableCell>Vendor</TableCell>
                  <TableCell>Fees</TableCell>
                  <TableCell>Amount</TableCell>
                  {user.role === 'admin' && (
                    <TableCell>Order Amount</TableCell>
                  )}
                  {(user.role === 'admin' || user.role === 'payment_partner') && (
                    <TableCell>
                      <TableSortLabel
                        active
                        direction={orderby.field === 'updated_at' ? orderby.order : 'desc'}
                        onClick={() =>
                          handleOrderby('updated_at', orderby.order === 'asc' ? 'desc' : 'asc')
                        }
                      >
                        Time Lapsed
                      </TableSortLabel>
                    </TableCell>
                  )}
                  {(user.role === 'admin' || user.role === 'payment_partner') && (
                    <TableCell>Internal Status</TableCell>
                  )}
                  <TableCell>Status</TableCell>
                  <TableCell>Progress</TableCell>
                  <TableCell />
                </TableRow>
              </TableHead>
              <TableBody
                sx={{
                  pt: 5,
                  borderBottom: '2px solid #e6e6e6',
                }}
              >
                {isLoading || isFetching ? (
                  <TableRow>
                    <TableCell colSpan={100}>
                      <LoadingScreen />
                    </TableCell>
                  </TableRow>
                ) : (
                  <>
                    {response?.data?.commissions &&
                      response?.data?.commissions.map((row, i) => (
                        <CommissionsListRow
                          row={row}
                          status={filteredStatus}
                          setCommission={(value) => setSelectedCommission(value)}
                          setViewCommission={() => setViewCommission(true)}
                          getLabel={(value) => getLabel(value)}
                          getTimeLapsed={(value, status) => calculateTimeLapsed(value, status)}
                          selectedCommissions={selectedCommissions}
                          setSelectedCommissions={(value) => setSelectedCommissions(value)}
                          allowBulkActions={allowBulkActions()}
                          getCommissionTotal={(commission) => getCommissionTotal(commission)}
                        />
                      ))}
                  </>
                )}
                <TableNoData notFound={response?.data?.commissions?.length <= 0} />
              </TableBody>
            </Table>
            <Stack
              direction="row"
              alignItems="center"
              justifyContent={selectedCommissions.length > 0 ? 'space-between' : 'flex-end'}
            >
              {selectedCommissions.length > 0 && (
                <Stack direction="row" alignItems="center" spacing={2} sx={{ px: 2 }}>
                  <Typography variant="subtitle2">{selectedCommissions.length} selected</Typography>
                  <Button
                    variant="contained"
                    color="secondary"
                    onClick={() => handleOpenChangeStatusDialog()}
                  >
                    Proceed
                  </Button>
                </Stack>
              )}
              <TablePaginationCustom
                count={response?.data?.total_pages}
                page={pageNum}
                rowsPerPageOptions={false}
                rowsPerPage={response?.data?.items_per_page}
                onPageChange={handlePageChange}
              />
            </Stack>
          </TableContainer>
        )}
      </Card>

      <Dialog fullWidth maxWidth="sm" open={viewCommission} onClose={() => handleClose()}>
        <DialogTitle sx={{ pb: 1 }}>
          <Stack flexDirection="row" alignItems="start" justifyContent="space-between">
            <Stack>
              Payout for Order #{selectedCommission?.order_id}
              <Typography variant="subtitle2">
                Created on {fDate(selectedCommission?.created_at)}
              </Typography>
            </Stack>
            <Stack>
              <Box sx={{ ml: 3, mb: 1 }}>{getLabel(selectedCommission?.status)}</Box>
            </Stack>
          </Stack>
        </DialogTitle>
        <DialogContent sx={{ pb: 3 }}>
          <Card>
            <CardContent sx={{ p: 2, display: 'flex', flexDirection: 'column', gap: '10px' }}>
              {selectedCommission?.product.map((product, i) => (
                <Stack flexDirection="row" alignItems="center" key={i}>
                  <Avatar
                    alt={product?.name}
                    src={product?.image}
                    variant="rounded"
                    sx={{ width: 64, height: 64, mr: 2 }}
                  />

                  <ListItemText
                    width="100%"
                    disableTypography
                    primary={
                      <Link
                        noWrap
                        color="inherit"
                        variant="subtitle2"
                        onClick={() => window.open(product?.permalink, '_blank')}
                        sx={{ cursor: 'pointer' }}
                      >
                        {product?.name}
                      </Link>
                    }
                    secondary={
                      <Box component="div" sx={{ typography: 'body2', color: 'text.disabled' }}>
                        {product?.sku}
                      </Box>
                    }
                  />
                </Stack>
              ))}
            </CardContent>
          </Card>

          <Box sx={{ justifyContent: 'end', display: 'flex' }}>
            <Table sx={{ maxWidth: '300px' }}>
              <TableBody>
                <TableRow>
                  <TableCell sx={{ textAlign: 'left', mt: 2 }}>
                    <strong>Order Amount</strong>
                  </TableCell>
                  <TableCell sx={{ textAlign: 'right' }}>
                    {selectedCommission?.original_amount
                      ? fCurrency(selectedCommission?.original_amount)
                      : fCurrency('0')}
                  </TableCell>
                </TableRow>

                <TableRow>
                  <TableCell sx={{ textAlign: 'left', mt: 2 }}>
                    <strong>Total Fees</strong>
                  </TableCell>
                  <TableCell sx={{ textAlign: 'right', color: 'error.main' }}>
                    {/* eslint-disable-next-line no-unsafe-optional-chaining */}
                    - {fCurrency(selectedCommission?.original_amount - selectedCommission?.amount)}
                  </TableCell>
                </TableRow>

                <TableRow>
                  <TableCell sx={{ textAlign: 'left', mt: 2 }}>
                    <strong>Payout Amount</strong>
                  </TableCell>
                  <TableCell sx={{ textAlign: 'right' }}>
                    {selectedCommission?.amount
                      ? fCurrency(selectedCommission.amount)
                      : fCurrency('0')}
                  </TableCell>
                </TableRow>
                {selectedCommission?.refunds_recovered > 0 && (
                  <TableRow>
                    <TableCell sx={{ textAlign: 'left', mt: 2 }}>
                      <strong>Refunds Recovered</strong>
                    </TableCell>
                    <TableCell sx={{ textAlign: 'right', color: 'error.main' }}>
                      - {selectedCommission?.refunds_recovered ? fCurrency(selectedCommission?.refunds_recovered) : fCurrency('0')}
                    </TableCell>
                  </TableRow>
                )}
                <TableRow>
                  <TableCell sx={{ textAlign: 'left', mt: 2 }}>
                    <strong>Payout Available</strong>
                  </TableCell>
                  <TableCell sx={{ textAlign: 'right' }}>
                    {selectedCommission?.amount
                      ? fCurrency(getCommissionTotal())
                      : fCurrency('0')}
                  </TableCell>
                </TableRow>
              </TableBody>
            </Table>
          </Box>

          {(user.role === 'admin' || user.role === 'payment_partner') && (
            <CommissionsInternalTimeline commission={selectedCommission} />
          )}

          <Card sx={{ mt: 3, p: 2 }}>
            <Stack
              flexDirection="row"
              alignItems="center"
              justifyContent="space-between"
              sx={collapseNotes && { mb: 2 }}
            >
              <CardHeader title="Notes" sx={{ p: 0 }} />
              <Stack flexDirection="row" spacing={1}>
                {collapseNotes && user.role !== 'vendor' && (
                  <LoadingButton
                    disabled={addCommissionNoteResult.isLoading || isFetching}
                    variant={addingNote ? 'outlined' : 'contained'}
                    color={addingNote ? 'error' : 'primary'}
                    onClick={() => setAddingNote(!addingNote)}
                  >
                    {' '}
                    {addingNote ? 'Cancel' : 'Add Note'}{' '}
                  </LoadingButton>
                )}
                <IconButton onClick={() => setCollapseNotes(!collapseNotes)}>
                  <Iconify icon="eva:arrow-ios-downward-fill" />
                </IconButton>
              </Stack>
            </Stack>
            {addingNote && (
              <Stack justifyContent="flex-end" spacing={2} sx={{ mb: 2 }}>
                <TextField
                  multiline
                  rows={5}
                  fullWidth
                  value={newNote}
                  onChange={(e) => setNewNote(e.target.value)}
                />
                <LoadingButton
                  variant="contained"
                  color="primary"
                  onClick={() => handleAddNote()}
                  loading={addCommissionNoteResult.isLoading || isFetching}
                >
                  Add Note
                </LoadingButton>
              </Stack>
            )}

            <Collapse in={collapseNotes}>
              <Timeline
                sx={{
                  [`& .${timelineOppositeContentClasses.root}`]: {
                    flex: '0.2',
                    paddingLeft: 0,
                  },
                  padding: 0,
                }}
              >
                {selectedCommission?.notes?.map((note, index) => (
                  <TimelineItem key={index} sx={{ minHeight: 'auto' }}>
                    <TimelineOppositeContent align="right" color="gray" fontSize={12}>
                      {fDateTime(note.date)}
                    </TimelineOppositeContent>
                    <TimelineSeparator>
                      <TimelineDot color="primary" />
                      <TimelineConnector />
                    </TimelineSeparator>
                    <TimelineContent fontSize={14}>{note.note}</TimelineContent>
                  </TimelineItem>
                ))}
              </Timeline>
            </Collapse>
          </Card>
        </DialogContent>
      </Dialog>

      {openStatusChangeDialog && (
        <CommissionsQuickSummary
          open={openStatusChangeDialog}
          onClose={() => handleCloseChangeStatusDialog()}
          commissions={response?.data?.commissions}
          selectedCommissions={selectedCommissions}
          status={filteredStatus}
          setNote={(value) => setNewNote(value)}
          handleProceed={(value) => handleChangeCommissionStatus(value)}
          isLoading={changeCommissionStatusResult?.isLoading}
        />
      )}
    </>
  );
}
