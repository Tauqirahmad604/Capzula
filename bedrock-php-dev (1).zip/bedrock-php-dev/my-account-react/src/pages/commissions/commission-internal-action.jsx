import PropTypes from 'prop-types';

import { Stack } from '@mui/system';
import { Typography } from '@mui/material';
import { alpha, useTheme } from '@mui/material/styles';

import { bgGradient } from 'src/theme/css';
import { useAuthContext } from 'src/auth/hooks';

import { internalStatuses, getInternalStatusTitlesByRole } from './constants';

// -----------------------------------------------

export default function CommissionInternalAction({ id, status, nextStatus, ...other }) {
  const { user } = useAuthContext();
  const theme = useTheme();
  const getDescription = () => {
    switch (status) {
      case internalStatuses.AWAITING_PAYMENT_TO_BANK:
        return 'This order has been charged. Payment is being processed to the Capzula bank account, awaiting for Capzula to confirm payment';
      case internalStatuses.PAYMENT_CONFIRMED_AT_BANK:
        return 'Payment has been confirmed at the bank. Funds are to be transferred to the payment partner, confirm transfer of payment';
      case internalStatuses.FUNDS_TRANSFERED_TO_PAYMENT_PARTNER:
        return "Funds have been transferred to the payment partner's account. Payment partner to confirm reciept of payment";
      case internalStatuses.FUNDS_RECIEVED:
        return 'Funds have been received by the payment partner. Payment partner has to pay the vendor, confirm once payment has been made to the vendor';
      case internalStatuses.PAID:
        return 'Payment has been made to the vendor no further action is required';
      default:
        return '';
    }
  };

  return (
    <Stack
      flexDirection={{ xs: 'column', md: 'row' }}
      sx={{
        ...bgGradient({
          direction: '135deg',
          startColor: alpha(theme.palette.primary.light, 0.2),
          endColor: alpha(theme.palette.primary.main, 0.3),
        }),
        height: { md: 1 },
        borderRadius: 1,
        padding: 2,
        gap: 3,
        alignItems: 'center',
        justifyContent: 'center',
        position: 'relative',
        color: 'common.black',
        backgroundColor: 'common.white',
      }}
      {...other}
    >
      <Stack flex={1}>
        <Typography variant="subtitle1" sx={{ mb: 1, whiteSpace: 'pre-line' }}>
          {getInternalStatusTitlesByRole(status, user.role).current_status}
        </Typography>
        <Typography variant="body2" sx={{ opacity: 0.8 }}>
          {getDescription()}
        </Typography>
      </Stack>
    </Stack>
  );
}

CommissionInternalAction.propTypes = {
  id: PropTypes.string,
  status: PropTypes.string,
  nextStatus: PropTypes.string,
};
