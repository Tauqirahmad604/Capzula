import { useState } from 'react';
import PropTypes from 'prop-types';

import { Stack } from '@mui/system';
// eslint-disable-next-line perfectionist/sort-named-imports
import { Card, CardHeader, Collapse, IconButton } from '@mui/material';
import TimelineOppositeContent, {
  timelineOppositeContentClasses,
} from '@mui/lab/TimelineOppositeContent';
import {
  Timeline,
  TimelineDot,
  TimelineItem,
  TimelineContent,
  TimelineConnector,
  TimelineSeparator,
} from '@mui/lab';

import { fDaysAgo, fDateTime } from 'src/utils/format-time';

import Label from 'src/components/label';
import Iconify from 'src/components/iconify';

import { internalStatusDeadlines } from './constants';
import CommissionInternalAction from './commission-internal-action';

export default function CommissionsInternalTimeline({ commission }) {
  const [collapse, setCollapse] = useState(false);

  const getTimeLapsed = (date, status) => {
    const numberofdays = fDaysAgo(date);
    const warningLimit = internalStatusDeadlines[status]
      ? internalStatusDeadlines[status][0]
      : false;
    const dangerLimit = internalStatusDeadlines[status]
      ? internalStatusDeadlines[status][1]
      : false;

    if (dangerLimit === false && warningLimit === false) {
      return '';
    }
    if (numberofdays >= dangerLimit) {
      return <Label color="error"> {numberofdays} Days passed - Overdue</Label>;
    }
    if (numberofdays >= warningLimit) {
      return <Label color="warning"> {numberofdays} Days passed - Due Today </Label>;
    }

    return <Label> {numberofdays} Days passed - On track</Label>;
  };

  return (
    <Card sx={{ mt: 3, p: 2 }}>
      <Stack flexDirection="row" alignItems="center" justifyContent="space-between" sx={{ mb: 2 }}>
        <CardHeader title="Internal Status" sx={{ p: 0 }} />
        <Stack flexDirection="row" spacing={1} alignItems="center">
          {getTimeLapsed(commission?.updated_at, commission?.internal_status)}
          <IconButton onClick={() => setCollapse(!collapse)}>
            <Iconify icon="eva:arrow-ios-downward-fill" />
          </IconButton>
        </Stack>
      </Stack>
      <Stack>
        <CommissionInternalAction id={commission?.order_id} status={commission?.internal_status} />
        {commission?.internal_notes?.length > 0 && (
          <Collapse in={collapse}>
            <Timeline
              sx={{
                [`& .${timelineOppositeContentClasses.root}`]: {
                  flex: '0.2',
                  paddingLeft: 0,
                },
                padding: 0,
              }}
            >
              {commission?.internal_notes?.map((note, index) => (
                <TimelineItem key={index} sx={{ minHeight: 'auto' }}>
                  <TimelineOppositeContent align="right" color="gray" fontSize={12}>
                    {fDateTime(note.date)}
                  </TimelineOppositeContent>
                  <TimelineSeparator>
                    <TimelineDot color="primary" />
                    <TimelineConnector />
                  </TimelineSeparator>
                  <TimelineContent fontSize={14}>{note.note}</TimelineContent>
                </TimelineItem>
              ))}
            </Timeline>
          </Collapse>
        )}
      </Stack>
    </Card>
  );
}

CommissionsInternalTimeline.propTypes = {
  commission: PropTypes.object,
};
