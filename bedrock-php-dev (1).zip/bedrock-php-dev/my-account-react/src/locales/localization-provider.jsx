import { useEffect } from 'react';
import PropTypes from 'prop-types';

import { AdapterDateFns } from '@mui/x-date-pickers/AdapterDateFns';
import { LocalizationProvider as MuiLocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';

import { useAuthContext } from 'src/auth/hooks';

import { useLocales, useTranslate } from './use-locales';

// ----------------------------------------------------------------------

export default function LocalizationProvider({ children }) {
  const { user } = useAuthContext();
  const { currentLang } = useLocales();
  const { onChangeLang } = useTranslate();

  useEffect(() => {
    if (user?.lang) {
      onChangeLang(user.lang);
    }
  }, [onChangeLang, user]);
  return (
    <MuiLocalizationProvider dateAdapter={AdapterDateFns} adapterLocale={currentLang.adapterLocale}>
      {children}
    </MuiLocalizationProvider>
  );
}

LocalizationProvider.propTypes = {
  children: PropTypes.node,
};
