import { format as formatDate } from 'date-fns';
import { useMemo, useCallback as useCallBack } from 'react';

import uuidv4 from 'src/utils/uuidv4';

import { useAuthContext } from 'src/auth/hooks';
import { useSupabaseContext } from 'src/supabase/hooks';
import { publishedStatus as pStatus } from 'src/lib/constants';

const nowDate = () => {
  const date = new Date();
  const now_utc = Date.UTC(
    date.getUTCFullYear(),
    date.getUTCMonth(),
    date.getUTCDate(),
    date.getUTCHours(),
    date.getUTCMinutes(),
    date.getUTCSeconds()
  );

  return new Date(now_utc).toISOString();
};

export const useDraftProduct = () => {
  const { user } = useAuthContext();
  const { makeAPICall } = useSupabaseContext();

  const updateCollectionName = useCallBack(
    async (collectionId, name) => {
      if (!name) {
        return { error: 'Name is required' };
      }

      try {
        const { data, error } = await makeAPICall((dbClient) =>
          dbClient
            .from('draft_products_collections')
            .update({ name })
            .eq('id', collectionId)
            .eq('vendor_id', user.vendor_id)
            .select('name')
        );

        if (error) {
          console.error(error);
          return { error };
        }
        return { data };
      } catch (error) {
        console.error(error);
        return { error };
      }
    },
    [makeAPICall, user.vendor_id]
  );

  const getUserDraftProductCollections = useCallBack(
    async ({ publishedStatus }) => {
      const statuses = {
        draft: [pStatus.DRAFT, pStatus.PROCESSING, pStatus.PARTIALLY_PUBLISHED, pStatus.FAILED],
        published: [pStatus.PUBLISHED, pStatus.PARTIALLY_PUBLISHED],
      };

      const { data, error } = await makeAPICall((dbClient) =>
        dbClient
          .from('draft_products_collections')
          .select('id, name, published_status, updated_at')
          .eq('vendor_id', user.vendor_id)
          .eq('status', 'active')
          .in('published_status', statuses[publishedStatus])
          .order('updated_at', { ascending: false })
      );

      if (error) {
        console.error(error);
        return { error };
      }

      return { data };
    },
    [makeAPICall, user.vendor_id]
  );

  const getDraftProductCollection = useCallBack(
    async (collectionId) => {
      const { data, error } = await makeAPICall((dbClient) =>
        dbClient
          .from('draft_products_collections')
          .select('id, name, published_status, updated_at')
          .eq('vendor_id', user.vendor_id)
          .eq('id', collectionId)
          .eq('status', 'active')
      );

      if (error) {
        console.error(error);
        return { error };
      }

      return { data: data[0] };
    },
    [makeAPICall, user.vendor_id]
  );

  const getDraftProducts = useCallBack(
    async (collectionId) => {
      const { data, error } = await makeAPICall((dbClient) =>
        dbClient
          .from('draft_products')
          .select('*')
          .eq('draft_products_collections_id', collectionId)
          .eq('vendor_id', user.vendor_id)
      );

      if (error) {
        console.error(error);
        return { error };
      }

      return { data };
    },
    [makeAPICall, user.vendor_id]
  );

  const listProductImages = useCallBack(
    async (itemId, saveLocation) => {
      const { data, error } = await makeAPICall((dbClient) =>
        dbClient.storage.from(saveLocation).list(`${user.vendor_id}/${itemId}`)
      );

      if (error) {
        console.error(error);
        return { error };
      }

      const dataWithPublicUrl = await Promise.all(
        data.map(async (image) => {
          const { data: urlData } = await makeAPICall((dbClient) =>
            dbClient.storage
              .from(saveLocation)
              .getPublicUrl(`${user.vendor_id}/${itemId}/${image.name}`)
          );

          return {
            ...image,
            publicUrl: urlData.publicUrl,
          };
        })
      );

      return { data: dataWithPublicUrl };
    },
    [makeAPICall, user.vendor_id]
  );

  const uploadImage = useCallBack(
    async ({ file, filename, saveLocation, itemId }) => {
      const fileExtension = file.name.split('.').pop();
      const activeFileName = filename || `${uuidv4()}.${fileExtension}`;
      const uploadPath = `${user.vendor_id}/${itemId}/${activeFileName}`;

      const { data, error } = await makeAPICall((dbClient) =>
        dbClient.storage.from(saveLocation).upload(uploadPath, file, {
          cacheControl: '3600',
          upsert: false,
        })
      );

      if (error) {
        console.error(error);
        return { error };
      }

      const { data: urlData } = await makeAPICall((dbClient) =>
        dbClient.storage.from(saveLocation).getPublicUrl(data.path)
      );

      return {
        source: urlData.publicUrl,
        name: uploadPath,
      };
    },
    [makeAPICall, user.vendor_id]
  );

  const deleteImages = useCallBack(async (filenames) => {
    if (!Array.isArray(filenames)) return { data: [] };

    if (filenames.length === 0) return { data: [] };

    const { data, error } = await makeAPICall((dbClient) =>
      dbClient.storage.from('products').remove(filenames)
    );

    if (error) {
      console.error(error);
      return { error };
    }

    return { data };
  }, []);

  const createDraftProductsCollection = useCallBack(
    async (collectionId, draftName) => {
      let currentId = collectionId;
      let name = {};

      if (!currentId) {
        currentId = uuidv4();
        name = { name: `draft-${formatDate(new Date(), 'dd-MM-yyyy HH:mm:ss')}` };
      } else {
        name = { name: draftName };
      }

      const { data, error } = await makeAPICall((dbClient) =>
        dbClient
          .from('draft_products_collections')
          .upsert({
            id: currentId,
            vendor_id: user.vendor_id,
            user_id: user.id,
            published_status: 'draft',
            ...name,
            updated_at: nowDate(),
          })
          .select('*')
      );

      if (error) {
        console.error(error);
        return { error };
      }

      return { data: data[0] };
    },
    [makeAPICall, user.id, user.vendor_id]
  );

  const archiveDraftProductsCollection = useCallBack(
    async (collectionId) => {
      const { data, error } = await makeAPICall((dbClient) =>
        dbClient
          .from('draft_products_collections')
          .update({ status: 'archived', updated_at: nowDate() })
          .eq('id', collectionId)
          .eq('vendor_id', user.vendor_id)
          .select('*')
      );

      if (error) {
        console.error(error);
        return { error };
      }

      return { data: data[0] };
    },
    [makeAPICall, user.vendor_id]
  );

  const saveDraftProducts = useCallBack(
    async (collectionId, products) => {
      const { data: collection, error: collectionError } =
        await createDraftProductsCollection(collectionId);

      if (collectionError) {
        console.error(collectionError);
        return { error: collectionError };
      }

      const productRows = products.map((product) => ({
        id: product.guid,
        draft_products_collections_id: collection.id,
        user_id: user.id,
        vendor_id: user.vendor_id,
        product_data: product,
        updated_at: nowDate(),
      }));

      const { error } = await makeAPICall((dbClient) =>
        dbClient.from('draft_products').upsert(productRows)
      );

      if (error) {
        console.error(error);
        return { error };
      }

      return { data: { id: collection.id } };
    },
    [createDraftProductsCollection, makeAPICall, user.id, user.vendor_id]
  );

  const deleteDraftProduct = useCallBack(async (collectionId, productId) => {
    const { error } = await makeAPICall((dbClient) =>
      dbClient
        .from('draft_products')
        .delete()
        .eq('vendor_id', user.vendor_id)
        .eq('draft_products_collections_id', collectionId)
        .eq('id', productId)
    );

    if (error) {
      console.error(error);
      return { error };
    }

    return { data: { id: productId } };
  });

  const data = useMemo(
    () => ({
      listProductImages,
      uploadImage,
      deleteImages,
      getUserDraftProductCollections,
      getDraftProductCollection,
      getDraftProducts,
      saveDraftProducts,
      updateCollectionName,
      deleteDraftProduct,
      archiveDraftProductsCollection,
    }),
    [
      listProductImages,
      uploadImage,
      deleteImages,
      getDraftProductCollection,
      getDraftProducts,
      getUserDraftProductCollections,
      saveDraftProducts,
      updateCollectionName,
      deleteDraftProduct,
      archiveDraftProductsCollection,
    ]
  );

  return data;
};

export default useDraftProduct;
