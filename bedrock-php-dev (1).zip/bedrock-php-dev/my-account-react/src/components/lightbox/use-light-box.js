import { useState, useCallback } from 'react';

// ----------------------------------------------------------------------

export default function useLightBox() {
  const [selected, setSelected] = useState(-1);
  const [slides, setSlides] = useState([]);

  const handleOpen = useCallback(
    (slideUrl) => {
      const slideIndex = slides.findIndex((slide) =>
        slide.type === 'video' ? slide.poster === slideUrl : slide.src === slideUrl
      );

      setSelected(slideIndex);
    },
    [slides]
  );

  const handleClose = useCallback(() => {
    setSelected(-1);
  }, []);

  const addToSlides = useCallback((slide) => {
    setSlides((prev) => {
      const isExist = prev.find((item) => item.src === slide.src);
      if (isExist) {
        return prev;
      }
      return [...prev, slide];
    });
  }, []);

  return {
    selected,
    open: selected >= 0,
    slides,
    addToSlides,
    onOpen: handleOpen,
    onClose: handleClose,
    setSelected,
  };
}
