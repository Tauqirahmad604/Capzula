import React from 'react';
import PropTypes from 'prop-types';
import { CardExpiryElement } from '@stripe/react-stripe-js';
import { Controller, useFormContext } from 'react-hook-form';

import TextField from '@mui/material/TextField';

const RHFCardExpiryField = ({ name, helperText, ...other }) => {
  const { control } = useFormContext();

  return (
    <Controller
      name={name}
      control={control}
      render={({ field, fieldState: { error } }) => (
        <TextField
          {...field}
          fullWidth
          error={!!error}
          helperText={error ? error.message : helperText}
          InputProps={{
            inputComponent: CardExpiryElement,
            inputProps: {
              options: {
                style: {
                  base: {
                    fontSize: '16px',
                    color: '#424770',
                    '::placeholder': {
                      color: 'rgba(0,0,0,0)',
                    },
                  },
                  invalid: {
                    color: '#FF5630',
                  },
                },
              },
            },
          }}
          {...other}
        />
      )}
    />
  );
};

RHFCardExpiryField.propTypes = {
  name: PropTypes.string.isRequired,
  helperText: PropTypes.node,
};

export default RHFCardExpiryField;