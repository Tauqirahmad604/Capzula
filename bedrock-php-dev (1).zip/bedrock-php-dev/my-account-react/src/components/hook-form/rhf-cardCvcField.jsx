// src/RHFCardCvcField.js
import React from 'react';
import PropTypes from 'prop-types';
import { CardCvcElement } from '@stripe/react-stripe-js';
import { Controller, useFormContext } from 'react-hook-form';

import TextField from '@mui/material/TextField';

const RHFCardCvcField = ({ name, helperText, ...other }) => {
  const { control } = useFormContext();

  return (
    <Controller
      name={name}
      control={control}
      render={({ field, fieldState: { error } }) => (
        <TextField
          {...field}
          fullWidth
          error={!!error}
          helperText={error ? error.message : helperText}
          InputProps={{
            inputComponent: CardCvcElement,
            inputProps: {
              options: {
                style: {
                  base: {
                    fontSize: '16px',
                    color: '#424770',
                    '::placeholder': {
                      color: 'rgba(0,0,0,0)',
                    },
                  },
                  invalid: {
                    color: '#FF5630',
                  },
                },
              },
            },
          }}
          {...other}
        />
      )}
    />
  );
};

RHFCardCvcField.propTypes = {
  name: PropTypes.string.isRequired,
  helperText: PropTypes.node,
};

export default RHFCardCvcField;