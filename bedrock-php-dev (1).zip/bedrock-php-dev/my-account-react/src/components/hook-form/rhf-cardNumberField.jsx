
import PropTypes from 'prop-types';
import React, { useState } from 'react';
import { CardNumberElement } from '@stripe/react-stripe-js';
import { Controller, useFormContext } from 'react-hook-form';

import TextField from '@mui/material/TextField';
import InputAdornment from '@mui/material/InputAdornment';

import Iconify from '../iconify';


const cardBrandToIcon = {
    visa: <Iconify icon="logos:visa" width={36} />,
    mastercard: <Iconify icon="logos:mastercard" width={36} />,
    amex: <Iconify icon="logos:amex" width={36} />,
    unknown: <Iconify icon="logos:credit-card" width={36} />,
};

const RHFCardNumberField = ({ name, helperText, ...other }) => {
    const { control } = useFormContext();
    const [cardBrand, setCardBrand] = useState('unknown');

    const handleCardNumberChange = (event) => {
        setCardBrand(event.brand || 'unknown');
    };

    return (
        <Controller
            name={name}
            control={control}
            render={({ field, fieldState: { error } }) => (
                <TextField
                    {...field}
                    fullWidth
                    error={!!error}
                    helperText={error ? error.message : helperText}
                    InputProps={{
                        startAdornment: (
                            <InputAdornment position="start">
                                {cardBrandToIcon[cardBrand]}
                            </InputAdornment>
                        ),
                        inputComponent: CardNumberElement,
                        inputProps: {
                            options: {
                                style: {
                                    base: {
                                        fontSize: '16px',
                                        color: '#424770',
                                        '::placeholder': {
                                            color: 'rgba(0,0,0,0)',
                                        },
                                    },
                                    invalid: {
                                        color: '#FF5630',
                                    },
                                },
                            },
                            // Listen for changes in the card number element
                            onChange: handleCardNumberChange,
                        },
                    }}
                    {...other}
                />
            )}
        />
    );
};

RHFCardNumberField.propTypes = {
    name: PropTypes.string.isRequired,
    helperText: PropTypes.node,
};

export default RHFCardNumberField;