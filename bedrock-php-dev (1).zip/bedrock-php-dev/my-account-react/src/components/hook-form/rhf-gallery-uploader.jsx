import PropTypes from 'prop-types';
import { Controller, useFormContext } from 'react-hook-form';

import FormHelperText from '@mui/material/FormHelperText';

import { useDraftProduct } from 'src/hooks/use-draft-product';

import getParam from 'src/sections/product-bulk/lib/getParam';
import GalleryUploader from 'src/sections/product-single/PostProduct/GalleryUploader';

export function RHFGalleryUploader({ name, handleSuccess, handleDelete, helperText, productId }) {
  const { control } = useFormContext();
  const { uploadImage } = useDraftProduct();

  return (
    <Controller
      name={name}
      control={control}
      render={({ field, fieldState: { error } }) => (
        <GalleryUploader
          initialState={field.value.map((url) => ({
            id: getParam(url, 'id'),
            source: url,
          }))}
          customRequest={({ uid, file, onSuccess, onError }) => {
            const prodId = productId ?? Math.floor(Math.random() * 10000000);
            uploadImage({
              file,
              saveLocation: 'products',
              itemId: prodId,
            }).then((response) => {
              if (response.error) {
                onError(uid, response.error);
              } else {
                onSuccess(uid, response);
              }
            });

            return {
              abort() {
                console.log('upload progress is aborted.');
              },
            };
          }}
          // handleChange={handleChange}
          handleSuccess={handleSuccess}
          onDeleted={handleDelete}
          error={!!error}
          helperText={
            (!!error || helperText) && (
              <FormHelperText error={!!error} sx={{ px: 2 }}>
                {error ? error?.message : helperText}
              </FormHelperText>
            )
          }
        />
      )}
    />
  );
}

RHFGalleryUploader.propTypes = {
  helperText: PropTypes.string,
  name: PropTypes.string,
  // handleChange: PropTypes.func,
  handleSuccess: PropTypes.func,
  handleDelete: PropTypes.func,
  productId: PropTypes.string,
};
