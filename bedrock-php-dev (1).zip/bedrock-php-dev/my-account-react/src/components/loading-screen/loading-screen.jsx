import PropTypes from 'prop-types';
import { useState, useEffect } from 'react';

import Box from '@mui/material/Box';
import LinearProgress from '@mui/material/LinearProgress';

import { twoFactor$ } from 'src/lib/observables';

// ----------------------------------------------------------------------

export default function LoadingScreen({ sx, ...other }) {
  const [dialogIsOpen, setDialogIsOpen] = useState(false);

  useEffect(() => {
    const subscription = twoFactor$.subscribe(({ action, isActive }) => {
      if (action === 'SHOW_2FA') {
        if (isActive) {
          setDialogIsOpen(true);
        } else {
          setDialogIsOpen(false);
        }
      }

      if (action === 'CANCEL_2FA') {
        setDialogIsOpen(false);
      }
    });

    return () => {
      subscription.unsubscribe();
    };
  }, []);

  return (
    !dialogIsOpen && (
      <Box
        sx={{
          px: 5,
          width: 1,
          flexGrow: 1,
          minHeight: 1,
          // height: '100vh',
          height: '50vh',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          ...sx,
        }}
        {...other}
      >
        <LinearProgress color="inherit" sx={{ width: 1, maxWidth: 360 }} />
      </Box>
    )
  );
}

LoadingScreen.propTypes = {
  sx: PropTypes.object,
};
