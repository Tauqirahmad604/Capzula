import { Crisp } from 'crisp-sdk-web';

import Stack from '@mui/material/Stack';
import Button from '@mui/material/Button';
import Typography from '@mui/material/Typography';

import { trl } from 'src/locales/i18n';

// ----------------------------------------------------------------------

export default function NavUpgrade() {
  // const { user } = useMockedUser();

  return (
    <Stack
      sx={{
        px: 2,
        py: 5,
        textAlign: 'center',
      }}
    >
      <Stack alignItems="center">
        {/* <Box sx={{ position: 'relative' }}>
          <Avatar src={user?.photoURL} alt={user?.displayName} sx={{ width: 48, height: 48 }} />
          <Label
            color="success"
            variant="filled"
            sx={{
              top: -6,
              px: 0.5,
              left: 40,
              height: 20,
              position: 'absolute',
              borderBottomLeftRadius: 2,
            }}
          >
            Free
          </Label>
        </Box> */}

        <Stack spacing={0.5} sx={{ mt: 1.5, mb: 2 }}>
          <Typography variant="subtitle2" noWrap>
            {trl('Sidebar.need_help?')}
          </Typography>

          {/* <Typography variant="body2" noWrap sx={{ color: 'text.disabled' }}>
            {trl('Sidebar.our_support_team_are_online')}
          </Typography> */}
        </Stack>

        <Button variant="contained" onClick={() => Crisp.chat.open()}>
          {trl('Sidebar.chat_now')}
        </Button>
      </Stack>
    </Stack>
  );
}
