import axios from 'axios';

export const translate = (text, { to, from, format }) => {
  // https://cloud.google.com/translate/docs/reference/rest/v2/translate
  const url = 'https://translation.googleapis.com/language/translate/v2';
  const key = import.meta.env.VITE_GOOGLE_TRANSLATE_API_KEY;

  const params = {
    key,
    q: text,
    // source: from || 'en',
    target: to,
    format: format || 'text',
  };

  return axios
    .get(url, { params })
    .then((res) => {
      // console.log(res.data, '<< res')
      const translatedText = res.data?.data?.translations?.[0]?.translatedText;
      return translatedText;
    })
    .catch((err) => {
      console.error(err);
      return text;
    });
};
