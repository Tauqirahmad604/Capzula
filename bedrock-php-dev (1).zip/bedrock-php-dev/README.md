## Clone this repo and run:
- git submodule update --init --recursive
- cd web/app/themes/capzula-theme
- git checkout bedrock

## To run the stack locally:
- cd back into the root of the bedrock repo (/)
- create a .env file, use .env-sample 
- docker compose up --build 

## Access the site at http://localhost:9000
- Complete the wordpress installation, this will create your admin account
- Login

## Verify the capzula-theme has been selected at:
http://localhost:9000/wp/wp-admin/themes.php

## Verify plugins are installed and active:
http://localhost:9000/wp/wp-admin/plugins.php

## Go to ACF and click on Sync tab:
- Select all, and apply Sync

## Go to Migration Config
http://localhost:9000/wp/wp-admin/admin.php?page=migration-config
- Run Migration

### Once ran, the following should have been confugured automatically:
- ACF Pro fields
- Countries
- Custom pages 
- WooCommerce configuration
- Custom Taxonomies
- Pages, such as registration pages 


# Building Docker
- docker build -t docker-php .
- docker run --env-file ./.env -d -p 9000:9000 docker-php
- Visit http://localhost:9000