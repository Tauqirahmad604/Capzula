import { InstantSearch, Configure } from 'react-instantsearch';
import searchClient from 'src/lib/searchClient';
import { Products } from './components';
import { getLangIndexName } from 'src/lib/utils';
import PropTypes from 'prop-types';
import { useEffect } from 'react';
import Content from 'src/sections/product-list/Content';
function FavProducts({ productIds }) {
  const indexName = getLangIndexName();
  // console.log('running!!', indexName);
  const getFilterData = () => {
    if (!productIds) {
      return;
    }
    return `parent_id:${productIds.join(' OR parent_id:')}`
  };

  return (
    <InstantSearch
      searchClient={searchClient}
      insights={true}
      indexName={indexName}
    >
      <Configure
        clickAnalytics
        hitsPerPage={999999}
        page={0}
        filters={getFilterData()}
        // filters={`NOT parent_id:${window.productData.id}`}
        ruleContexts={[]}
        facetingAfterDistinct={false}
      />

      <Content />
    </InstantSearch>
  );
}

FavProducts.propTypes = {
  productIds: PropTypes.array,
};

export default FavProducts;
