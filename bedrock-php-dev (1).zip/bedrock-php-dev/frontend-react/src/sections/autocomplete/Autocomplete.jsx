import { useMemo } from 'react';
import PropTypes from "prop-types";
import { useTranslation } from 'src/i18n';
import searchClient from 'src/lib/searchClient';
import { appendLangToUrl } from 'src/lib/utils';

import { SearchBox} from './components';
import { useProductsPlugin, useVendorsPlugin, useCategoriesPlugin, useRecentSearchesPlugin} from './plugins';

const Autocomplete = ({plugins}) => {
  const { t } = useTranslation();
  const vendorsPlugin = useVendorsPlugin();
  const productsPlugin = useProductsPlugin();
  const categoriesPlugin = useCategoriesPlugin();
  const recentSearchesPlugin = useRecentSearchesPlugin();

  const activePlugins = useMemo(() => {
    const pluginsAvailable = {
      'products': productsPlugin,
      'categories': categoriesPlugin,
      'vendors': vendorsPlugin,
      'recent-searches': recentSearchesPlugin
    }
    return plugins.map(plugin => pluginsAvailable[plugin])
  }, [categoriesPlugin, plugins, productsPlugin, vendorsPlugin, recentSearchesPlugin]);

  return (
    <div className="container">
      <SearchBox
        searchClient={searchClient}
        placeholder={t('autocomplete.searchPlaceholder')}
        openOnFocus
        initialState={{}}
        plugins={activePlugins}
        onSubmit={({ state }) => {
          window.location.href = appendLangToUrl(`/shop?query=${state.query}`);
        }}
      />
    </div>
  );
}

Autocomplete.propTypes = {
  plugins: PropTypes.array.isRequired,
}

export default Autocomplete;