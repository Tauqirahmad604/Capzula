import { getAlgoliaFacets } from '@algolia/autocomplete-js';
import { useTranslation } from 'src/i18n';
import searchClient from 'src/lib/searchClient';
import { getLangIndexName } from 'src/lib/utils';


function useVendorsPlugin() {
  const indexName = getLangIndexName();
  const { t } = useTranslation();

  return {
    getSources({ query }) {
      if (query.length < 3) {
        return [];
      }
      return [
        {
          sourceId: 'vendors',
          getItems({ query }) {
            return getAlgoliaFacets({
              searchClient,
              queries: [
                {
                  indexName,
                  facet: 'vendor.name',
                  params: {
                    facetQuery: query,
                    query: query,
                    maxFacetHits: 10,
                  },
                },
                {
                  indexName,
                  facet: 'vendor.slug',
                  params: {
                    facetQuery: query,
                    query: query,
                    maxFacetHits: 10,
                  },
                },
              ],
              transformResponse({ results }) {                
                return results[0].facetHits.map((facetHit, index) => {
                  return {
                    ...facetHit,
                    slug: results[1].facetHits[index].value,
                  }
                });
              }
            });
          },
          templates: {
            item({ item }) {
              return (
                <a href={`/vendor/${item.slug}`} className="aa-ItemLink">
                  <div className="aa-ItemContent">
                    <div className="aa-ItemTitle">
                      <span>{item.value}</span>
                    </div>
                  </div>
                </a>
              )
            },
            header({ items }) {
              if (items.length === 0) {
                return null;
              }

              return (
                <div className="aa-SourceHeader">
                  <div className="aa-SourceHeaderTitle">{t('autocomplete.results.sellers')}</div>
                  <div className="aa-SourceHeaderLine" />
                </div>
              );
            },
            footer({ state, items }) {
              if (state.context.isLoading) {
                return (
                  <div className="aa-SourceFooter">{t('autocomplete.searching')}</div>
                );
              }

              if(items.length) {
                return (
                  <a className="aa-ItemLink" href='/sellers'>
                    <div className="aa-ItemContent">
                      <div className="aa-ItemTitle">
                        <span>
                          {t('autocomplete.results.seeAllSellers')}
                        </span>
                      </div>
                    </div>
                  </a>
                );
              }

              return null;
            }
          }
        }
      ]
    }
  }
}

export default useVendorsPlugin;