import { getAlgoliaResults } from '@algolia/autocomplete-js';

import { useTranslation } from 'src/i18n';
import searchClient from 'src/lib/searchClient';
import { getLangIndexName } from 'src/lib/utils';

import {  SearchResult } from '../components';

function useProductsPlugin() {
  const { t } = useTranslation();
  const indexName = getLangIndexName();

  return {
    getSources({ query, state }) {
      if (query.length < 3) {
        return [];
      }
      return [{
        sourceId: 'products',
        getItems() {
          return getAlgoliaResults({
            searchClient,
            queries: [
              {
                indexName,
                query,
                params: {
                  hitsPerPage: 10,
                  clickAnalytics: true,
                },
              },
            ],
          });
        },
        templates: {
          header({ items }) {
            if (items.length === 0) {
              return null;
            }

            return (
              <div className="aa-SourceHeader">
                <div className="aa-SourceHeaderTitle">{t('autocomplete.results.products')}</div>
                <div className="aa-SourceHeaderLine" />
              </div>
            );
          },
          footer({ state }) {
            if (state.context.isLoading) {
              return (
                <div className="aa-SourceFooter">{t('autocomplete.searching')}</div>
              );
            }

            return null;
          },
          noResults({ state }) {
            if (state.context.isLoading) {
              return null;
            }

            return (
              <div className="aa-SourceFooter">{t('autocomplete.results.noResults')}</div>
            );
          },
          item({ item, components }) {
            return <SearchResult hit={item} components={components} insights={state.context.algoliaInsightsPlugin.insights} />;
          },
        },
      }];
    }
  };
}

export default useProductsPlugin;