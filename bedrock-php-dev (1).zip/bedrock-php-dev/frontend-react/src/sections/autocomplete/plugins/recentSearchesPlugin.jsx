import { createLocalStorageRecentSearchesPlugin } from '@algolia/autocomplete-plugin-recent-searches';


function useRecentSearchesPlugin() {
  const recentSearchesPlugin = createLocalStorageRecentSearchesPlugin({
    key: 'RECENT_SEARCH',
    limit: 5,
    transformSource({ source, state }) {
      if(state.query?.length > 3) {
        return {};
      }

      return {
        ...source,
        templates: {
          ...source.templates,
          header() {
            return (
              <>
                <span className="aa-SourceHeaderTitle">Your searches</span>
                <div className="aa-SourceHeaderLine" />
              </>
            );
          },
        },
      };
    },
  });

  return recentSearchesPlugin;
}

export default useRecentSearchesPlugin;