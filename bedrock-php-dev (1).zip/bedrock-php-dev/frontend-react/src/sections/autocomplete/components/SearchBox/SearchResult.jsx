import PropTypes from "prop-types";

import './SearchResult.scss';

const placeholderImage = 'https://via.placeholder.com/150';

const thumbImageFrom = (image) => {
  return image?.thumb || image?.small || placeholderImage;
};

const handleImageError = (e) => {
  e.target.src = placeholderImage;
}

function SearchResult({ hit, components, insights }) {
  const imageSrc = thumbImageFrom(hit.image);
  const handleClick = (event) => {
    event.preventDefault();

    window.location.href = hit.permalink;
  }

  return (
    <a href={hit.permalink} onClick={handleClick} className="aa-ItemLink">
      <div className="aa-ItemContent">
        <img src={imageSrc} alt={hit.name} className="aa-ItemIcon" onError={handleImageError} />
        <div className="aa-ItemTitle">
          <components.Highlight hit={hit} attribute="name" />
        </div>
      </div>
    </a>
  );
}

SearchResult.propTypes = {
  hit: PropTypes.object.isRequired,
  components: PropTypes.object.isRequired,
  insights: PropTypes.object.isRequired,
}

export default SearchResult;