import { useRef } from 'react';
import {
  // FrequentlyBoughtTogether,
  // RelatedProducts,
  useRecommendations,
} from '@algolia/recommend-react';
import recommend from '@algolia/recommend';

import ProductLoaders from 'src/components/Loaders/ProductLoaders';
import Product from 'src/sections/product-list/components/Product/Product';

import { getLangIndexName } from 'src/lib/utils';
import useSwiper from 'src/hooks/useSwiper';
import PropTypes from 'prop-types';

const recommendClient = recommend(import.meta.env.VITE_ALGOLIA_APP_ID, import.meta.env.VITE_ALGOLIA_SEARCH_API_KEY);
const indexName = getLangIndexName();


function CpzRelatedProducts({filters, id}) {
  // const swiper = useRef(null);

  const prepedVariationIds = window.productData?.variations.map((variation) => String(variation.id));

  const currentObjectIDs = prepedVariationIds || [];

  const defaultFilter = `NOT parent_id:${window.productData.id}`;

  
  const prepedFilters = filters ? [defaultFilter, ...filters].join(' AND ') : defaultFilter;

  const {status, recommendations} = useRecommendations({
    recommendClient,
    indexName,
    objectIDs: currentObjectIDs,
    queryParameters: {
      distinct: true,
      analytics: true,
      clickAnalytics: true,
      filters: prepedFilters,

    },
    model: 'looking-similar',
    maxRecommendations: 24,
  });

  // filters={`NOT parent_id:${window.productData.id}`}

  const isLoading = status === 'loading';

  useSwiper(`.swiper-${id}`, {
      xl: 6,
      lg: 4,
      md: 4,
      sm: 2,
  });

  return (
    <div className="slider-container">
      <div className={`swiper swiper-${id}`}>
        <div className="swiper-wrapper py-4">
          {isLoading && <ProductLoaders numOfProducts={6} />}

          {recommendations.map((hit) => (
            <div key={hit.objectID} className="swiper-slide">
              <Product
                lazy={false}
                key={hit.objectID}
                hit={hit}
                onClick={() => {}}
              />
            </div>
          ))}
        </div>

        <div className="swiper-pagination"></div>
        <div className="swiper-button-prev"></div>
        <div className="swiper-button-next"></div>
        <div className="swiper-scrollbar"></div>
      </div>
    </div>
  );
}

export default CpzRelatedProducts;


CpzRelatedProducts.propTypes = {
  filters: PropTypes.array,
  id: PropTypes.string,
}