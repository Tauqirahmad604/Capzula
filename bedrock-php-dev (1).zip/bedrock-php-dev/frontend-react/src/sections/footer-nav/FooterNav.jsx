import PropTypes from 'prop-types';
import { appendLangToUrl } from 'src/lib/utils';
import { useEffect, useState } from 'react';
import he from 'he';
import { FavProducts } from '../fav-products';

function BrowsePage() {
  return (
    <div className="page-wrapper">
      <ul className="list--blank circle-grid-section">
        {window.categories.map((category) => (
          <li className="mb-5" key={category.name}>
            <h2>{he.decode(category.name)}</h2>
            {category.children.length > 0 && (
              <ul className="circle-grid mt-4">
                {category.children.map((child) => (
                  <li className="circle-grid__elem" key={child.name}>
                    <a href={child.url}>
                      <img src={child.image} alt={child.name} />
                      {he.decode(child.name)}
                    </a>
                  </li>
                ))}
              </ul>
            )}
          </li>
        ))}
      </ul>
    </div>
  );
}

function FavouritesPage() {
  const [favProducts, setFavProducts] = useState(null);
  const [activeTab, setActiveTab] = useState('products');

  useEffect(() => {
    let localCopy = localStorage.getItem('favProducts');
    if (localCopy) {
      localCopy = JSON.parse(localCopy);
      setFavProducts(localCopy?.default);
    }
  }, []);

  // setCartCount

  return (
    <div className="page-wrapper p-4">
      <ul className="nav nav-pills mb-3">
        <li className="nav-item w-50 text-center">
          <a
            onClick={(e) => {
              e.preventDefault();
              setActiveTab('products');
            }}
            className={`nav-link ${
              activeTab === 'products' ? 'active' : ''
            } p-4`}
            aria-current="page"
            href="#"
          >
            Favourite Products
          </a>
        </li>
        <li className="nav-item w-50 text-center">
          <a
            onClick={(e) => {
              e.preventDefault();
              setActiveTab('sellers');
            }}
            className={`nav-link ${
              activeTab === 'sellers' ? 'active' : ''
            } p-4`}
            href="#"
          >
            Favourite Sellers
          </a>
        </li>
      </ul>

      {activeTab === 'products' && (
        <>{favProducts && <FavProducts productIds={favProducts} />}</>
      )}

      {activeTab === 'sellers' && <>sellers</>}
    </div>
  );
}

function FooterNav() {
  // const [activeFramePage, setActiveFramePage] = useState(false);
  const [activeFramePageUrl, setActiveFramePageUrl] = useState(false);
  const [activeAppPage, setActiveAppPage] = useState(false);
  const [animateHeart, setAnimateHeart] = useState(false);
  const [animateCart, setAnimateCart] = useState(false);
  const [cartCount, setCartCount] = useState(0);

  const openFramePage = (path) => {
    const url = appendLangToUrl(
      `${import.meta.env.VITE_ACCOUNT_APP_URL}/${path}`
    );

    if (url === activeFramePageUrl) {
      setActiveFramePageUrl(false);
      setActiveAppPage(false);
      return;
    }

    setActiveAppPage(false);
    setActiveFramePageUrl(false);

    if (activeFramePageUrl) {
      setTimeout(() => {
        // setActiveFramePage(true);
        setActiveFramePageUrl(url);
      }, 200);
      return;
    }

    setActiveFramePageUrl(url);
  };

  const toggleAppPage = (page) => {
    if (activeAppPage === page) {
      setActiveFramePageUrl(false);
      setActiveAppPage(false);
      return;
    }

    setActiveFramePageUrl(false);
    setActiveAppPage(false);

    if (activeFramePageUrl || activeAppPage) {
      setTimeout(() => {
        setActiveAppPage(page);
      }, 200);
      return;
    }
    setActiveAppPage(page);
  };

  useEffect(() => {
    const handleFavAdded = () => {
      setAnimateHeart(true);
    };

    window.addEventListener('favAdded', handleFavAdded);

    return () => {
      window.removeEventListener('favAdded', handleFavAdded);
    };
  }, []);

  useEffect(() => {
    const cartCountListener = (event_count) => {
      if (event_count?.detail?.cart_count) {
        if (
          !document.body.classList.contains('woocommerce-cart') ||
          !document.body.classList.contains('woocommerce-checkout')
        ) {
          setAnimateCart(true);
        }
        setCartCount(event_count?.detail?.cart_count);
      }
    };
    const onLoadCartCount = document
      .querySelector('.cart-count')
      ?.innerText?.trim();

    if (onLoadCartCount) {
      setCartCount(onLoadCartCount);
    }

    window.addEventListener('cartCount', cartCountListener);

    return () => {
      window.removeEventListener('cartCount', cartCountListener);
    };
  }, []);

  useEffect(() => {
    if (animateHeart) {
      setTimeout(() => {
        setAnimateHeart(false);
      }, 500);
    }
  }, [animateHeart]);

  useEffect(() => {
    if (animateCart) {
      setTimeout(() => {
        setAnimateCart(false);
      }, 500);
    }
  }, [animateCart]);

  return (
    <>
      {activeFramePageUrl}
      <div
        onClick={() => {
          setActiveAppPage(false);
          setActiveFramePageUrl(false);
        }}
        className={`footer-frame-bg ${
          activeFramePageUrl || activeAppPage ? 'is-open' : ''
        }`}
      ></div>
      <div
        className={`footer-frame-wrapper ${
          activeFramePageUrl || activeAppPage ? 'is-open' : ''
        }`}
      >
        {activeAppPage === 'browse' && <BrowsePage />}
        {activeAppPage === 'favourites' && <FavouritesPage />}

        {activeFramePageUrl && (
          <iframe
            src={activeFramePageUrl}
            className="footer-frame"
            border="0"
          />
        )}
      </div>

      <nav className="footer-nav-wrapper">
        <ul className="footer-nav">
          <li>
            <a
              href={`${appendLangToUrl('/')}`}
              className={`${
                document.body.classList.contains(
                  'page-template-homeMarketplaceTemplate'
                )
                  ? 'is-active'
                  : ''
              }`}
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="2em"
                height="2em"
                viewBox="0 0 16 16"
              >
                <path
                  fill="currentColor"
                  d="M8.687 1.262a1 1 0 0 0-1.374 0L2.469 5.84A1.5 1.5 0 0 0 2 6.931v5.57A1.5 1.5 0 0 0 3.5 14H5a1.5 1.5 0 0 0 1.5-1.5V10a.5.5 0 0 1 .5-.5h2a.5.5 0 0 1 .5.5v2.5A1.5 1.5 0 0 0 11 14h1.5a1.5 1.5 0 0 0 1.5-1.5V6.93a1.5 1.5 0 0 0-.47-1.09z"
                />
              </svg>
            </a>
          </li>
          <li>
            <a
              className={`${
                activeFramePageUrl ===
                `${import.meta.env.VITE_ACCOUNT_APP_URL}/${appendLangToUrl(
                  'chats'
                )}`
                  ? 'is-active'
                  : ''
              }`}
              href="/"
              onClick={(e) => {
                e.preventDefault();
                openFramePage('chats');
              }}
            >
              {/* {activeFramePageUrl} <br/>
              {appendLangToUrl('chats')} */}
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="2em"
                height="2em"
                viewBox="0 0 24 24"
              >
                <path
                  fill="currentColor"
                  fillRule="evenodd"
                  d="m13.629 20.472l-.542.916c-.483.816-1.69.816-2.174 0l-.542-.916c-.42-.71-.63-1.066-.968-1.262c-.338-.197-.763-.204-1.613-.219c-1.256-.021-2.043-.098-2.703-.372a5 5 0 0 1-2.706-2.706C2 14.995 2 13.83 2 11.5v-1c0-3.273 0-4.91.737-6.112a5 5 0 0 1 1.65-1.651C5.59 2 7.228 2 10.5 2h3c3.273 0 4.91 0 6.113.737a5 5 0 0 1 1.65 1.65C22 5.59 22 7.228 22 10.5v1c0 2.33 0 3.495-.38 4.413a5 5 0 0 1-2.707 2.706c-.66.274-1.447.35-2.703.372c-.85.015-1.275.022-1.613.219c-.338.196-.548.551-.968 1.262M8 11.75a.75.75 0 0 0 0 1.5h5.5a.75.75 0 0 0 0-1.5zM7.25 9A.75.75 0 0 1 8 8.25h8a.75.75 0 0 1 0 1.5H8A.75.75 0 0 1 7.25 9"
                  clipRule="evenodd"
                />
              </svg>
            </a>
          </li>

          <li>
            <a
              className={`${
                activeFramePageUrl ===
                `${import.meta.env.VITE_ACCOUNT_APP_URL}/${appendLangToUrl(
                  'dashboard'
                )}`
                  ? 'is-active'
                  : ''
              }`}
              href="/"
              onClick={(e) => {
                e.preventDefault();
                openFramePage('dashboard');
              }}
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="2em"
                height="2em"
                viewBox="0 0 24 24"
              >
                <circle cx="12" cy="6" r="4" fill="currentColor" />
                <path
                  fill="currentColor"
                  d="M20 17.5c0 2.485 0 4.5-8 4.5s-8-2.015-8-4.5S7.582 13 12 13s8 2.015 8 4.5"
                />
              </svg>
            </a>
          </li>

          <li>
            <a
              href={`${appendLangToUrl('/cart')}`}
              className={`${
                document.body.classList.contains('woocommerce-cart') ||
                document.body.classList.contains('woocommerce-checkout')
                  ? 'is-active'
                  : ''
              }
              
              ${animateCart ? 'is-animated' : ''}
              `}
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="2em"
                height="2em"
                viewBox="0 0 24 24"
              >
                <path
                  fill="currentColor"
                  d="M2.237 2.288a.75.75 0 1 0-.474 1.423l.265.089c.676.225 1.124.376 1.453.529c.312.145.447.262.533.382c.087.12.155.284.194.626c.041.361.042.833.042 1.546v2.672c0 1.367 0 2.47.117 3.337c.12.9.38 1.658.982 2.26c.601.602 1.36.86 2.26.981c.866.117 1.969.117 3.336.117H18a.75.75 0 0 0 0-1.5h-7c-1.435 0-2.436-.002-3.192-.103c-.733-.099-1.122-.28-1.399-.556c-.235-.235-.4-.551-.506-1.091h10.12c.959 0 1.438 0 1.814-.248c.376-.248.565-.688.943-1.57l.428-1c.81-1.89 1.215-2.834.77-3.508C19.533 6 18.506 6 16.45 6H5.745a8.996 8.996 0 0 0-.047-.833c-.055-.485-.176-.93-.467-1.333c-.291-.404-.675-.66-1.117-.865c-.417-.194-.946-.37-1.572-.58zM7.5 18a1.5 1.5 0 1 1 0 3a1.5 1.5 0 0 1 0-3m9 0a1.5 1.5 0 1 1 0 3a1.5 1.5 0 0 1 0-3"
                />
              </svg>

              {cartCount > 0 && (
                <div className="footer-nav-icon-badge">{cartCount}</div>
              )}
            </a>
          </li>

          <li>
            <a
              className={`${
                activeAppPage === 'favourites' ? 'is-active' : ''
              } ${animateHeart ? 'is-animated' : ''}`}
              href=""
              onClick={(e) => {
                e.preventDefault();
                toggleAppPage('favourites');
              }}
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="2em"
                height="2em"
                viewBox="0 0 24 24"
              >
                <path
                  fill="currentColor"
                  d="m12 21.35l-1.45-1.32C5.4 15.36 2 12.27 2 8.5C2 5.41 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.08C13.09 3.81 14.76 3 16.5 3C19.58 3 22 5.41 22 8.5c0 3.77-3.4 6.86-8.55 11.53z"
                />
              </svg>
            </a>
          </li>

          <li>
            <a
              className={`${activeAppPage === 'browse' ? 'is-active' : ''}`}
              href=""
              onClick={(e) => {
                e.preventDefault();
                toggleAppPage('browse');
              }}
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="2em"
                height="2em"
                viewBox="0 0 24 24"
              >
                <path
                  fill="currentColor"
                  d="M15.5 5a3.5 3.5 0 1 0 0 7a3.5 3.5 0 0 0 0-7M10 8.5a5.5 5.5 0 1 1 10.032 3.117l2.675 2.676l-1.414 1.414l-2.675-2.675A5.5 5.5 0 0 1 10 8.5M3 4h5v2H3zm0 7h5v2H3zm18 7v2H3v-2z"
                />
              </svg>
            </a>
          </li>
        </ul>
      </nav>
    </>
  );
}

export default FooterNav;

FooterNav.propTypes = {
  filters: PropTypes.array,
  id: PropTypes.string,
};
