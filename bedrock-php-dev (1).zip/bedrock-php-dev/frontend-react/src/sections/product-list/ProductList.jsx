import { useEffect, useState } from 'react';
import { InstantSearch, Configure } from 'react-instantsearch';

import { history } from 'instantsearch.js/es/lib/routers';

import searchClient from 'src/lib/searchClient';
import { getLangIndexName } from 'src/lib/utils';

import Content from './Content';

const defaultUiState = (indexName) => {
  const hierarchicalMenu = (window.categoriesHierarchy ?? [])
    .filter(({ name }) => {
      return name !== 'product';
    })
    .map(({ name }) => {
      return name;
    });
  const search = window.location.search;
  const params = new URLSearchParams(search);
  const query = params.get('query') ?? '';
  const filter = {
    query,
  };

  // filter['toggle'] = {
  //   // 'campaign_ids': [window.activeCampaign?.id],
  //   'campaign_ids': ['1563'],
  // };

  // toggle: {
  //   freeShipping: true
  // },

  // if (window.activeCampaign?.id) {
  // }
  if (window.activeSellerShop?.name) {
    filter['refinementList'] = {
      'vendor.name': [window.activeSellerShop?.name],
    };
  } else {
    filter['hierarchicalMenu'] = {
      'categories.lvl0': hierarchicalMenu,
    };
  }

  return {
    [indexName]: filter,
  };
};

function getCategorySlug(name) {
  return name.split(' ').map(encodeURIComponent).join('+');
}

// Returns a name from the category slug.
// The "+" are replaced by spaces and other
// characters are decoded.
function getCategoryName(slug) {
  return slug.split('+').map(decodeURIComponent).join(' ');
}

const configureRouting = (indexName) => {
  return {
    router: history({
      windowTitle: ({ category, query }) => {
        const queryTitle = query ? `Results for "${query}"` : 'Search';

        if (category) {
          return `${category} â€“ ${queryTitle}`;
        }

        return queryTitle;
      },
      createURL({ qsModule, routeState, location }) {
        const urlParts = location.href.match(/^(.*?)\/search/);
        const baseUrl = `${urlParts ? urlParts[1] : ''}/`;

        const categoryPath = routeState.category
          ? `${getCategorySlug(routeState.category)}/`
          : '';
        const queryParameters = {};

        console.log({ routeState });

        if (routeState.query) {
          queryParameters.query = encodeURIComponent(routeState.query);
        }
        if (routeState.page !== 1) {
          queryParameters.page = routeState.page;
        }
        if (routeState.brands) {
          queryParameters.brands = routeState.brands.map(encodeURIComponent);
        }

        const queryString = qsModule.stringify(queryParameters, {
          addQueryPrefix: true,
          arrayFormat: 'repeat',
        });

        return `${baseUrl}search/${categoryPath}${queryString}`;
      },
      parseURL({ qsModule, location }) {
        const pathnameMatches = location.pathname.match(/search\/(.*?)\/?$/);
        const category = getCategoryName(pathnameMatches?.[1] || '');
        const {
          query = '',
          page,
          brands = [],
        } = qsModule.parse(location.search.slice(1));
        // `qs` does not return an array when there's a single value.
        const allBrands = Array.isArray(brands)
          ? brands
          : [brands].filter(Boolean);

        return {
          query: decodeURIComponent(query),
          page,
          brands: allBrands.map(decodeURIComponent),
          category,
        };
      },
    }),
    stateMapping: {
      stateToRoute(uiState) {
        const indexUiState = uiState[indexName] || {};

        console.log({ indexUiState });

        return {
          query: indexUiState.query,
          page: indexUiState.page,
          brands: indexUiState.refinementList?.['vendor.name'] ?? [],
          // category: indexUiState.menu?.categories,
        };
      },

      routeToState(routeState) {
        return {
          [indexName]: {
            query: routeState.query,
            page: routeState.page,
            refinementList: {
              'vendor.name': routeState.brands,
            },
            // menu: {
            //   categories: routeState.category,
            // },
            // refinementList: {
            //   brand: routeState.brands,
            // },
          },
        };
      },
    },
  };
};

const ProductList = () => {
  const indexName = `${getLangIndexName(window.userLang)}`;
  const [initialUiState] = useState(defaultUiState(indexName));
  const checkForCampaign = window.activeCampaign?.id ? `campaign_ids:${window.activeCampaign?.id}` : '';


  return (
    <InstantSearch
      searchClient={searchClient}
      indexName={indexName}
      routing={true}
      // routing={configureRouting(indexName)}
      insights={true}
      // searchState={{
        // page: 0,

        // menu: {
        //   categories: '',
        // },
      // }}
      initialUiState={initialUiState}
    >
      <Configure
        clickAnalytics
        // userToken=''
        hitsPerPage={50}
        // filters="campaign_ids:1563"
        filters={checkForCampaign}
        ruleContexts={[]}
        facetingAfterDistinct={false}
        attributesToRetrieve={[
          'objectID',
          'name',
          'price',
          'regular_price',
          'vendor',
          'image',
          'color',
          'parent_color',
          'parent_id',
          'country_code',
          'permalink',
          'campaign_ids',
          'variant_colors',
        ]}
      />
      <Content />
    </InstantSearch>
  );
};

export default ProductList;