import { useEffect } from "react";
import { isBackForwardNavigation } from 'src/lib/utils';


export function useRestorePosition(key) {

  useEffect(() => {
    if (isBackForwardNavigation()) {
      const scrollPosition = sessionStorage.getItem(key);
      if (scrollPosition) {
        setTimeout(() => {
          window.scrollTo({ top: parseInt(scrollPosition), left: 0,  behavior: "instant"});
          sessionStorage.removeItem(key);
        }, 50);
      }
    }
  }, []);
}