import { useState, useRef } from 'react';
import { Icon } from '@iconify/react';
import { useSearchBox } from 'react-instantsearch';
import { useTranslation } from 'src/i18n';

import './SearchInput.scss';

function SearchInput(props) {
  const { query, refine } = useSearchBox(props);
  const [inputValue, setInputValue] = useState(query);
  const inputRef = useRef(null);
  const { t } = useTranslation();

  function setQuery(newQuery) {
    setInputValue(newQuery);

    refine(newQuery);
  }

  return (
    <form
      className='search-input-container'
      action=""
      role="search"
      noValidate
      onSubmit={(event) => {
        event.preventDefault();
        event.stopPropagation();

        if (inputRef.current) {
          inputRef.current.blur();
        }
      }}
      onReset={(event) => {
        event.preventDefault();
        event.stopPropagation();

        setQuery('');

        if (inputRef.current) {
          inputRef.current.focus();
        }
      }}
    >
      <input
        className='search-input'
        ref={inputRef}
        autoComplete="off"
        autoCorrect="off"
        autoCapitalize="off"
        placeholder={t('productList.searchPlaceholder')}
        spellCheck={false}
        maxLength={512}
        type="search"
        value={inputValue}
        onChange={(event) => {
          setQuery(event.currentTarget.value);
        }}
      />
            <Icon icon="iconamoon:search" width={24} className='search-icon' />

      {/* <button type="submit">Submit</button>
      <button
        type="reset"
        hidden={inputValue.length === 0 || isSearchStalled}
      >
        Reset
      </button> */}
    </form>
  );
}

export default SearchInput;