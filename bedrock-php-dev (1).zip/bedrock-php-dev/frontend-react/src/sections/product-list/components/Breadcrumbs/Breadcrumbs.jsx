import { useBreadcrumb } from 'react-instantsearch';

import { isModifierClick } from '../../utils';
import './Breadcrumbs.scss';
import he from 'he';

function Breadcrumbs(props) {
  const { items, refine, createURL } = useBreadcrumb(props);

  function createOnClick(value) {
    return function onClick(event) {
      if (!isModifierClick(event)) {
        event.preventDefault();
        refine(value);
      }
    };
  }

  return (
    <nav className='cpz-product-breadcrumbs' aria-label="breadcrumb" style={{
      "--bs-breadcrumb-divider": `url('data:image/svg+xml,%3Csvg xmlns="http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg" width="13" height="13" viewBox="0 0 16 16"%3E%3Cpath fill="currentColor" d="M6.22 3.22a.75.75 0 0 1 1.06 0l4.25 4.25a.75.75 0 0 1 0 1.06l-4.25 4.25a.751.751 0 0 1-1.042-.018a.751.751 0 0 1-.018-1.042L9.94 8L6.22 4.28a.75.75 0 0 1 0-1.06"%2F%3E%3C%2Fsvg%3E')"`,
      marginBottom: '1rem',
    }}>
      <ol className="breadcrumb">
        {/* <li className="breadcrumb-item">
          <a href={createURL(null)} onClick={createOnClick(null)}>
            {t('productList.breadcrumbs.home')}
          </a>
        </li> */}

        {items.map((item, index) => {
          const isLast = index === items.length - 1;

          return (
            <li className="breadcrumb-item" key={index} {...(isLast) ? ({"aria-current": "page"}) : {}}>
              {/* <span aria-hidden="true">&gt;</span> */}

              {isLast ? (
                he.decode(item.label)
              ) : (
                <a
                  href={createURL(item.value)}
                  onClick={createOnClick(item.value)}
                >
                  {he.decode(item.label)}
                </a>
              )}
            </li>
          );
        })}
      </ol>
    </nav>
  );
}

export default Breadcrumbs;