import PropTypes from 'prop-types';

import './Panel.scss';

export default function Panel({
  children,
  header,
  footer,
}) {
  return (
    <div className="panel">
      {header && <div className="panel-header">{header}</div>}
      <div className="panel-body">{children}</div>
      {footer && <div className="panel-footer">{footer}</div>}
    </div>
  );
}

Panel.propTypes = {
  children: PropTypes.node,
  header: PropTypes.node,
  footer: PropTypes.node,
};