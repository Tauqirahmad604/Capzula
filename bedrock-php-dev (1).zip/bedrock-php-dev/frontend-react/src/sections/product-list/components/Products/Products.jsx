import PropTypes from 'prop-types';
import { useCallback, useEffect, useRef, useState } from 'react';
import {
  useHits,
  useInstantSearch,
  usePagination,
} from 'react-instantsearch';
import { useTranslation } from 'src/i18n';
import ProductLoaders from 'src/components/Loaders/ProductLoaders';
import SortBy from '../SortBy/SortBy';
import Product from '../Product/Product';
import { getLangIndexName } from 'src/lib/utils';
import { SCROLL_POSITION_KEY } from 'src/lib/constants';
import ResponsivePagination from 'react-responsive-pagination';
import 'react-responsive-pagination/themes/classic.css';

import './Products.scss';

function Products(props) {
  const {
    hits,
    sendEvent,
    // isFirstPage,
    // isLastPage,
    results,
    // showMore,
    // showPrevious,
  } = useHits(props);
  const { refinementRef, lazy = true } = props;
  const { status } = useInstantSearch();
  const { currentRefinement, pages, refine } = usePagination(props);

  // const sentinelBottomRef = useRef(null);
  const sentinelTopRef = useRef(null);
  const { t } = useTranslation();
  const index_name_with_lang = getLangIndexName();
  const isLoading = status === 'loading' || status === 'stalled';
  const [favProducts, setFavProducts] = useState(null);

  // useEffect(() => {
  //   if (sentinelBottomRef.current !== null) {
  //     const observer = new IntersectionObserver((entries) => {
  //       entries.forEach((entry) => {
  //         if (entry.isIntersecting && !isLastPage) {
  //           showMore();
  //         }
  //       });
  //     });

  //     observer.observe(sentinelBottomRef.current);

  //     return () => {
  //       observer.disconnect();
  //     };
  //   }
  // }, [isLastPage, showMore]);

  // useEffect(() => {
  //   if (sentinelTopRef.current !== null) {
  //     const observer = new IntersectionObserver((entries) => {
  //       entries.forEach((entry) => {
  //         if (entry.isIntersecting && !isFirstPage) {
  //           showPrevious();
  //           console.log('SHOWING PREV');
  //         }
  //       });
  //     });

  //     observer.observe(sentinelTopRef.current);

  //     return () => {
  //       observer.disconnect();
  //     };
  //   }
  // }, [isFirstPage, showPrevious]);

  const handleClick = useCallback(
    (hit) => {
      sendEvent('click', hit, 'Product Clicked');
      sessionStorage.setItem(SCROLL_POSITION_KEY, String(window.scrollY));
    },
    [sendEvent]
  );

  const getFavProducts = async () => {
    try {
      let localCopy = localStorage.getItem('favProducts');
      if (localCopy) {
        localCopy = JSON.parse(localCopy);
        setFavProducts(localCopy);
        return;
      }
      if (window.get_fav_products) {
        const favProducts = await window.get_fav_products();
        if (favProducts?.data?.products){
          setFavProducts(favProducts?.data?.products);
          localStorage.setItem('favProducts', JSON.stringify(favProducts?.data?.products));
        }
      }
    } catch (err) {
      console.error(err);
    }
  }

  useEffect(() => {
    getFavProducts();
  }, []);

  useEffect(()=>{
    console.log(favProducts, '<< fav Products');
  }, [favProducts]);

  const productIsFavorite = (productId) => {
    return favProducts?.default?.includes(productId);
  }

  const favProduct = async (parent_id) => {
    const favProducts = await window.fav_product(parent_id);
    if (favProducts?.data?.products) {
      setFavProducts(favProducts?.data?.products);

      if (favProducts?.data?.isFaved){
        const event = new CustomEvent('favAdded');
        window.dispatchEvent(event);
      }


      localStorage.setItem('favProducts', JSON.stringify(favProducts?.data?.products));
      getFavProducts();
    }
  //  console.log(data, '<< parent_id')

};


  const handlePageClick = (event) => {
    refine(event - 1);
    refinementRef?.current?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <div className="ais-InfiniteHits">
      {/* {hits.length === 0 && <div>No results</div>} */}
      <div className="row">
        <div className="col">
          <span className="result-count">
            {t('productList.showingResults', {
              hits: hits.length,
              totalHits: results.nbHits,
            })}
            {/* {' - '}Showing {uiState[getLangIndexName()].page} of {calcPages()} */}
          </span>
        </div>

        <div className="col-auto">
          <SortBy
            items={[
              // { label: 'Featured', value: 'instant_search' },
              { label: 'Latest', value: `${index_name_with_lang}` },
              {
                label: 'Price (asc)',
                value: `${index_name_with_lang}_price_asc`,
              },
              {
                label: 'Price (desc)',
                value: `${index_name_with_lang}_price_desc`,
              },
            ]}
          />
        </div>
      </div>
      {/* {hits.length > 0 && <div>{hits.length} results</div>} */}

      <div ref={sentinelTopRef} aria-hidden="true" />

      {/* <button onClick={showPrevious}>Show Previous</button> */}
      <div className="product-grid product-grid--small ais-InfiniteHits-list">
        {isLoading ? (
          <ProductLoaders numOfProducts={50} />
        ) : (
          hits.map((hit) => (
            <Product favProduct={favProduct} isFav={productIsFavorite(hit.parent_id)} lazy={lazy} key={hit.objectID} hit={hit} onClick={handleClick} />
          ))
        )}
      </div>

      {pages.length > 1 && (
        <div className="mt-5 mx-5">
          <ResponsivePagination
            current={currentRefinement + 1}
            total={pages.length}
            onPageChange={handlePageClick}
          />
        </div>
      )}

      {/* <div ref={sentinelBottomRef} aria-hidden="true" />
      {isLoading && <div className="product-loader" />} */}
    </div>
  );
}

Products.defaultProps = {
  showPrevious: false,
  showMore: false,
  refinementRef: null,
};

Products.propTypes = {
  showPrevious: PropTypes.bool,
  showMore: PropTypes.bool,
  refinementRef: PropTypes.object,
  lazy: PropTypes.bool,
};

export default Products;
