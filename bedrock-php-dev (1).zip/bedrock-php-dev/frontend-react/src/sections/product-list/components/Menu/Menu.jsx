import PropTypes from 'prop-types';
import { useMenu } from 'react-instantsearch';
import classnames from 'classnames';

import './Menu.css';

function Menu(props) {
  const {
    items,
    createURL,
    refine,
    // canRefine,
    isShowingMore,
    toggleShowMore,
    canToggleShowMore,
    // sendEvent,
  } = useMenu({...props, sortBy: ['name:asc']});

  return (
    <>
      <div className="list-group list-group-flush">
          {items.map((item) => (
              <a
                className={classnames("list-group-item list-group-item-action d-flex justify-content-between align-items-center", {
                  'list-group-item-dark': item.isRefined,
                })}
                key={item.label}
                href={createURL(item.value)}
                onClick={(event) => {
                  event.preventDefault();

                  refine(item.value);
                }}
              >
                <span className='w-100'>{item.label}</span>
                <span>{item.count}</span>
              </a>
          ))}
        </div>
        {props.showMore && (
          <button disabled={!canToggleShowMore} onClick={toggleShowMore}>
            {isShowingMore ? 'Show less' : 'Show more'}
          </button>
        )}
    </>
  );
}

Menu.propTypes = {
  attibute: PropTypes.string.isRequired,
  limit: PropTypes.number,
  showMore: PropTypes.bool,
  showMoreLimit: PropTypes.number,
  transformItems: PropTypes.func,
  className: PropTypes.string,
  defaultRefinement: PropTypes.arrayOf(PropTypes.string),

};

export default Menu;
