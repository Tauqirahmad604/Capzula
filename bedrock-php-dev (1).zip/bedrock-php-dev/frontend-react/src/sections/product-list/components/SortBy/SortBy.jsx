import { useSortBy } from 'react-instantsearch';

import './SortBy.scss';

function SortBy(props) {
  const { currentRefinement, options, refine } = useSortBy(props);

  return (
    <select
      className="form-select"
      onChange={(event) => refine(event.target.value)}
      value={currentRefinement}
    >
      {options.map((option) => (
        <option key={option.value} value={option.value}>
          {option.label}
        </option>
      ))}
    </select>
  );
}

export default SortBy;