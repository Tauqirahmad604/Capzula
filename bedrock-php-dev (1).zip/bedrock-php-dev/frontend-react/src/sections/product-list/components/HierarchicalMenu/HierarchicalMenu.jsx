import { useHierarchicalMenu } from 'react-instantsearch';
import classNames from 'classnames';
import './HierarchicalMenu.scss';

import { isModifierClick } from '../../utils';

function HierarchicalMenu(props) {
  const {
    items,
    refine,
    canToggleShowMore,
    toggleShowMore,
    isShowingMore,
    createURL,
  } = useHierarchicalMenu(props);

  return (
    <>
      <HierarchicalList
        items={items}
        onNavigate={refine}
        createURL={createURL}
      />
      {props.showMore && (
        <button disabled={!canToggleShowMore} onClick={toggleShowMore}>
          {isShowingMore ? 'Show less' : 'Show more'}
        </button>
      )}
    </>
  );
}

function HierarchicalList({ items, createURL, onNavigate }) {
  if (items.length === 0) {
    return null;
  }

  return (
    <ul className='list-group list-group-flush'>
      {items.map((item) => (
        <li className='list-group-item' key={item.value}>
          <a
            className={classNames(
              'd-flex justify-content-between align-items-center text-decoration-none text-dark',
              {
                ['cpz-active']: item.isRefined,
              }
            )}
            href={createURL(item.value)}
            onClick={(event) => {
              if (isModifierClick(event)) {
                return;
              }
              event.preventDefault();

              onNavigate(item.value);
            }}
          >
            <span>{item.label}</span>
            <span className=''>{item.count}</span>
          </a>
          {item.data && (
            <HierarchicalList
              items={item.data}
              onNavigate={onNavigate}
              createURL={createURL}
            />
          )}
        </li>
      ))}
    </ul>
  );
}

export default HierarchicalMenu;