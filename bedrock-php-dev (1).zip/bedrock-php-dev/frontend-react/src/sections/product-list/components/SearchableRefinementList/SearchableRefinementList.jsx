import PropTypes from 'prop-types';
import { useMemo, useState } from 'react';
import { useRefinementList } from 'react-instantsearch';
import Select from 'react-select';

import './SearchableRefinementList.scss';


function SearchableRefinementList(props) {
  const {
    items,
    refine,
    sendEvent,
    searchForItems,
    isFromSearch,
  } = useRefinementList({...props, sortBy: ['name:asc']});
  // const [searchValue, setSearchValue] = useState('');
  // const handleInputChange = (e) => {
  //   setSearchValue(e.target.value);
  //   searchForItems(e.target.value);
  // }
  const attributes = useMemo(() => items.map((item) => ({
    label: item.label,
    value: item.value,
  })), [items]);

  const refinedItems = useMemo(() =>
    items.filter((item) => item.isRefined)
    .map(item => ({
      label: item.label,
      value: item.value,
    })), [items]);

  const handleChange = (value, action) => {
    if (action.action === 'select-option') {
      sendEvent('click', action.option, 'Refinement Clicked');
      refine(action?.option?.value);
    }

    if (action.action === 'remove-value') {
      refine(action?.removedValue?.value);
    }
  }

  return (
    <>
        <Select
          name={props.attribute}
          options={attributes}
          onChange={handleChange}
          className="basic-multi-select"
          classNamePrefix="select"
          value={refinedItems}
          isMulti
          isSearchable
          placeholder='Search...'
        />
        {/* <div>
          <input list={props.attribute} className="form-control" value={searchValue} onInput={handleInputChange} placeholder='Filter' />
          <datalist id={props.attribute}>
            {items.map((item) => (
              <option key={item.label} value={item.label} />
            ))}
          </datalist>
        </div>
        <ul className="list-group list-group-flush">
          {items.map((item) => (
            <li key={item.label} className="list-group-item">
              <label className="form-check-label d-flex">
                <input
                  className="form-check-input me-1"
                  type="checkbox"
                  checked={item.isRefined}
                  onChange={() => refine(item.value)}
                />
                <div className='d-flex flex-fill justify-content-between'>
                  <span>{item.label}</span>
                  <span>{item.count}</span>
                </div>
              </label>
            </li>
          ))}
        </ul> */}
    </>
  );
}

SearchableRefinementList.propTypes = {
  attribute: PropTypes.string.isRequired,
  limit: PropTypes.number,
  showMore: PropTypes.bool,
  showMoreLimit: PropTypes.number,
  transformItems: PropTypes.func,
  className: PropTypes.string,
  defaultRefinement: PropTypes.arrayOf(PropTypes.string),
};

export default SearchableRefinementList;