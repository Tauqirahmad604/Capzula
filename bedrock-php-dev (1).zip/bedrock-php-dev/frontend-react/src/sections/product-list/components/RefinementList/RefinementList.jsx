import { useRefinementList } from 'react-instantsearch';

import './RefinementList.scss';

function RefinementList(props) {
  const {
    items,
    refine,
    canToggleShowMore,
    isShowingMore,
    toggleShowMore,
    sendEvent,
    // hasExhaustiveItems,
  } = useRefinementList({...props, sortBy: ['name:asc']});

  return (
    <>
      <ul className="list-group list-group-flush">
        {items.map((item) => (
          <li key={item.label} className="list-group-item">
            <label className="form-check-label d-flex">
              <input
                className="form-check-input me-1"
                type="checkbox"
                checked={item.isRefined}
                onChange={() => {
                  refine(item.value)
                  sendEvent('click', item, 'Refinement Clicked');
                }}
              />
              <div className='d-flex flex-fill justify-content-between'>
                <span>{item.label}</span>
                {/* <span>{item.count}</span> */}
              </div>
            </label>
          </li>
        ))}
      </ul>

      {canToggleShowMore && (
        <button className='btn btn-link' onClick={toggleShowMore}>
          {isShowingMore ? 'Show less' : 'Show more'}
        </button>
      )}
    </>
  );
}

export default RefinementList;