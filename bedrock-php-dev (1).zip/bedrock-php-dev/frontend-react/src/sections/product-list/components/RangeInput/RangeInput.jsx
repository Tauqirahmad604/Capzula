import { styled } from '@mui/material/styles';
import Slider, {SliderThumb} from '@mui/material/Slider';
import { useRange } from 'react-instantsearch';


function valueText(value) {
  return `$${value}`;
}

const CustomSlider = styled(Slider)({
  color: '#333333',
  height: 8,
  '& .MuiSlider-track': {
    border: 'none',
  },
  '& .MuiSlider-thumb': {
    height: 24,
    width: 24,
    backgroundColor: '#fff',
    border: '2px solid currentColor',
    '&:focus, &:hover, &.Mui-active, &.Mui-focusVisible': {
      boxShadow: 'inherit',
    },
    '&::before': {
      display: 'none',
    },
  },
  '& .MuiSlider-valueLabel': {
    lineHeight: 1.2,
    fontSize: 12,
    background: 'unset',
    padding: 0,
    width: 32,
    height: 32,
    borderRadius: '50% 50% 50% 0',
    backgroundColor: '#333333',
    transformOrigin: 'bottom left',
    transform: 'translate(50%, -100%) rotate(-45deg) scale(0)',
    '&::before': { display: 'none' },
    '&.MuiSlider-valueLabelOpen': {
      transform: 'translate(50%, -100%) rotate(-45deg) scale(1)',
    },
    '& > *': {
      transform: 'rotate(45deg)',
    },
  },
});

function RangeInput(props) {
  const { start, range, refine } = useRange(props);

  const values = {
    min:
      start[0] !== -Infinity && start[0] !== range.min
        ? start[0]
        : range.min,
    max:
      start[1] !== Infinity && start[1] !== range.max
        ? start[1]
        : range.max,
  };

  if(!range.min || !range.max) return null;

  return (
    <div style={{width: '100%', margin: '0 auto', paddingLeft: '1em', paddingRight: '1em'}}>
      <CustomSlider
        min={range.min}
        max={range.max}
        defaultValue={[values.min, values.max]}
        getAriaValueText={valueText}
        // step={1}
        onChangeCommitted={(event, value) => {
          refine(value);
        }}
        slots={{ thumb: SliderThumb }}
        getAriaLabel={(index) => (index === 0 ? 'Minimum price' : 'Maximum price')}
        valueLabelDisplay="auto"
        valueLabelFormat={valueText}
        marks={[
          {
            value: range.min,
            label: `$${range.min}`
          },
          {
            value: range.max,
            label: `$${range.max}`
          }
        ]}
      />
    </div>
  );
}

export default RangeInput;