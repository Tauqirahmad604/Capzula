import { useCurrentRefinements, useClearRefinements} from 'react-instantsearch';
import { Icon } from '@iconify/react';
import { isModifierClick, colorNameFor } from '../../utils';
import { useTranslation } from 'src/i18n';
import he from 'he';
import './CurrentRefinements.scss';


function CurrentRefinements(props) {
  const { items, refine } = useCurrentRefinements(props);
  const { canRefine: canClearRefinements, refine: clearRefinements } = useClearRefinements(props);
  const { t } = useTranslation();

  return (
    <>
      {canClearRefinements && (
        <div className='row justify-content-between mb-2'>
          <div className='col'>
          <ul className='current-refinements'>
            {items.filter((item)=> window.activeSellerShop?.name ? (item.label !== 'vendor.name') : true ).map((item) => (
              <li key={[item.indexName, item.label].join('/')}>
                <span className='current-refinements__heading'>{labelName(item)}:{' '}</span>
                {item.refinements.map((refinement) => (
                  <div className='current-refinements__tag' key={refinement.label}>
                    <span>{labelValue({ label: he.decode(item.label), value: he.decode(refinement.label) })}</span>
                    <button
                      type="button"
                      onClick={(event) => {
                        if (isModifierClick(event)) {
                          return;
                        }

                        refine(refinement);
                      }}
                    >
                      <Icon icon="carbon:close-filled" width="18" />
                    </button>
                  </div>
                ))}
              </li>
            ))}
          </ul>
          </div>
          <div className='col-auto ms-auto'>
            <button className='current-refinements-clear-btn' disabled={!canClearRefinements} onClick={clearRefinements}>
              {t('productList.clearFilters')}
            </button>
          </div>
        </div>
      )}

    </>
  );

  function labelName({label}) {
    if( label.toLowerCase().includes('categories')) {
      return t('productList.categories');
    }

    switch (label.toLowerCase()) {
      case 'parent_color.term_id':
        return t('productList.colors');
      case 'vendor.name':
        return t('productList.brands');
      case 'compositions':
        return t('productList.materials');
      case 'country_code':
        return t('productList.countries');
      default:
        return label;
    }
  }

  function labelValue({label, value}) {
    switch (label.toLowerCase()) {
      case 'parent_color.term_id':
        return colorNameFor(value);
      case 'country_code':
        switch (value.toLowerCase()) {
          case 'us':
            return t('productList.countryName.us');
          case 'tr':
            return t('productList.countryName.tr');
          case 'co':
            return t('productList.countryName.co');
          default:
            return value;
        }
      default:
        return value;
    }
  }
}


export default CurrentRefinements;