import PropTypes from 'prop-types';

import { colorHexFor } from '../../utils';
import { appendLangToUrl } from 'src/lib/utils';
import { LazyLoadImage } from 'react-lazy-load-image-component';
import { useEffect, useState } from 'react';
import { CircleFlag } from 'react-circle-flags';

const countryImage = (countryCode) => {
  switch (countryCode?.toUpperCase()) {
    case 'US':
      return 'https://capzula.com/wp-content/uploads/2023/07/usa.png';
    case 'TR':
      return 'https://capzula.com/wp-content/uploads/2023/07/turkey.png';
    case 'CO':
      return 'https://capzula.com/wp-content/uploads/2023/07/columbia.png';
    default:
      return '';
  }
};

const placeholderImage = 'https://via.placeholder.com/240x360';

const getImageFor = (image) => {
  return image?.small || image?.full || placeholderImage;
};

const FavEnabledIcon = () => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width="1.5em"
    height="1.5em"
    viewBox="0 0 24 24"
  >
    <path
      fill="currentColor"
      d="M2 9.137C2 14 6.02 16.591 8.962 18.911C10 19.729 11 20.5 12 20.5s2-.77 3.038-1.59C17.981 16.592 22 14 22 9.138c0-4.863-5.5-8.312-10-3.636C7.5.825 2 4.274 2 9.137"
    />
  </svg>
);

const FavDisabledIcon = () => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width="1.5em"
    height="1.5em"
    viewBox="0 0 24 24"
  >
    <path
      fill="currentColor"
      fillRule="evenodd"
      d="M5.624 4.424C3.965 5.182 2.75 6.986 2.75 9.137c0 2.197.9 3.891 2.188 5.343c1.063 1.196 2.349 2.188 3.603 3.154c.298.23.594.459.885.688c.526.415.995.778 1.448 1.043c.452.264.816.385 1.126.385c.31 0 .674-.12 1.126-.385c.453-.265.922-.628 1.448-1.043c.29-.23.587-.458.885-.687c1.254-.968 2.54-1.959 3.603-3.155c1.289-1.452 2.188-3.146 2.188-5.343c0-2.15-1.215-3.955-2.874-4.713c-1.612-.737-3.778-.542-5.836 1.597a.75.75 0 0 1-1.08 0C9.402 3.882 7.236 3.687 5.624 4.424M12 4.46C9.688 2.39 7.099 2.1 5 3.059C2.786 4.074 1.25 6.426 1.25 9.138c0 2.665 1.11 4.699 2.567 6.339c1.166 1.313 2.593 2.412 3.854 3.382c.286.22.563.434.826.642c.513.404 1.063.834 1.62 1.16c.557.325 1.193.59 1.883.59s1.326-.265 1.883-.59c.558-.326 1.107-.756 1.62-1.16a78.6 78.6 0 0 1 .826-.642c1.26-.97 2.688-2.07 3.854-3.382c1.457-1.64 2.567-3.674 2.567-6.339c0-2.712-1.535-5.064-3.75-6.077c-2.099-.96-4.688-.67-7 1.399"
      clipRule="evenodd"
    />
  </svg>
);

const Product = (props) => {
  const [hasErrored, setHasErrored] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  const { hit, onClick, lazy = true, isFav, favProduct } = props;
  const {
    name,
    price,
    regular_price,
    vendor,
    image,
    color,
    parent_color,
    country_code,
    permalink,
    parent_id,
    campaign_ids: campaign_tax_ids,
    variant_colors: variantColors,
  } = hit;

  const colorName = color?.name;
  const priceFormatter = new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
  });

  // console.log(image);
  // const handleImageError = (e) => {
  //   e.target.src = placeholderImage;
  // };

  // const campaignDetails =  => campaign_ids?.select((id) => {
  //   return window.campaigns.find((campaign) => campaign.id === id);
  // });

  const colorHex = colorHexFor(color.term_id);
  const discountAmount = (price, regularPrice) => {
    return Math.round(((regularPrice - price) / regularPrice) * 100);
  };

  function capitalizeFirstLetter(string) {
    return string
      .toLowerCase() // Convert the whole string to lowercase
      .replace(/(^\w{1})|(\s+\w{1})/g, (letter) => letter.toUpperCase()); // Capitalize the first letter of every word
  }

  const badgeData = () => {
    if (!campaign_tax_ids) {
      return [];
    }

    const preppedBadges = campaign_tax_ids
      .map((id) => {
        id = parseInt(id);
        const campaignId = window.campaigns[id];
        return campaignId;
      })
      .filter((badgeData) => {
        return badgeData?.badge_text;
      });

    return preppedBadges;
  };

  useEffect(() => {
    setIsLoading(false);
  }, [isFav]);

  // fav_product

  return (
    !hasErrored && (
      <div className="img-card-wrapper">
        <div className="img-card__actions">
          <div
            className="fav-heart"
            onClick={() => {
              setIsLoading(true);
              favProduct(parent_id);
            }}
          >
            {isLoading ? (
              isFav ? (
                <FavDisabledIcon />
              ) : (
                <FavEnabledIcon />
              )
            ) : isFav ? (
              <FavEnabledIcon />
            ) : (
              <FavDisabledIcon />
            )}
          </div>
        </div>
        <a
          className="ais-InfiniteHits-item"
          href={appendLangToUrl(permalink)}
          onClick={() => onClick(hit)}
        >
          <div className="img-card img-card--large">
            <div className="img-card__badges">
              {badgeData().map((badge) => (
                <div
                  style={{
                    backgroundColor: badge?.badge_bg_color || null,
                    color: badge?.badge_text_color || null,
                  }}
                  key={badge?.badge_text}
                  className="product-badge"
                >
                  {badge?.badge_text}
                </div>
              ))}

              {price !== regular_price &&
                discountAmount(price, regular_price) > 5 && (
                  <div className="product-badge product-badge--sale ">
                    {discountAmount(price, regular_price)}% OFF
                  </div>
                )}
            </div>
            <div className="img-card__img">
              <div className="product-ph">
                {lazy ? (
                  <LazyLoadImage
                    alt={name}
                    effect="blur"
                    onError={() => setHasErrored(true)}
                    src={getImageFor(image)}
                    width="100%"
                  />
                ) : (
                  <img
                    alt={name}
                    onError={() => setHasErrored(true)}
                    src={getImageFor(image)}
                    width="100%"
                  />
                )}
              </div>
            </div>

            <div className="img-card__content">
              {country_code && (
                <div className="img-card__icon img-card__icon--small">
                  <CircleFlag
                    countryCode={country_code.toLowerCase()}
                    height="20"
                    width="20"
                  />
                </div>
              )}

              <div className="product-desc">
                <div className="product-desc__title">
                  {capitalizeFirstLetter(name)}
                </div>
                <div className="product-desc__vendor">by {vendor?.name}</div>
                <div className="product-desc__price">
                  <div className="price-text">
                    <span
                      className={`price-text__price ${
                        price !== regular_price ? 'price-text__price--pop' : ''
                      }`}
                    >
                      {priceFormatter.format(price)}
                    </span>
                    {price !== regular_price && (
                      <span className="price-text__price price-text__price--strike">
                        {priceFormatter.format(regular_price)}
                      </span>
                    )}
                  </div>
                </div>
                <div className="product-desc__colors">
                  <ul className="color-circles">
                    {colorName === 'multi' ? (
                      <li className="color-circle color-circle--multi">
                        <div className="color-wheel"></div>
                      </li>
                    ) : (
                      <li
                        className="color-circle"
                        style={{
                          backgroundColor:
                            colorHex || colorHexFor(parent_color?.term_id),
                        }}
                      >
                        {colorName}
                      </li>
                    )}
                    {colorName !== 'multi' &&
                      variantColors.map((variant) => {
                        return (
                          <li
                            key={variant.term_id}
                            className="color-circle"
                            style={{
                              backgroundColor:
                                colorHexFor(variant.term_id) || '#eee',
                            }}
                          >
                            {variant.name}
                          </li>
                        );
                      })}
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </a>
      </div>
    )
  );
};

Product.propTypes = {
  hit: PropTypes.object.isRequired,
  onClick: PropTypes.func.isRequired,
  lazy: PropTypes.bool,
  isFav: PropTypes.bool,
  favProduct: PropTypes.func,
};

export default Product;
