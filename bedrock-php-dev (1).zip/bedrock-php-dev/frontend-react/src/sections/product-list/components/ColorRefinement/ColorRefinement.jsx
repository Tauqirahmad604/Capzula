import { memo } from 'react';
import { useRefinementList } from 'react-instantsearch';
import { Icon } from '@iconify/react';
import { colorHexFor } from '../../utils';


import './ColorRefinement.scss';

function ColorRefinement(props) {
  const {
    items,
    refine,
    sendEvent,
  } = useRefinementList({...props, sortBy: ['name:asc']});

  return (
    <>
      <ul className='cpz-colors-container'>
        {items.map((item) => {
          const color = colorHexFor(item.value);

          if(item.value === 'multi') {
            return (
              <li className='cpz-color-icon' key={item.label}>
                <label>
                  <span>
                    <div className='cpz-color-wheel'></div>
                    <input
                      type="checkbox"
                      checked={item.isRefined}
                      onChange={() => {
                        sendEvent('click', item, 'Color Clicked');
                        refine(item.value)
                      }}
                    />
                    <span>{item.label} {item}</span>
                  </span>
                  {/* <span>({item.count})</span> */}
                </label>
              </li>
            )
          }

          return (
          <li className='cpz-color-icon' key={item.label}>
            <label>
              <span>
                {item.isRefined ? (
                  <Icon icon="mdi:checkbox-marked-circle" color={color} width="30" />
                ) : (
                  <Icon icon="mdi:checkbox-blank-circle" color={color} width="30" />
                )}
                <input
                  type="checkbox"
                  checked={item.isRefined}
                  onChange={() => refine(item.value)}
                />
                <span>{item.label}</span>
              </span>
              {/* <span>({item.count})</span> */}
            </label>
          </li>
        )})}
      </ul>
    </>
  );
}

export default ColorRefinement;