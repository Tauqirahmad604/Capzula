import { Icon } from '@iconify/react';
import { useTranslation } from 'src/i18n';

function LanguageSwitcher() {
  const { t, changeLanguage } = useTranslation();
  const items = [
    { value: 'cpz_products_en', label: t('productList.language.en'), flag: 'us', language: 'en' },
    { value: 'cpz_products_es', label: t('productList.language.es'), flag: 'es', language: 'es' },
    { value: 'cpz_products_tr', label: t('productList.language.tr'), flag: 'tr', language: 'tr' },
  ];

  return (
    // <div className="row mb-6 pb-6 justify-content-end">
      <div className="col-auto">
        {items.map((item) => (
          <button className="btn" key={item.value} onClick={() => {
            changeLanguage(item.language);
            location.search = `?${item.value}`;
          }}>
            <Icon icon={`flag:${item.flag}-4x3`} width="30" />
            <span>{item.label}</span>
          </button>
        ))}
      </div>
    // </div>
  )
}

export default LanguageSwitcher;