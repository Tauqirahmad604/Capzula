import { useCallback, useEffect, useRef, useState } from 'react';
import { SortBy, useCurrentRefinements } from 'react-instantsearch';
import { createInfiniteHitsSessionStorageCache } from 'instantsearch.js/es/lib/infiniteHitsCache';

import { useTranslation } from 'src/i18n';
import { useRestorePosition } from './hooks';
import {
  INSTANT_SEARCH_HIERARCHICAL_ATTRIBUTES,
  SCROLL_POSITION_KEY,
} from 'src/lib/constants';
// import { getLangIndexName, isBackForwardNavigation } from 'src/lib/utils';
import {
  CurrentRefinements,
  ColorRefinement,
  Breadcrumbs,
  Panel,
  Products,
  SearchInput,
  RefinementList,
  HierarchicalMenu,
  SearchableRefinementList,
  RangeInput,
} from './components';
import { colorNameFor } from './utils';
import { useOnScreen } from 'src/lib/utils';
import { getLangIndexName } from 'src/lib/utils';

const sessionStorageCache = createInfiniteHitsSessionStorageCache();

const Content = () => {
  const { t } = useTranslation();
  const [filtersActive, setFiltersActive] = useState(false);
  const [showFilters, setShowFilters] = useState(false);
  const [filterNoticeShown, setFilterNoticeShown] = useState(
    localStorage.getItem('notice_filter_shown') === 'true'
  );

  const [isFaded, setIsFaded] = useState(false);
  // const { refresh, setUiState } = useInstantSearch();
  const refinementRef = useRef(null);
  const { items } = useCurrentRefinements();

  useRestorePosition(SCROLL_POSITION_KEY);

  // useEffect(() => {
  //   // If the user is coming from a different page, reset the page number
  //   if(!isBackForwardNavigation()) {
  //     const indexName = getLangIndexName();
  //     setUiState((uiState) => {
  //       return ({
  //       ...uiState,
  //       [indexName]: {
  //         ...uiState[indexName],
  //         page: 0
  //       }
  //     })});
  //     sessionStorage.clear();
  //     refresh();
  //   }
  // }, [refresh, setUiState]);

  // const ref = useRef<HTMLDivElement>(null)
  // const filterButtonIsInView = useOnScreen(ref)

  useEffect(() => {
    if (!showFilters) {
      setIsFaded(false);
      setTimeout(() => {
        setFiltersActive(false);
      }, 150);
    }
    if (showFilters) {
      setFiltersActive(true);
      setTimeout(() => {
        setIsFaded(true);
      }, 150);
    }
  }, [showFilters]);

  const filtersNoticeClicked = () => {
    setFilterNoticeShown(true);
    localStorage.setItem('notice_filter_shown', 'true');
  };
  useEffect(() => {
    const productListViewDiv = document.getElementById(
      'product_list_view_loader'
    );
    if (productListViewDiv) {
      productListViewDiv.style.display = 'none';
    }
  }, []);

  const transformColors = useCallback((items) => {
    return items?.map((item) => {
      return {
        ...item,
        value: item?.value,
        label: colorNameFor(item?.value),
      };
    });
  }, []);

  const transformCountries = useCallback(
    (items) => {
      return items.map((item) => {
        switch (item.label.toLowerCase()) {
          case 'us':
            return {
              ...item,
              label: t('productList.countryName.us'),
            };
          case 'tr':
            return {
              ...item,
              label: t('productList.countryName.tr'),
            };
          case 'co':
            return {
              ...item,
              label: t('productList.countryName.co'),
            };
          default:
            return item;
        }
      });
    },
    [t]
  );
  const index_name_with_lang = getLangIndexName();

  return (
    <>
      <div className="filters-tab-wrapper d-lg-none">
        {!filterNoticeShown && (
          <div className="filters-tab-notice">
            {t('productList.openFilterNotice')}
            <div>
              <button
                onClick={filtersNoticeClicked}
                className="btn btn-block btn-sm btn-light mt-3"
              >
                OK
              </button>
            </div>
          </div>
        )}

<button
          className="filters-tab"
          // type="button"
          onClick={() => {
            setShowFilters(!showFilters);
            filtersNoticeClicked();
          }}
        >
          <svg
            xmlns="http://www.w3.org/2000/svg"
            className="me-2"
            width="1.5em"
            height="1.5em"
            viewBox="0 0 24 24"
          >
            <path
              fill="currentColor"
              d="M22 18.605a.75.75 0 0 1-.75.75h-5.1a2.93 2.93 0 0 1-5.66 0H2.75a.75.75 0 1 1 0-1.5h7.74a2.93 2.93 0 0 1 5.66 0h5.1a.75.75 0 0 1 .75.75m0-13.21a.75.75 0 0 1-.75.75H18.8a2.93 2.93 0 0 1-5.66 0H2.75a.75.75 0 1 1 0-1.5h10.39a2.93 2.93 0 0 1 5.66 0h2.45a.74.74 0 0 1 .75.75m0 6.6a.74.74 0 0 1-.75.75H9.55a2.93 2.93 0 0 1-5.66 0H2.75a.75.75 0 1 1 0-1.5h1.14a2.93 2.93 0 0 1 5.66 0h11.7a.75.75 0 0 1 .75.75"
            />
          </svg>
          {items.length > 0
            ? `Change Filters (${items.length})`
            : 'Filter Products'}
        </button>
        
        <div className="filters-tab" style={{borderRight: 'none'}}>
        <SortBy
            items={[
              // { label: 'Featured', value: 'instant_search' },
              { label: 'Sort By Latest', value: `${index_name_with_lang}` },
              {
                label: 'Sort By Price (asc)',
                value: `${index_name_with_lang}_price_asc`,
              },
              {
                label: 'Sort By Price (desc)',
                value: `${index_name_with_lang}_price_desc`,
              },
            ]}
          />

        </div>


      </div>
      <div className="no-trans">
        {/* <LanguageSwitcher /> */}
        <Breadcrumbs
          translations={{
            home: 'Home',
            category: 'Category',
          }}
          attributes={INSTANT_SEARCH_HIERARCHICAL_ATTRIBUTES}
        />
        <div className="row">
          <div className="col-lg-3 col-xxl-2">
            <div
              onClick={() => setShowFilters(false)}
              className={`product-filters-wrapper ${
                filtersActive ? 'is-active' : ''
              } ${isFaded ? 'is-faded' : ''} `}
            >
              <div
                onClick={(e) => e.stopPropagation()}
                className={`product-filters sidebar`}
              >
                <div className="">
                  {/* {!window.activeSellerShop?.name &&
                <Panel header={t('productList.brands')}>
                  <RefinementList attribute="vendor.name" />
                </Panel>
              } */}

                  <div
                    style={{
                      display: window.activeSellerShop?.name ? 'none' : 'block',
                    }}
                  >
                    <Panel header={t('productList.brands')}>
                      {/* <RefinementList attribute="vendor.name" /> */}
                      <SearchableRefinementList attribute="vendor.name" />
                    </Panel>
                  </div>

                  <Panel header={t('productList.countries')}>
                    <RefinementList
                      attribute="country_code"
                      transformItems={transformCountries}
                    />
                  </Panel>

                  <Panel header={t('productList.categories')}>
                    <HierarchicalMenu
                      attributes={[
                        'categories.lvl0',
                        'categories.lvl1',
                        'categories.lvl2',
                      ]}
                    />
                  </Panel>

                  <Panel header={t('productList.materials')}>
                    <RefinementList
                      attribute="compositions"
                      showMore
                      limit={5}
                    />
                  </Panel>

                  <Panel header={t('productList.colors')}>
                    <ColorRefinement
                      attribute="parent_color.term_id"
                      transformItems={transformColors}
                    />
                  </Panel>

                  <Panel header={t('productList.price')}>
                    <RangeInput attribute="price" />
                  </Panel>

                  <Panel header={t('productList.tags')}>
                    <RefinementList attribute="tags" showMore limit={5} />
                  </Panel>
                </div>
              </div>
            </div>
          </div>
          <div className=" col-lg-9 col-xxl-10">
            {window.activeCampaign?.banner && (
              <div className="card mb-4">
                <img src={window.activeCampaign?.banner} />
              </div>
            )}

            <section className="content card">
              <div className="card-body">
                <div className="refinements" ref={refinementRef}>
                  <CurrentRefinements />
                </div>
                <SearchInput placeholder="Search" autoFocus />
                {/* <SearchBox placeholder="Search" autoFocus /> */}
                <div className="results">
                  <Products
                    refinementRef={refinementRef}
                    cache={sessionStorageCache}
                  />
                </div>
              </div>
            </section>
          </div>
        </div>
      </div>
    </>
  );
};

export default Content;
