import Colors from '../data/colors.json';

// const Colors = window.productColors;

export const colorHexFor = (colorId) => {
  const color = Colors.find((color) => color.term_id === Number(colorId));
  const parentColor = Colors.find((color) => color?.parent_color?.term_id === Number(colorId));

  return color?.hex || parentColor?.hex;
}

export const colorNameFor = (colorId) => {
  const color = Colors.find((color) => color.term_id === Number(colorId));
  const parentColor = Colors.find((color) => color?.parent_color?.term_id === Number(colorId));

  return color?.name || parentColor?.name;
}

export function isModifierClick(event) {
  const isMiddleClick = event.button === 1;

  return Boolean(
    isMiddleClick ||
      event.altKey ||
      event.ctrlKey ||
      event.metaKey ||
      event.shiftKey
  );
}