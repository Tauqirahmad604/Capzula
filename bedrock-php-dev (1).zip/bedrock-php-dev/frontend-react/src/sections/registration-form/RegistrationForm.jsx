import { Button, Col, FormFeedback, FormGroup, Input, Label, Row } from 'reactstrap';
import 'react-phone-number-input/style.css';
import PhoneInput from 'react-phone-number-input';
import { useForm, Controller } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import * as Yup from 'yup';
import { enqueueSnackbar } from 'notistack';

const phoneRegExp = /^[+]*[(]{0,1}[0-9]{1,4}[)]{0,1}[-\s./0-9]*$/;

const validationSchema = Yup.object().shape({
  firstName: Yup.string().required('First name is required'),
  lastName: Yup.string().required('Last name is required'),
  email: Yup.string().email('Invalid email address').required('Email is required'),
  password: Yup.string().min(6, 'Password must be at least 6 characters').required('Password is required'),
  phoneNumber: Yup.string()
    .matches(phoneRegExp, 'Phone number is not valid')
    .required('Phone number is required'),
});

function RegistrationForm() {
  const {
    register,
    handleSubmit,
    control,
    setError,
    formState: { errors },
  } = useForm({
    resolver: yupResolver(validationSchema),
  });

  const onSubmit = handleSubmit(async (data) => {
    const registrationFormWrapper = document.getElementById('registration_form_wrapper');
    const nonce = registrationFormWrapper.dataset.nonce;
    const userType = registrationFormWrapper.dataset.usertype;

    if (userType !== 'customer' && userType !== 'yith_vendor') {
      alert('Invalid user type');
      return;
    }

    const userData = {
      first_name: data.firstName,
      last_name: data.lastName,
      phone_number: data.phoneNumber,
      email: data.email,
      password: data.password,
      role: userType,
      nonce,
    };

    try {
      const response = await fetch(import.meta.env.VITE_ECOMMERCE_APP_URL + '/wp-json/v1/user/register', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(userData),
      });

      const result = await response.json();
      if (response.ok) {
        window.location.href = import.meta.env.VITE_ECOMMERCE_APP_URL + '/my-account';
      } else {
        if (result.data.error === 'email_exists') {
          setError('email', {
            type: 'manual',
            message: 'Email already exists',
          });
        } else {
          enqueueSnackbar(result.data.message, { variant: 'error' });
        }
      }
    } catch (error) {
      alert('Error: ' + error.message);
    }
  });

  const { ref: firstNameRef, ...registerFirstName } = register("firstName");
  const { ref: lastNameRef, ...registerLastName } = register("lastName");
  const { ref: emailRef, ...registerEmail } = register("email");
  const { ref: passwordRef, ...registerPassword } = register("password");
  return (
    <form onSubmit={onSubmit} className="my-2 mx-2">
      <Row className="mb-1">
        <Col xs="6">
          <FormGroup>
            <Label for="firstName">First Name</Label>
            {console.log(registerFirstName)}
            <Input
              id="firstName"
              name="firstName"
              type="text"
              size="lg"
              invalid={!!errors.firstName}
              innerRef={firstNameRef}
              {...registerFirstName }
            />
            {errors.firstName && <FormFeedback>{errors.firstName.message}</FormFeedback>}
          </FormGroup>
        </Col>
        <Col xs="6">
          <FormGroup>
            <Label for="lastName">Last Name</Label>
            <Input
              id="lastName"
              name="lastName"
              type="text"
              size="lg"
              invalid={!!errors.lastName}
              innerRef={lastNameRef}
              {...registerLastName}
            />
            {errors.lastName && <FormFeedback>{errors.lastName.message}</FormFeedback>}
          </FormGroup>
        </Col>
      </Row>
      <FormGroup>
        <Label for="phoneNumber">Phone Number</Label>
        <Controller
          name="phoneNumber"
          control={control}
          render={({ field }) => (
            <PhoneInput
              {...field}
              className={`mb-1 ${errors.phoneNumber ? 'is-invalid' : ''}`}
              placeholder="Enter phone number"
            />
          )}
        />
        {errors.phoneNumber && <FormFeedback>{errors.phoneNumber.message}</FormFeedback>}
      </FormGroup>
      <Row className="mb-1">
        <Col xs="6">
          <FormGroup>
            <Label for="email">Email</Label>
            <Input
              id="email"
              name="email"
              type="email"
              size="lg"
              invalid={!!errors.email}
              innerRef={emailRef}
              {...registerEmail}
            />
            {errors.email && <FormFeedback>{errors.email.message}</FormFeedback>}
          </FormGroup>
        </Col>
        <Col xs="6">
          <FormGroup>
            <Label for="password">Password</Label>
            <Input
              id="password"
              name="password"
              type="password"
              size="lg"
              invalid={!!errors.password}
              innerRef={passwordRef}
              {...registerPassword}
            />
            {errors.password && <FormFeedback>{errors.password.message}</FormFeedback>}
          </FormGroup>
        </Col>
      </Row>
      <Button type="submit" className="btn-block btn-md" color="success">
        Register
      </Button>
    </form>
  );
}

export default RegistrationForm;
