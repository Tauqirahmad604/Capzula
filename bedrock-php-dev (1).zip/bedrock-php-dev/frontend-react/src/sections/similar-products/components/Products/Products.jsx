import { useRef } from 'react';
import { useHits, useInstantSearch } from 'react-instantsearch';
import PropTypes from 'prop-types';

// import Carousel from 'react-multi-carousel';
// import 'swiper/css/bundle';
// import 'swiper/css/scrollbar';
// import { Navigation, Pagination, Scrollbar } from 'swiper/modules';

import Product from 'src/sections/product-list/components/Product/Product';
import ProductLoaders from 'src/components/Loaders/ProductLoaders';
import useSwiper from 'src/hooks/useSwiper';


function Products({ slidesPerView, id, lazy = false }) {
  const { status } = useInstantSearch();
  const { hits, sendEvent } = useHits();
  const isLoading = status === 'loading';

  useSwiper(`.swiper-${id}`, slidesPerView);

  return (
    <div className="slider-container">
      <div className={`swiper swiper-${id}`}>
        <div className="swiper-wrapper py-4">
          {isLoading && <ProductLoaders />}

          {hits.map((hit) => (
            <div key={hit.objectID} className="swiper-slide">
              <Product
                lazy={lazy}
                key={hit.objectID}
                hit={hit}
                onClick={(hit) => sendEvent('click', hit, 'Product Clicked')}
              />
            </div>
          ))}
        </div>

        <div className="swiper-pagination"></div>
        <div className="swiper-button-prev"></div>
        <div className="swiper-button-next"></div>

        <div className="swiper-thumbs"></div>
        <div className="swiper-scrollbar"></div>
      </div>
    </div>
  );
}

export default Products;


Products.propTypes = {
  slidesPerView: PropTypes.object,
  id: PropTypes.string,
  lazy: PropTypes.bool,
};