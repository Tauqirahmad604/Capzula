import { InstantSearch, Configure } from 'react-instantsearch';
import searchClient from 'src/lib/searchClient';
import {Products} from './components';
import { getLangIndexName } from 'src/lib/utils';
import PropTypes from 'prop-types';



function SimilarProducts({type, id}) {
  const indexName = getLangIndexName();
  const getFilterData = () => {
    if (!window.categoriesHierarchy) {
      return [];
    }
    const categoriesString = window.categoriesHierarchy.map((cat)=>cat.name);
    if (categoriesString.length > 2) {
      categoriesString.pop();
    }

    const filterData = [
      `categories.lvl1:${categoriesString.join(' > ')}`,
    ];
    if (window.activeSellerShop?.id && type === 'vendor') {
      filterData.push(`vendor.id:${window.activeSellerShop?.id}`);
    }


    return filterData;
  }


  const slidesPerViewConfig = {
    xl: 4,
    lg: 4,
    md: 3,
    sm: 2,
  }


  return (
    <InstantSearch
      searchClient={searchClient}
      insights={true}
      indexName={indexName}
    >
      <Configure
        clickAnalytics
        hitsPerPage={16}
        page={0}
        facetFilters={getFilterData()}
        filters={`NOT parent_id:${window.productData.id}`}
        ruleContexts={[]}
        facetingAfterDistinct={false}
      />

      <Products lazy={false} id={id} slidesPerView={slidesPerViewConfig} />

    </InstantSearch>
  );
}

SimilarProducts.propTypes = {
  type: PropTypes.string,
  id: PropTypes.string,
}

export default SimilarProducts;

