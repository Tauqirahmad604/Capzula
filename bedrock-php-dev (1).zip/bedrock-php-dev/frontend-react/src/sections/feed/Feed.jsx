import React, { useRef, useEffect } from 'react';
import styled from 'styled-components';
import Item from './Item';
const FeedContainer = styled.div`
  max-height: 100vh;
  overflow-y: scroll;
  scroll-snap-type: y mandatory;
  background: #fff;
  display: flex;
  flex-direction: column;
  scrollbar-width: none;

  &::-webkit-scrollbar {
    display: none; /* for Chrome, Safari, and Opera */
  }
`;

const FeedItem = styled.div`
  margin: 0;
  padding: 20px 0px;
  text-align: center;
  display: flex;
  justify-content: center;
  align-items: center;
  align-content: center;
  scroll-snap-align: start;
    scroll-snap-stop: always;

  min-height: 100vh;

  background: #eee;
  &:nth-child(odd) {
    background-color: #f2f2f2;
  }
`;

const StyledGalleryContainer = styled.div`
  min-width: 488px;
  border-radius: 20px;
  background-color: black;
  height: 867px;
  position: relative;
  overflow: hidden;
`;

const GalleryContainer = ({ index, children }) => {
  const containerRef = useRef(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            console.log(`GalleryContainer ${index} is in view`);
          }
        });
      },
      {
        root: null,
        threshold: 0.5, // Adjust this threshold as needed
      }
    );

    if (containerRef.current) {
      observer.observe(containerRef.current);
    }

    return () => {
      if (containerRef.current) {
        observer.unobserve(containerRef.current);
      }
    };
  }, [index]);

  return <StyledGalleryContainer ref={containerRef}>{children}</StyledGalleryContainer>;
};

const Feed = () => {
  return (
    <FeedContainer>
      <FeedItem>
        <GalleryContainer index={1} >
<Item>
  test
          </Item>
          </GalleryContainer>
      </FeedItem>
      <FeedItem>
        <GalleryContainer index={2} >
<Item>
          </Item>
          </GalleryContainer>
      </FeedItem>
      <FeedItem>
        <GalleryContainer index={3} >
<Item>
          </Item>
          </GalleryContainer>
      </FeedItem>
      <FeedItem>
        <GalleryContainer index={4} >
<Item>
          </Item>
          </GalleryContainer>
      </FeedItem>
      <FeedItem>
        <GalleryContainer index={5} >
<Item>
          </Item>
          </GalleryContainer>
      </FeedItem>
    </FeedContainer>
  );
};

export default Feed;
