import { useEffect } from 'react';
import { createPortal } from 'react-dom';
import OutfitsFeed from './components/OutfitsFeed';
import ProductGallery from './components/ProductGallery';
import { ProductList } from './sections/product-list';
import { Autocomplete } from './sections/autocomplete';
import { SimilarProducts } from './sections/similar-products';
import { CpzRelatedProducts } from './sections/related-products';
import { FooterNav } from './sections/footer-nav';
import { RegistrationForm } from './sections/registration-form';

import i18n from './i18n';
import Feed from './sections/feed/Feed';
import { SnackbarProvider } from 'notistack';
// sessionStorage.clear();
// console.log('cleared')
function App() {
  const outfitsFeedDiv = document.getElementById('outfits_feed_wrapper');
  const registrationFormDiv = document.getElementById('registration_form_wrapper');
  const productListViewDiv = document.getElementById('product_list_view');
  const globalSearchDiv = document.getElementById('global_search');
  const vendorSearchDiv = document.getElementById('vendor_search');
  const vendorSimilarProducts = document.getElementById(
    'vendor_similar_products'
  );
  const mobileFooterNavDiv = document.getElementById('mobile_footer_nav');
  const recommendedSimilarProducts = document.getElementById(
    'recommended_similar_products'
  );
  const relatedProducts = document.getElementById('related_products');
  const productGallery = document.getElementById('product_gallery');

  useEffect(() => {
    const lang = window.userLang || 'en';
    i18n.changeLanguage(lang);
  }, []);

  return (
    <>
      {!!globalSearchDiv &&
        createPortal(
          <Autocomplete
            plugins={['products', 'vendors', 'recent-searches', 'categories']}
          />,
          globalSearchDiv
        )}
      {!!vendorSearchDiv &&
        createPortal(<Autocomplete plugins={['vendors']} />, vendorSearchDiv)}
      {!!outfitsFeedDiv && createPortal(<Feed />, outfitsFeedDiv)}
      {!!productListViewDiv &&
        createPortal(<ProductList />, productListViewDiv)}
      {!!vendorSimilarProducts &&
        window.activeSellerShop?.id &&
        createPortal(
          // <FooterNav filters={[`vendor.id:${window.activeSellerShop?.id}`, ]} />,
          <SimilarProducts id="vendor-similar-products" type="vendor" />,
          vendorSimilarProducts
        )}
      {!!recommendedSimilarProducts &&
        createPortal(
          <SimilarProducts
            id="recommended-similar-products"
            type="recommended"
          />,
          recommendedSimilarProducts
        )}
      {!!productGallery &&
        !!window.productGalleryImages &&
        createPortal(<ProductGallery />, productGallery)}

      {!!relatedProducts &&
        createPortal(
          <CpzRelatedProducts id="related-products" />,
          relatedProducts
        )}

{!!mobileFooterNavDiv && createPortal(<FooterNav />, mobileFooterNavDiv)}
{!!registrationFormDiv && createPortal((
  <SnackbarProvider>
    <RegistrationForm />
  </SnackbarProvider>
), registrationFormDiv)}

      
    </>
  );
}

export default App;
