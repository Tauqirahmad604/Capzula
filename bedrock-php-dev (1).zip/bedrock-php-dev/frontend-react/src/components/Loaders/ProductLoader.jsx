import './ProductLoader.scss';

const ProductLoader = () => {
  return (
    <div className="img-card-wrapper ais-InfiniteHits-item">
      <div className="cpz-skeleton">
        <div className="cpz-skeleton-wrapper">
          <div className="cpz-skeleton-image bg-loading">
            <img className="img-card__img-loader" src="https://capzula.com/wp-content/themes/capzula-theme/static/images/layout/product-placeholder.png" alt="" />
          </div>
          <div className="cpz-skeleton-content">
            <div className="cpz-skeleton-title bg-loading"></div>
            <div className="cpz-skeleton-price bg-loading"></div>
          </div>
          <div className="cpz-skeleton-colors">
            <div className="cpz-skeleton-color bg-loading"></div>
            <div className="cpz-skeleton-color bg-loading"></div>
            <div className="cpz-skeleton-color bg-loading"></div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProductLoader;
