import { useMemo } from 'react';
import PropTypes from 'prop-types';
import ProductLoader from './ProductLoader';

const ProductLoaders = ({numOfProducts = 4}) => {
  const skeletons = useMemo(
    () =>
      Array(numOfProducts)
        .fill()
        .map((_, index) => <ProductLoader key={index} />),
    [numOfProducts]
  );

  return <>{skeletons}</>;
};

ProductLoaders.propTypes = {
  numOfProducts: PropTypes.number,
};

export default ProductLoaders;