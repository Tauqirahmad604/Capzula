import styled from "styled-components";

export const ThumbnailContainer = styled.div`
  display: flex;
  overflow-x: auto;
  gap: 10px;
  padding: 10px;
`;

const thumbnailImageSize = "70px";

export const ThumbnailImage = styled.img`
  height: ${thumbnailImageSize};
  width: ${thumbnailImageSize};
  min-width: ${thumbnailImageSize};
  min-height: ${thumbnailImageSize};
  object-fit: cover;
  border-radius: 10px;
  border: 1px solid gray;
  box-sizing: border-box;
  cursor: pointer;
  &:hover {
    border: 1px solid black;
  }
`;
