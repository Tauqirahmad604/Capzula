import styled from "styled-components";

export const ImageIcon = styled.img`
  width: 30px;
  height: 30px;
  border-radius: 40%;
  padding: 2px;

  &:hover {
    cursor: pointer;
    background-color: white;
  }
`;
