import styled from "styled-components";

export const FocusCircle = styled.div`
  height: 10px;
  width: 10px;
  border-radius: 50%;
  border: 1px solid gray;
  box-sizing: border-box;
`;
