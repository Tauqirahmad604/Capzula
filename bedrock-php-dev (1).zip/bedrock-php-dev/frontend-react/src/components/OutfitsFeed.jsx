import { useEffect, useState } from "react";
import { Outfit } from "./Outfit";
import { OutfitsContainer } from "./OutfitsContainer";
import outfitsMock from "./outfits.json";
function OutfitsFeed() {
  const [outfits, setOutfits] = useState(outfitsMock.outfits);
  const [category, setCategory] = useState();
  const [subcategory, setSubcategory] = useState();

  // function fetchOutfits() {
  //   // fetch("https://backend-images.onrender.com/outfits")
  //   //   .then((response) => response.json())
  //   //   .then((json) => {
  //   //     setOutfits([...outfits, ...json.outfits]);
  //   //     setIsLoadingMore(false);
  //   //   });

  //   setOutfits(outfits.outfits)
  // }

  useEffect(() => {
    const currentUrl = window.location.pathname;

    const match = currentUrl.match(/product-category\/(.*)/);

    if (match) {
      const urlParams = match[0].split("/");
      const ifCategory = urlParams[1] != undefined;
      const ifSubcategory = urlParams[2] != undefined;
      if (ifCategory) {
        setCategory(urlParams[1]);
      }
      if (ifSubcategory) {
        setSubcategory(urlParams[2]);
      }
    }
    // fetchOutfits();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const [isLoadingMore, setIsLoadingMore] = useState(false);

  function handleScroll(event) {
    const element = event.target;
    const scrollPosition = element.scrollTop;
    const scrollHeight = element.scrollHeight;
    const clientHeight = element.clientHeight;
    const scrollBottom = scrollHeight - scrollPosition - clientHeight;

    if (scrollBottom < 1500 && !isLoadingMore) {
      setIsLoadingMore(true);
      console.log("fetch more");
      // fetchOutfits();
    }
  }

  // const [firstTouch, setFirstTouch] = useState(false);

  // if (!firstTouch) {
  //   return (
  //     <>
  //       <div style={{ fontSize: 10, color: "black" }}>
  //         {category && <h5>{category}</h5>}
  //         {subcategory && <h5>{subcategory}</h5>}
  //       </div>
  //       <button onClick={() => setFirstTouch(true)}>Login</button>
  //     </>
  //   );
  // }

  return (
    <div className="app">
      <div style={{ fontSize: 10, color: "black" }}>
        {category && <h5>{category}</h5>}
        {subcategory && <h5>{subcategory}</h5>}
      </div>
      {console.log(outfits, '<< outfits')}

      <div className="outfit-list" onScroll={handleScroll}>
        <OutfitsContainer className="outfits-container">
          {outfits.map((outfit, index) => (
            <Outfit key={index} outfit={outfit} />
          ))}
        </OutfitsContainer>
      </div>
    </div>
  );
}

export default OutfitsFeed;
