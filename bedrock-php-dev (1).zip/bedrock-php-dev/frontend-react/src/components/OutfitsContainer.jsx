import styled from "styled-components";

export const OutfitsContainer = styled.div`
  display: flex;
  flex-direction: column;
  gap: 10rem;
  height: 100vh;
  width: 100%;
`;
