import PropTypes from "prop-types";
import styled from "styled-components";
const ModalContainer = styled.article`
  background-color: rgba(0, 0, 0, 0.5);
  position: fixed;
  left: 0;
  right: 0;
  top: 0;
  bottom: 0;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  z-index: 1000;
`;

const ModalContentContainer = styled.div`
  background-color: white;
  position: relative;
  width: 85%;
  height: auto;
  border-radius: 12px;
  background: white;
  display: flex;
  flex-direction: column;
  justify-content: start;
  align-items: center;
  color: black;
  box-shadow: 0 16px 24px 0 rgba(0, 0, 0, 0.2);
  backdrop-filter: blur(8px);
  -webkit-backdrop-filter: blur(8px);
  max-height: 70vh;
  overflow-y: auto;
  padding: 20px;
  box-sizing: border-box;

  p {
    margin: 0;
    padding: 0;
  }
`;

export const Modal = ({ children, openModal, setOpenModal }) => {
  if (!openModal) return null;

  function closeModal() {
    setOpenModal(false);
  }

  // CLOSE MODAL WHEN CLICKING OUTSIDE OF IT
  function outsideClick(event) {
    const element = event.target;
    if (element.id === "modal-container") {
      closeModal();
    }
  }
  return (
    <ModalContainer onClick={outsideClick} id="modal-container">
      <ModalContentContainer>{children}</ModalContentContainer>
    </ModalContainer>
  );
};

Modal.propTypes = {
  children: PropTypes.node.isRequired,
  openModal: PropTypes.bool.isRequired,
  setOpenModal: PropTypes.func.isRequired,
};
