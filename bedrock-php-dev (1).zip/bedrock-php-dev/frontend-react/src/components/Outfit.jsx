/* eslint-disable react/prop-types */
/* eslint-disable no-unused-vars */
import { useEffect, useState } from "react";
import { ImageIcon } from "./ImageIcon";
import { ThumbnailContainer, ThumbnailImage } from "./ThumbnailImage";
import { ImagesContainer } from "./ImagesContainer";
import { ProductImage, ProductVideo } from "./ProductImage";
import { ContainerCircles } from "./ContainerCircles";
import { FocusCircle } from "./FocusCircle";
import { Modal } from "./Modal";

export const Outfit = ({ outfit }) => {
  const [openModal, setOpenModal] = useState(false);
  const [foccusedImage, setFoccusedImage] = useState(0);
  const [productList, setProductList] = useState(outfit.products);

  function handleScroll(event) {
    const element = event.target;
    const scrollSnapList = element.getClientRects();
    const scrollSnapWidth = scrollSnapList[0].width;
    const scrollPosition = element.scrollLeft;
    const currentFoccusedImage = Math.round(scrollPosition / scrollSnapWidth);
    if (currentFoccusedImage !== foccusedImage) {
      setFoccusedImage(currentFoccusedImage);
    }
  }

  function handleThumbnailClick(index) {
    setFoccusedImage(index);

    const element = document.getElementById(`images-container-${outfit.id}`);
    const scrollSnapList = element.getClientRects();
    const scrollSnapWidth = scrollSnapList[0].width;
    element.scrollLeft = index * scrollSnapWidth;
  }
  useEffect(() => {
    setTimeout(() => {
      handleThumbnailClick(0);
    }, 100);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <div
      style={{
        backgroundColor: "#f0f0f0",
        scrollSnapAlign: "start",
      }}
    >
      <div style={{ position: "relative" }}>
        <ImagesContainer
          id={`images-container-${outfit.id}`}
          onScroll={handleScroll}
        >
          {productList.map((product, index) => (
            <>
              {product.type === "image" ? (
                <ProductImage key={index} src={product.src} alt="product" />
              ) : (
                <ProductVideo
                  key={index}
                  src={product.src}
                  autoPlay
                  loop
                  muted
                  controls={false}
                  playsInline
                />
              )}
            </>
          ))}
        </ImagesContainer>
        <div
          style={{
            width: "100%",
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
          }}
        >
          <ContainerCircles>
            {productList.map((_, index) => (
              <FocusCircle
                key={index}
                style={{
                  backgroundColor: index === foccusedImage ? "black" : "white",
                }}
              />
            ))}
          </ContainerCircles>
        </div>
        <div
          style={{
            position: "absolute",
            bottom: 25,
            right: 14,
            display: "flex",
            flexDirection: "column",
            gap: 10,
          }}
        >
          <ImageIcon src="https://cdn-icons-png.flaticon.com/128/1077/1077035.png" />
          <ImageIcon
            src="https://cdn-icons-png.flaticon.com/512/1170/1170678.png"
            onClick={() => setOpenModal(true)}
          />
        </div>
      </div>
      <ThumbnailContainer>
        {productList.map((product, index) => (
          <ThumbnailImage
            key={index}
            src={product.type === "image" ? product.src : product.thumbnail}
            style={{
              border: index === foccusedImage ? "2px solid black" : "none",
            }}
            onClick={() => {
              handleThumbnailClick(index);
            }}
          />
        ))}
      </ThumbnailContainer>
      <Modal openModal={openModal} setOpenModal={setOpenModal}>
        <div
          style={{
            width: "100%",
            display: "flex",
            flexDirection: "column",
            gap: 20,
            height: "100%",
            minHeight: "360px",
            overflowY: "auto",
          }}
        >
          {productList.map((product, index) => (
            <div
              key={index}
              style={{
                display: "flex",
                width: "100%",
                alignItems: "center",
                gap: 10,
              }}
            >
              <input
                type="checkbox"
                checked={product.checked}
                onChange={() =>
                  setProductList(
                    productList.map((item) => {
                      if (item.id === product.id) {
                        return {
                          ...item,
                          checked: !item.checked,
                        };
                      }
                      return item;
                    })
                  )
                }
                style={{ width: 20, height: 20 }}
              />
              <ThumbnailImage
                src={product.type === "image" ? product.src : product.thumbnail}
              />
              <div style={{ fontSize: 14 }}>
                <p>
                  <strong>{product.name}</strong>
                </p>
                <p>{product.store}</p>
                <p>
                  <strong>{product.price}</strong>
                </p>
              </div>
            </div>
          ))}
        </div>
        <button onClick={() => setOpenModal(false)}>Add to basket</button>
      </Modal>
    </div>
  );
};
