import ImageGallery from "react-image-gallery";

function ProductGallery() {
  const hidePlaceholderLoader = () => {
    const loader = document.querySelector('.product-loading-placeholder');
    const gallery = document.querySelector('.product-gallery')

    //remove d-none class from gallery
    if (gallery) {
      gallery.style.display = 'block';
    }
    if (loader) {
      loader.style.display = 'none';
    }
  };

  return (
    <ImageGallery showPlayButton={false} useBrowserFullscreen={false} showFullscreenButton={false} onImageLoad={hidePlaceholderLoader} thumbnailPosition="left"  items={window.productGalleryImages} />
  );
}

export default ProductGallery;
