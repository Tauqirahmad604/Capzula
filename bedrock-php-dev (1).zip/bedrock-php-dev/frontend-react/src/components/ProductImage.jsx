import styled from "styled-components";

export const ProductImage = styled.img`
  scroll-snap-align: center;
  object-fit: cover;
  min-height: 60vh;
  max-width: 100%;
`;

export const ProductVideo = styled.video`
  scroll-snap-align: center;
  object-fit: cover;
  min-height: 60vh;
  max-width: 100%;
`;
