import styled from "styled-components";

export const ContainerCircles = styled.div`
  display: flex;
  justify-content: center;
  align-items: center;
  gap: 4px;
  position: absolute;
  bottom: 10px;
  padding: 5px 10px;
  background-color: rgba(0, 0, 0, 0.1);
  border-radius: 20px;
`;
