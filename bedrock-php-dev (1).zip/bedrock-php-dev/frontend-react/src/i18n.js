import i18n from 'i18next';
import { initReactI18next, useTranslation as useTranslationHook } from 'react-i18next';
import { en, es, tr } from './translations'

const lng = window.userLang || 'en';
const lngInStorage = localStorage.getItem('i18nextLng');

// Set the language in local storage if it's not set or different
if (!lngInStorage || lngInStorage !== lng) {
  localStorage.setItem('i18nextLng', lng);
}

i18n
  // pass the i18n instance to react-i18next.
  .use(initReactI18next)
  // init i18next
  // for all options read: https://www.i18next.com/overview/configuration-options
  .init({
    fallbackLng: 'en',
    debug: true,
    lng,
    resources: {
      en: {
        translation: en,
      },
      es: {
        translation: es,
      },
      tr: {
        translation: tr,
      },
    },
    interpolation: {
      escapeValue: false, // not needed for react as it escapes by default
    },
  });

// i18n.on('languageChanged', (lng) => {
//   i18n.changeLanguage(lng);
// });

export default i18n;

export function useTranslation() {
  const { t, i18n, ready } = useTranslationHook();

  return {
    t,
    i18n,
    ready,
    changeLanguage: (lng) => {
      i18n.changeLanguage(lng)
    },
  };
}