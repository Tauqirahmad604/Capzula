import { useEffect, useRef } from 'react';
// import 'swiper/css/scrollbar';
import { Navigation, Pagination, Scrollbar } from 'swiper/modules';
import Swiper from 'swiper';

import 'swiper/css/bundle';


function useSwiper(element, config) {
  const swiper = useRef(null);

  useEffect(() => {
    if (!element) return;

    const slidesPerViewConfig = {
      xl: config?.xl || 4,
      lg: config?.lg || 3,
      md: config?.md || 3,
      sm: config?.sm || 2,
    }

    swiper.current = new Swiper(element, {
      // configure Swiper to use modules
      modules: [Navigation, Pagination, Scrollbar],
      spaceBetween: 10,
      breakpoints: {
        320: {
          slidesPerView: slidesPerViewConfig.sm,
        },
        640: {
          slidesPerView: slidesPerViewConfig.md,
        },
        767: {
          slidesPerView: slidesPerViewConfig.lg,
        },
        1000: {
          slidesPerView: slidesPerViewConfig.xl,
        }
      },
      createElements: true,
      scrollbar: {
        el: '.swiper-scrollbar',
      },
      navigation: {
        nextEl: '.swiper-button-next',
        prevEl: '.swiper-button-prev',
      },
    });

    return () => {
      swiper.current?.destroy();
    };
  }, [element, config?.lg, config?.md, config?.sm, config?.xl]);

  return swiper;
}

export default useSwiper;