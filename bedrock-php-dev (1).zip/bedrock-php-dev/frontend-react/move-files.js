import fs from 'fs-extra';
import path from 'path';

// Define the source and destination directories

// eslint-disable-next-line no-undef
const sourceDir = path.join(process.cwd(), 'dist');
// eslint-disable-next-line no-undef
const destDir = path.join(process.cwd(), '../web/app/themes/capzula-theme/static/frontend-react');

// Move the files from source to destination
fs.move(sourceDir, destDir, { overwrite: true })
  .then(() => console.log('Files moved successfully!'))
  .catch(err => console.error('Error moving files:', err));