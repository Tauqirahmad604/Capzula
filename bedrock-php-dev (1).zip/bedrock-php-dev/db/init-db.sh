#!/bin/bash
set -e

# Wait for the MySQL server to be ready
while ! mysqladmin ping -h"localhost" --silent; do
    sleep 1
done

# Restore the backup
mysql -u root -p"${MYSQL_ROOT_PASSWORD}" "${MYSQL_DATABASE}" < /docker-entrypoint-initdb.d/backup.sql
